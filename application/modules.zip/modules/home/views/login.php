



































<div class="container col-2" style="margin-top: 20px;">

    <?php 
    if($this->session->flashdata("error_msg") != ''){?>
       <div class="alert alert-danger">
           <button class="close" data-dismiss="alert"></button>
           <?php echo $this->session->flashdata("error_msg");?>
       </div>
       <?php
   }
   ?>
   <?php 
   if($this->session->flashdata("success") != ''){?>
       <div class="alert alert-success">
           <button class="close" data-dismiss="alert"></button>
           <?php echo $this->session->flashdata("success");?>
       </div>
       <?php
   }
   ?> 

   <div class="row">
    <?php include('side_bar.php'); ?>






    <div class="col-sm-9" id="content">



      <h1>Checkout</h1>
      <div id="accordion" class="panel-group">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="panel-title"><a class="accordion-toggle collapsed" data-parent="#accordion" data-toggle="collapse" href="#collapse-checkout-option" aria-expanded="false">Step 1: Checkout Options <i class="fa fa-caret-down"></i></a></h4>
        </div>
        <div id="collapse-checkout-option" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
            <div class="panel-body">
              <div class="row">

                <form action="<?php echo base_url('home/customer_auth');?>" method="post">
                <div class="col-sm-6">
          <h2>Register</h2>
          <p>New Customer please register first!</p>
          <div class="form-group">
            <label for="input-email" class="control-label">E-Mail</label>
            <input type="text" class="form-control" id="input-email" placeholder="E-Mail" value="" name="email">
        </div>
        <div class="form-group">
            <label for="input-password" class="control-label">Password</label>
            <input type="password" class="form-control" id="input-password" placeholder="Password" value="" name="password">
            <!-- <a href="http://localhost/opc001/index.php?route=account/forgotten">Forgotten Password</a> --></div>
            <input class="btn btn-primary" type="submit" name="submit" value="Register" style="margin-bottom: 15px;">
        </div>
    </form>

        <form action="<?php echo base_url('home/customer_auth');?>" method="post">
      <div class="col-sm-6">
          <h2>Login Customer</h2>
          <p>Existing Customer Login First</p>
          <div class="form-group">
            <label for="input-email" class="control-label">E-Mail</label>
            <input type="text" class="form-control" id="input-email" placeholder="E-Mail" value="" name="email">
        </div>
        <div class="form-group">
            <label for="input-password" class="control-label">Password</label>
            <input type="password" class="form-control" id="input-password" placeholder="Password" value="" name="password">
            <!-- <a href="http://localhost/opc001/index.php?route=account/forgotten">Forgotten Password</a> --></div>
            <input class="btn btn-primary" type="submit" name="submit" value="Login">
        </div>
    </form>
    </div>
</div>
</div>
</div>
</div>


</div>
</div>
</div>


















