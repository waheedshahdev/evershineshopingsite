<style type="text/css">
    *{
    margin: 0;
    padding: 0;
}
.rate {
    float: left;
    height: 46px;
    padding: 0 10px;
}
.rate:not(:checked) > .inpt {
    position:fixed;
    top:-9999px;
}
.rate:not(:checked) > .str {
    float:right;
    width:1em;
    overflow:hidden;
    white-space:nowrap;
    cursor:pointer;
    font-size:30px;
    color:#ccc;
}
.rate:not(:checked) > .str:before {
    content: '★ ';
}
.rate > .inpt:checked ~ .str {
    color: #ffc700;    
}
.rate:not(:checked) > .str:hover,
.rate:not(:checked) > .str:hover ~ .str {
    color: #deb217;  
}
.rate > .inpt:checked + .str:hover,
.rate > .inpt:checked + .str:hover ~ .str,
.rate > .inpt:checked ~ .str:hover,
.rate > .inpt:checked ~ .str:hover ~ .str,
.rate > .str:hover ~ .inpt:checked ~ .str {
    color: #c59b08;
}

/* Modified from: https://github.com/mukulkant/Star-rating-using-pure-css */
  </style>







<div class="container col-2" style="margin-top: 20px;">
     
                                    <?php 
             if($this->session->flashdata("error_msg") != ''){?>
             <div class="alert alert-danger">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("error_msg");?>
             </div>
          <?php
            }
          ?>
          <?php 
             if($this->session->flashdata("success") != ''){?>
             <div class="alert alert-success">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("success");?>
             </div>
          <?php
            }
          ?> 
    
    <div class="row">
        <?php include('side_bar.php'); ?>




    <?php foreach ($product_detail as $detail) {
                     if(empty($detail->customer_retail_price_new) || $detail->customer_retail_price_new == 0)
                                    {
                                        $pr_price = $detail->customer_retail_price;
                                        $product_price = '<span class="current_price">PKR '.$detail->customer_retail_price.'.00</span>';
                                    }
                                    else{
                                        $pr_price = $detail->customer_retail_price_new;
                                        $product_price = '
                                                <span class="current_price">PKR '.$detail->customer_retail_price_new.'.00</span>';
                                    }

                                    if(empty($detail->sub_image))
                                    {
                                        $img = 'frontfiles/assets/image/product/product8.jpg';
                                    }
                                    else{
                                        $img = 'product_images/'.$detail->sub_image.'';
                                    }

                

                } ?>

<style type="text/css">
    .thumbnails img{
        padding: 2% 10%;
        height: auto !important;
    }
    iframe{
        padding-top: 15px;
    }
</style>

<div id="content" class="col-sm-9">
            <div class="row">
                <div class="col-sm-6">
                    <ul class="thumbnails">
                        <li><a class="thumbnail fancybox" href="<?php echo base_url($img); ?>" title="<?php echo $detail->product_name; ?>"><img src="<?php echo base_url($img); ?>" title="<?php echo $detail->product_name; ?>" alt="<?php echo $detail->product_name; ?>" /></a></li>
                        <div id="product-thumbnail" class="owl-carousel">
                            <div class="item">
                                <li class="image-additional"><a class="thumbnail fancybox" rel="gallery1"  href="assets/image/product/product1.jpg" title="<?php echo $detail->product_name; ?>"> <img src="<?php echo base_url(); ?>frontfiles/assets/image/product/pro-1-220x294.jpg" title="<?php echo $detail->product_name; ?>" alt="<?php echo $detail->product_name; ?>" /></a></li>
                            </div>
                            <div class="item">
                                <li class="image-additional"><a class="thumbnail fancybox" rel="gallery1" href="<<?php echo base_url($img); ?>" title="<?php echo $detail->product_name; ?>"> <img src="<?php echo base_url($img); ?>" title="<?php echo $detail->product_name; ?>" alt="<?php echo $detail->product_name; ?>" /></a></li>
                            </div>
                            <div class="item">
                                <li class="image-additional"><a class="thumbnail fancybox" rel="gallery1" href="<?php echo base_url(); ?>frontfiles/assets/image/product/product3.jpg" title="<?php echo $detail->product_name; ?>"> <img src="<?php echo base_url(); ?>frontfiles/assets/image/product/pro-3-220x294.jpg" title="<?php echo $detail->product_name; ?>" alt="<?php echo $detail->product_name; ?>" /></a></li>
                            </div>
                            <div class="item">
                                <li class="image-additional"><a class="thumbnail fancybox" rel="gallery1" href="<?php echo base_url(); ?>frontfiles/assets/image/product/product4.jpg" title="<?php echo $detail->product_name; ?>"> <img src="<?php echo base_url(); ?>frontfiles/assets/image/product/pro-4-220x294.jpg" title="<?php echo $detail->product_name; ?>" alt="<?php echo $detail->product_name; ?>" /></a></li>
                            </div>
                            <div class="item">
                                <li class="image-additional"><a class="thumbnail fancybox" rel="gallery1" href="<?php echo base_url(); ?>frontfiles/assets/image/product/product5.jpg" title="<?php echo $detail->product_name; ?>"> <img src="<?php echo base_url(); ?>frontfiles/assets/image/product/pro-5-220x294.jpg" title="<?php echo $detail->product_name; ?>" alt="<?php echo $detail->product_name; ?>" /></a></li>
                            </div>
                            <div class="item">
                                <li class="image-additional"><a class="thumbnail fancybox" rel="gallery1" href="<?php echo base_url(); ?>frontfiles/assets/image/product/product6.jpg" title="<?php echo $detail->product_name; ?>"> <img src="<?php echo base_url(); ?>frontfiles/assets/image/product/pro-6-220x294.jpg" title="<?php echo $detail->product_name; ?>" alt="<?php echo $detail->product_name; ?>" /></a></li>
                            </div>
                            <div class="item">
                                <li class="image-additional"><a class="thumbnail fancybox" rel="gallery1" href="<?php echo base_url(); ?>frontfiles/assets/image/product/product7.jpg" title="<?php echo $detail->product_name; ?>"> <img src="assets/image/product/pro-7-220x294.jpg" title="<?php echo $detail->product_name; ?>" alt="<?php echo $detail->product_name; ?>" /></a></li>
                            </div>
                        </div>
                    </ul>
                </div>
                <div class="col-sm-6">
                    <h1 class="productpage-title"><?php echo $detail->product_name; ?></h1>
                    <div class="rating product"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span> <span class="review-count"> <a href="#" onClick="$('a[href=\'#tab-review\']').trigger('click'); return false;">1 reviews</a> / <a href="#" onClick="$('a[href=\'#tab-review\']').trigger('click'); return false;">Write a review</a></span>
                        <hr>
                        <!-- AddThis Button BEGIN -->
                        <div class="addthis_toolbox addthis_default_style"><a class="addthis_button_facebook_like" ></a> <a class="addthis_button_tweet"></a> <a class="addthis_button_pinterest_pinit"></a> <a class="addthis_counter addthis_pill_style"></a></div>
                        <script type="text/javascript" src="../s7.addthis.com/js/300/addthis_widget.html#pubid=ra-515eeaf54693130e"></script> 
                        <!-- AddThis Button END --> 
                    </div>
                    <ul class="list-unstyled productinfo-details-top">
                        <li>
                            <h2 class="productpage-price"><?php echo $product_price; ?></h2>
                        </li>
                        <!-- <li><span class="productinfo-tax">Ex Tax: $100.00</span></li> -->
                    </ul>
                    <hr>
                    <ul class="list-unstyled product_info">
                        <li>
                            <label>Brand:</label>
                            <span> <a href="#"><?php echo $detail->brand; ?></a></span></li>
                        <li>
                            <label>Product Category:</label>
                            <span> <a href="#"><?php echo $detail->category_name; ?></a></span></li>
                        <li>
                            <label>Product Code: </label>
                            <span> <?php echo $detail->product_id; ?></span></li>
                        <li>
                            <label>Availability:</label>
                            <?php if(empty($sizes)){?>
                                <span style="color: red;">Out of Stock</span>
                            <?php } elseif (!empty($sizes)) {?>
                            <span> In Stock</span>    
                            <?php } ?>
                            
                        </li>
                        <?php if(!empty($sizes)){?>
                        <li>
                            <label>Size:</label>
                            <input type="hidden" name="product_id" id="product_id" value="<?php echo $detail->product_id; ?>">
                            <select class="form-control" style="width: 40%;" name="size" id="size">
                                <?php foreach ($sizes as $value) {?>
                                <option value="<?php echo $value->id.','.$value->size; ?>"><?php echo $value->size; ?></option>        
                                <?php } ?>
                                
                            </select>
                        </li>
                        <li>
                            <label>Color:</label>
                            <select class="form-control" style="width: 40%;" name="color" id="color">
                               
                                
                            </select>
                            <div id="stock"></div>
                        </li>
                        <?php } ?>
                        <li>
                            <label>video Link:</label>
                            <span><a href="<?php echo $detail->video_url; ?>" target="_blank"><?php echo $detail->video_url; ?></a></span>
                        </li>
                    </ul>
                    <hr>
                    <!-- <p class="product-desc"><?php //echo $detail->description; ?></p> -->
                    <div id="product">
                        <div class="form-group">
                            <label class="control-label qty-label" for="input-quantity">Qty</label>
                            <input type="number" name="product_quantity" id="product_quantity" size="2" class="form-control productpage-qty" />
                            <input type="hidden" name="product_id" value="48" />

                            <?php    $p_id = $this->uri->segment(3);
                                    foreach ($cart_data as $cart) {
                                        $c_id = $cart['product_id'];
                                        $c_qty = $cart['qty'];

                                        if($p_id == $c_id){
                                            $now_id = $c_id;
                                            $now_qty = $c_qty;
                                        }

                                    } ?>
                            <input type="hidden" name="cart_product_id" id="cart_product_id" value="<?php echo $now_id; ?>" />
                            <input type="hidden" name="cart_qty" id="cart_qty" value="<?php if(empty($cart_data)){ echo '0';}else{ echo $c_qty; }   ?>" />
                            <div class="btn-group" style="margin:20px 0;">
                                <!-- model code for popup of Login notification for Wishlist           data-toggle="modal" data-target="#myModal" -->
                                <button type="button"  class="btn btn-default wishlist" data-product_id="<?php echo $detail->product_id; ?>" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>

                                <?php if(!empty($sizes)){?>
                                <a class="btn btn-primary btn-lg btn-block add_to_cart" type="button"data-product_name="<?php echo $detail->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-product_id="<?php echo $detail->product_id; ?>" data-product_image="<?php echo $img; ?>" data-p_info_id = "<?php echo $this->uri->segment(4); ?>" title="Add to cart">Add to cart</a>
                                <?php } ?>
                                
                                <!-- <button class="btn btn-primary btn-lg btn-block add_to_cart" type="button"data-product_name="<?php echo $products->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-product_id="<?php echo $products->product_id; ?>" data-product_image="<?php echo $img; ?>" title="Add to cart">Add to Cart</button> -->

                                <button type="button" data-toggle="tooltip" class="btn btn-default compare" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <iframe id="youtube" width="100%" height="400px" src="<?php echo $detail->video_url; ?>" frameborder="0" allow="encrypted-media" allowfullscreen></iframe>


            <div class="productinfo-tab">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#tab-description" data-toggle="tab">Description</a></li>
                    <li><a href="#tab-review" data-toggle="tab">Reviews (<?php echo $total_reviews; ?>)</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="tab-description">
                        <div class="cpt_product_description ">
                            <div>
                                <p> <strong><?php $str = $detail->description; $head = explode(' ', $str, 4);  echo $head[0].' '.$head[1].' '.$head[2]; ?></strong></p>
                                <p><?php echo $detail->description; ?></p>
                                
                            </div>
                        </div>
                        <!-- cpt_container_end --></div>
                    <div class="tab-pane" id="tab-review">
                        <form class="form-horizontal" action="<?php echo base_url('home/product_details/'.$this->uri->segment(3).'/'.$this->uri->segment(4).''); ?>" method="post" enctype='multipart/form-data'>
                            <div id="review"></div>
                            <h2>Write a review</h2>
                            <div class="form-group required">
                                <div class="col-sm-12">
                                    <label class="control-label" for="input-name">Your Name</label>
                                    <input type="text" name="name" value="" id="input-name" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group required">
                                <div class="col-sm-12">
                                    <label class="control-label" for="input-review">Your Review</label>
                                    <textarea name="review" rows="5" id="input-review" class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="form-group required">
                                <div class="col-sm-12">
                                    <label class="control-label">Rating</label>
                                       <div class="rate">
                                        <input type="radio" class="inpt" id="star5" name="rating" value="5" />
                                        <label for="star5" title="text" class="str">5 stars</label>
                                        <input type="radio" class="inpt" id="star4" name="rating" value="4" />
                                        <label for="star4" title="text" class="str">4 stars</label>
                                        <input type="radio" class="inpt" id="star3" name="rating" value="3" />
                                        <label for="star3" title="text" class="str">3 stars</label>
                                        <input type="radio" class="inpt" id="star2" name="rating" value="2" />
                                        <label for="star2" title="text" class="str">2 stars</label>
                                        <input type="radio" class="inpt" id="star1" name="rating" value="1" />
                                        <label for="star1" title="text" class="str">1 star</label>
                                      </div>


                                </div>
                            </div>
                            <div class="form-group">
                                    <label>Choose Multiple Images</label>
                                    <input type="file" name="userfile[]" class="form-control" id="userfile" placeholder="Enter Product Images" required="" multiple="multiple">
                                </div> 
                            <div class="buttons clearfix">
                                <div class="pull-right">
                                    <button type="submit" id="button-review" data-loading-text="Loading..." name="submit_review" value="Submit Review" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>

                        <br> <br>
                                 <div class="content mt-3">

            <div class="animated fadeIn">

            <div class="row">
            <div class="col-md-12">
                <div class="card">
                   
                    <div class="comment-widgets m-b-20">



                        <?php foreach ($rating as $review):?>
                        <div class="d-flex flex-row comment-row">

                            <!-- <div class="p-2"><span class="round"><img src="images/face_3.jpeg" alt="user" width="50"></span></div> -->

                            <div class="comment-text w-100">
                                <h5><?php echo $review->customer_name; ?></h5>

                                <div class="form-group required">
                                
                                       <div class="rate">
                                        <input type="radio" <?php if($review->rating == '5'){ echo 'checked="checked"';} ?> class="inpt" id="star5" name="rating_<?php echo $review->id; ?>" value="5" />
                                        <label for="star5" title="text" class="str">5 stars</label>
                                        <input type="radio" <?php if($review->rating == '4'){ echo 'checked="checked"';} ?> class="inpt" id="star4" name="rating_<?php echo $review->id; ?>" value="4" />
                                        <label for="star4" title="text" class="str">4 stars</label>
                                        <input type="radio" <?php if($review->rating == '3'){ echo 'checked="checked"';} ?> class="inpt" id="star3" name="rating_<?php echo $review->id; ?>" value="3" />
                                        <label for="star3" title="text" class="str">3 stars</label>
                                        <input type="radio" <?php if($review->rating == '2'){ echo 'checked="checked"';} ?> class="inpt" id="star2" name="rating_<?php echo $review->id; ?>" value="2" />
                                        <label for="star2" title="text" class="str">2 stars</label>
                                        <input type="radio" <?php if($review->rating == '1'){ echo 'checked="checked"';} ?> class="inpt" id="star1" name="rating_<?php echo $review->id; ?>" value="1" />
                                        <label for="star1" title="text" class="str">1 star</label>
                                      </div>


                               
                            </div>
                            <!-- <button class="btn btn-danger" style="float: right;">Delete Review</button> -->
                                <div class="comment-footer"> <span class="date">    <?php echo date('M, d Y', strtotime($review->created_at)); ?></span>  <span class="action-icons"> <a href="<?php echo base_url('admin/delete_review/'.$review->product_id.'/'.$review->id.''); ?>" data-abc="true"><i class="fa fa-trash"></i></a> </span> </div>
                                <p class="m-b-5 m-t-10"><?php echo $review->review; ?></p>
                                <?php $get_images = get_query_data('SELECT review_images, review_id FROM tbl_review_images where review_id = '.$review->id.'');
                                        foreach ($get_images as $imgs) {?>
                                           <a href="<?php echo base_url('rating_images/'.$imgs->review_images.''); ?>"><img src="<?php echo base_url('rating_images/'.$imgs->review_images.''); ?>" style="width: 50px; height: 50px;"></a> 
                                        <?php }
                                 ?>
                                
                            </div>
                        </div>
                        <hr>
                    <?php endforeach; ?>
                       
                       
                        
                    
                    </div>
                </div>
            </div>
        </div>

            </div><!-- .animated -->

        </div><!-- .content -->

                    </div>


                </div>
            </div>

            <!-- <h3 class="productblock-title">Related Products</h3> -->
            <!-- <div class="box">
                <div id="related-slidertab" class="row owl-carousel product-slider">
                    <div class="item">
                        <div class="product-thumb transition">
                            <div class="image product-imageblock"> <a href="#"> <img src="assets/image/product/pro-1-220x294.jpg" alt="iPhone" title="iPhone" class="img-responsive" /> </a>
                                <div class="button-group">
                                    <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                    <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                </div>
                            </div>
                            <div class="caption product-detail">
                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                            </div>
                            <div class="button-group">
                                <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product"><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    <div class="item">
                        <div class="product-thumb transition">
                            <div class="image product-imageblock"> <a href="#"> <img src="assets/image/product/pro-7-220x294.jpg" alt="iPhone" title="iPhone" class="img-responsive" /> </a>
                                <div class="button-group">
                                    <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                    <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                </div>
                            </div>
                            <div class="caption product-detail">
                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                            </div>
                            <div class="button-group">
                                <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product"><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
    </div>


<!-- LOgin Modal -->
<div class="container">


  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>Some text in the modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
<!-- END login Modal -->



</div>


















