<div class="container col-2" style="margin-top: 20px;">
    
  
    <div class="row">
        <?php include('side_bar.php'); ?>





        <div id="content" class="col-sm-9">
            <div class="customtab">
                <!-- <div id="tabs" class="customtab-wrapper">
                    <ul class='customtab-inner'>
                        <li class='tab'><a href="#tab-latest">Latest</a></li>
                        <li class='tab'><a href="#tab-special">Special</a></li>
                        <li class='tab'><a href="#tab-bestseller">Bestseller</a></li>
                    </ul>
                </div> -->
            <h3 class="productblock-title">Featured</h3>
            
                <div id="tab-latest" class="tab-content">
                    <div class="box">
                        <div id="latest-slidertab" class="row owl-carousel product-slider">
                            <?php foreach ($product_by_category as $products):

                                    if(empty($products->customer_retail_price_new) || $products->customer_retail_price_new == 0)
                                    {
                                        $pr_price = $products->customer_retail_price;
                                        $product_price = '<span class="current_price">$'.$products->customer_retail_price.'.00</span>';
                                    }
                                    else{
                                        $pr_price = $products->customer_retail_price_new;
                                        $product_price = '
                                                <span class="price-new">$'.$products->customer_retail_price_new.'.00</span><span class="price-old">$'.$products->customer_retail_price.'.00</span>';
                                    }

                                    
                                  


                                    if(empty($products->sub_image))
                                    {
                                        $img = 'new_adminfiles/assets/image/product/6product50x59.jpg';
                                    }
                                    else{
                                        $img = 'product_images/'.$products->sub_image.'';
                                    }

                                ?>


                            <div class="item">
                                <div class="product-thumb transition">
                                    <div class="image product-imageblock"> <a href="<?php echo base_url(); ?>home/product_details/<?php echo $products->product_id; ?>/<?php echo $products->p_info_id; ?>"><img src="<?php echo base_url($img);?>" alt="<?php echo $products->product_name; ?>" title="<?php echo $products->product_name; ?>" class="img-responsive" /> </a>
                                        <input type="hidden" name="product_quantity" id="product_quantity" value="1">
                                        <div class="button-group">
                                            <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                            <button type="button" class="addtocart-btn add_to_cart" data-product_name="<?php echo $products->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-product_id="<?php echo $products->product_id; ?>" data-product_image="<?php echo $img; ?>" title="Add to cart" >Add to Cart</button>
                                            <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                                        </div>
                                    </div>
                                    <div class="caption product-detail">
                                        <h4 class="product-name"><a href="<?php echo base_url(); ?>home/product_details/<?php echo $products->product_id; ?>/<?php echo $products->p_info_id; ?>" title="<?php echo $products->product_name; ?>"><?php echo $products->product_name; ?></a></h4>
                                        <p class="price product-price"><?php echo $product_price; ?></p>
                                        <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                    </div>
                                    <div class="button-group">
                                        <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List" ><i class="fa fa-heart-o"></i></button>
                                        <button type="button" class="addtocart-btn add_to_cart" data-product_name="<?php echo $products->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-product_id="<?php echo $products->product_id; ?>" data-product_image="<?php echo $img; ?>" title="Add to cart" >Add to Cart</button>
                                        <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                            
                            
                            
                            
                            
                        </div>
                    </div>
                </div>

              
                
            </div>
            
        </div>
    </div>
</div>