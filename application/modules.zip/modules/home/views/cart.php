



                  <!--   <div class="row">
                      <div class="col-lg-6 col-md-6">
                            
                            <div class="coupon_code left">
                                <h3>Delivery Coupon</h3>
                                <form action="<?php echo base_url(); ?>home/delivery_coupon/<?php echo $cart['rowid']; ?>" method="post">
                                <div class="coupon_inner">   
                                    <p>Enter your Delivery coupon code if you have one.</p>                                
                                    <input placeholder="Coupon code" type="text" name="delivery_coupon" id="delivery_coupon">
                                    <button type="submit" name="submit" value="Apply Coupon">Apply coupon</button>
                                </div>
                                 </form>
                            </div>
                              
                        </div>
                      
                    </div> -->
                  <!--   <?php if($cart['delivery_coupon'] != ''){ ?>

                    <div class="row">
                      <div class="col-lg-6 col-md-6">
                            
                            <div class="coupon_code left">
                                <h3>Coupon</h3>
                                <table class="table">
                                    <thead>
                                      <tr>
                                        <th>Coupon</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td><?php echo $cart['delivery_coupon']; ?></td>
                                        <td><?php echo $cart['delivery_price']; ?></td>
                                        <td><a href="<?php echo base_url();?>home/remove_delivery_coupon/<?php echo $cart['rowid'];?>"><i class="ion-android-close"></i></a></td>
                                      </tr>
                                    
                                    </tbody>
                                  </table>
                            </div>
                              
                        </div>
                      
                    </div>
                  <?php } ?> -->

















<div class="container col-2" style="margin-top: 20px;">
     
                                    <?php 
             if($this->session->flashdata("error_msg") != ''){?>
             <div class="alert alert-danger">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("error_msg");?>
             </div>
          <?php
            }
          ?>
          <?php 
             if($this->session->flashdata("success") != ''){?>
             <div class="alert alert-success">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("success");?>
             </div>
          <?php
            }
          ?> 
    
    <div class="row">
        <?php include('side_bar.php'); ?>






        <div class="col-sm-9" id="content">
      <h1>Shopping Cart                &nbsp;(10.00kg) </h1>
   
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <td class="text-center">#</td>
                <td class="text-center">Image</td>
                <td class="text-left">Product Name</td>
                <td class="text-left">Quantity</td>
                <td class="text-right">Color</td>
                <td class="text-right">Size</td>
                <td class="text-right">Unit Price</td>
                <td class="text-right">Total</td>
              </tr>
            </thead>
            <tbody>


                          
                            
<?php
                    $count = 1;
                     foreach ($cart_data as $cart):
                    $cn = $count++;
                    $get_size = get_query_data('SELECT * FROM tbl_product_sizes where id = '.$cart['size_id'].'');

                    ?>

              <tr>
                <td><?php echo $cn; ?></td>
                <td class="text-center"><a href="#"><img class="img-thumbnail" style="width: 70px; height: 70px;" title="<?php echo $cart['name']; ?>" alt="<?php echo $cart['name']; ?>" src="<?php echo base_url($cart['product_image']); ?>"></a></td>

                <td class="text-left"><a href="#"><?php echo $cart['name']; ?></a></td>

                <td class="text-left"><div style="max-width: 200px;" class="input-group btn-block">
                  <form action="<?php echo base_url(); ?>home/update_quantity/<?php echo $cart['rowid'];?>" method = 'POST'>
                    <input type="number" id="cart_quantity" class="form-control quantity" size="1" value="<?php echo $cart['qty']; ?>" name="quantity">
                    <span class="input-group-btn">
                    <button class="btn btn-primary" title="" data-toggle="tooltip" type="submit" data-original-title="Update"><i class="fa fa-refresh"></i></button>
                    </form>
                    <a href="<?php echo base_url();?>home/remove_cart_item/<?php echo $cart['rowid'];?>" class="btn btn-danger" title="" data-toggle="tooltip" type="button" data-original-title="Remove" style="padding:8.5px 14px;"><i class="fa fa-times-circle"></i></a>
                    <!-- <button  ><i class="fa fa-times-circle"></i></button> -->
                    </span></div></td>
                <td class="text-right"><?php echo $get_size[0]->color; ?></td>
                <td class="text-right"><?php echo $get_size[0]->size; ?></td>
                <td class="text-right">PKR <?php echo $cart['price']; ?>.00</td>
                <td class="text-right">PKR <?php echo $cart['subtotal']; ?>.00</td>
              </tr>
              <?php endforeach; ?>


            </tbody>
          </table>
        </div>
      <h2>What would you like to do next?</h2>
      <p>Choose if you have a discount code or reward points you want to use or would like to estimate your delivery cost.</p>

      <div id="accordion" class="panel-group">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="panel-title"><a data-parent="#accordion" data-toggle="collapse" class="accordion-toggle" href="#collapse-coupon">Use Coupon Code <i class="fa fa-caret-down"></i></a></h4>
          </div>

          <div class="panel-collapse collapse" id="collapse-coupon">
            <form action="<?php echo base_url(); ?>home/discount_coupon/<?php echo $cart['rowid']; ?>" method="post">
            <div class="panel-body">
              <label for="input-coupon" class="col-sm-3 control-label">Enter your coupon here</label>
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Enter your coupon here" name="coupon" id="coupon" style="font-size: 15px;padding: 9px;">
                <span class="input-group-btn">
                <input type="submit" class="btn btn-primary" name="submit" data-loading-text="Loading..." id="button-coupon" value="Apply Coupon">
                </span>
              </div>
            </div>
          </form>
          
          </div>
          <?php 
                      if($cart['discount_coupon'] != ''){
                     ?>
                    <div class="row">
                      <div class="col-lg-6 col-md-6">
                            
                            <div class="coupon_code left">
                                <h3>Coupon</h3>
                                  <table class="table table-bordered">
                                    <thead>
                                      <tr>
                                        <th>Coupon</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td><?php echo $cart['discount_coupon']; ?></td>
                                        <td><?php echo $cart['discount_amount']; ?></td>
                                        <td><a href="<?php echo base_url();?>home/remove_discount_coupon/<?php echo $cart['rowid'];?>"><i class="fa fa-times-circle"></i></a></td>
                                      </tr>
                                    
                                    </tbody>
                                  </table>
                            </div>
                              
                        </div>
                      
                    </div>
                    <?php } ?>


        </div>

      </div>
      <br>
      <div class="row">
        <div class="col-sm-4 col-sm-offset-8">
          <table class="table table-bordered">
            <tbody>
              <tr>
                <td class="text-right"><strong>Sub-Total:</strong></td>
                <td class="text-right">PKR <?php echo $cart['subtotal']; ?>.00</td>
              </tr>
              <?php if($cart['discount_coupon'] != ''){ ?>
              <tr>
                <td class="text-right"><strong>Discount:</strong></td>
                <td class="text-right">PKR <?php echo $cart['discount_amount']; ?>.00</td>
              </tr>
              <?php } ?>

              <tr>
                <td class="text-right"><strong>Delivery:</strong></td>
                <td class="text-right">PKR <?php echo $cart['delivery_price']; ?>.00</td>
              </tr>
              <?php if($cart['delivery_price'] == 'Free'){
                                        $delivery_amount = 0;
                                       }
                                       else{
                                        $delivery_amount = $cart['delivery_price'];
                                       }
                                        ?>
              <tr>
                <td class="text-right"><strong>Total:</strong></td>
                <td class="text-right">PKR <?php echo $this->cart->total() + $delivery_amount - $cart['discount_amount']; ?>.00</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="buttons">
        <div class="pull-left"><a class="btn btn-default" href="<?php echo base_url('home'); ?>" style="line-height: 30px;">Continue Shopping</a></div>
        <div class="pull-right"><a class="btn btn-primary" href="<?php echo base_url('home/checkout'); ?>" style="line-height: 40px;">Checkout</a></div>
      </div>
    </div>
    </div>
</div>


















