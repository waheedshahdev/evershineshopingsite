<div class="container col-2" style="margin-top: 20px;">

    <?php 
    if($this->session->flashdata("error_msg") != ''){?>
       <div class="alert alert-danger">
           <button class="close" data-dismiss="alert"></button>
           <?php echo $this->session->flashdata("error_msg");?>
       </div>
       <?php
   }
   ?>
   <?php 
   if($this->session->flashdata("success") != ''){?>
       <div class="alert alert-success">
           <button class="close" data-dismiss="alert"></button>
           <?php echo $this->session->flashdata("success");?>
       </div>
       <?php
   }
   ?> 

   <div class="row">
    <?php include('side_bar.php'); ?>






    <div class="col-sm-9" id="content">



      <h1>Checkout</h1>
      <div id="accordion" class="panel-group">






        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="panel-title">Checkout Form</h4>
          </div>
          <div>
            <div class="panel-body">
                <?php foreach ($customer_data as $customer) {
                            # code...
                        } ?>
                        <?php foreach ($customer_shipping_data_2 as $customer_2) {
                            # code...
                        } ?>
              <form class="form-horizontal" action="<?php echo base_url('home/update_customer_shipping'); ?>" method="post">
                
               <!--  
                <div class="radio">
                  <label>
                    <input type="radio" checked="checked" value="new" name="payment_address" data-id="payment-new">
                    I want to use a new address</label>
                </div>
                <br> -->
                <!-- <div id="payment-new"  style="display: none;"> -->
                  <h4 style="color:#3fa9f5;">Step 1: Shipping Address</h4>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label for="input-payment-firstname" class="col-sm-4 control-label">First Name</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="input-payment-firstname" required="required" placeholder="First Name" value="<?php echo $customer->first_name; ?>" name="first_name">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label for="input-payment-lastname" class="col-sm-4 control-label">Last Name</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="input-payment-lastname" required="required" placeholder="Last Name" value="<?php echo $customer->last_name; ?>" name="last_name">
                        </div>
                      </div>
                    </div>
                  
                  <div class="col-md-6">
                    <div class="form-group required">
                      <label for="input-payment-address-1" class="col-sm-4 control-label">Complete Address</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="input-payment-address-1" required="required" placeholder="Address 1" value="<?php echo $customer->street_address; ?>" name="street_address">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group required">
                      <label for="input-payment-city" class="col-sm-4 control-label">City</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="input-payment-city" required="required" placeholder="City" value="<?php echo $customer->city; ?>" name="city">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group required">
                      <label for="input-payment-country" class="col-sm-4 control-label">Country</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="input-payment-Country" required="required" placeholder="Country" value="<?php echo $customer->country; ?>" name="country">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group required">
                      <label for="input-payment-zone" class="col-sm-4 control-label">Province</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="input-payment-postcode" required="required" placeholder="State" value="<?php echo $customer->state; ?>" name="state">
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group required">
                      <label for="input-payment-zone" class="col-sm-4 control-label">Phone</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="input-payment-postcode" required="required" placeholder="Phone" value="<?php echo $customer->phone; ?>" name="phone">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group required">
                      <label for="input-payment-zone" class="col-sm-4 control-label">Shipping & Billing Address Same?</label>
                      <div class="col-sm-8">
                        <select class="form-control" id="input-payment-postcode" required="required" name="shipping_address_same">
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                        </select>
                 
                      
                      </div>

                    </div>
                  </div>
                </div>
                  
                <!-- </div> -->
                <div class="buttons clearfix">
                  <div class="pull-right">
                    
                    <input type="submit" name="submit" value="Save Shipping Info" class="btn btn-primary" data-loading-text="Loading...">
                  </div>
                </div>
              </form>
              <script type="text/javascript">
                $('input[name=\'payment_address\']').on('change', function() {
                    if (this.value == 'new') {
                        $('#payment-existing').hide();
                        $('#payment-new').show();
                    } else {
                        $('#payment-existing').show();
                        $('#payment-new').hide();
                    }
                });

              </script>


              <hr style="margin: 30px;">


            <h4  style="color:#3fa9f5;">Step 2: Billing Details <span>(if different then shipping address.)</span></h4>
            <form class="form-horizontal" action="<?php echo base_url('home/update_customer_shipping'); ?>" method="post">
              <!--   <div class="radio">
                  <label>
                    <input type="radio" checked="checked" value="existing" name="shipping_address">
                    I want to use an existing address</label>
                </div>
                <div id="shipping-existing" >
                  <select class="form-control" name="address_id">
                    <option selected="selected" value="4">mahi mahi, dasd, adsasd, Al Hasakah, Syrian Arab Republic</option>
                  </select>
                </div>
                <div class="radio">
                  <label>
                    <input type="radio" value="new" name="shipping_address">
                    I want to use a new address</label>
                </div>
                <br> -->
                <div id="shipping-new" >
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label for="input-payment-firstname" class="col-sm-4 control-label">First Name</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="input-payment-firstname" required="required" placeholder="First Name" value="<?php echo $customer_2->first_name; ?>" name="first_name_2">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label for="input-payment-lastname" class="col-sm-4 control-label">Last Name</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="input-payment-lastname" required="required" placeholder="Last Name" value="<?php echo $customer_2->last_name; ?>" name="last_name_2">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label for="input-payment-address-1" class="col-sm-4 control-label">Address 1</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="input-payment-address-1" required="required" placeholder="Address 1" value="<?php echo $customer_2->street_address; ?>" name="street_address_2">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label for="input-payment-city" class="col-sm-4 control-label">City</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="input-payment-city" required="required" placeholder="City" value="<?php echo $customer_2->city; ?>" name="city">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label for="input-payment-country" class="col-sm-4 control-label">Country</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="input-payment-Country" required="required" placeholder="Country" value="<?php echo $customer_2->country; ?>" name="country_2">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label for="input-payment-zone" class="col-sm-4 control-label">Region / State</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="input-payment-postcode" required="required" placeholder="State" value="<?php echo $customer_2->state; ?>" name="state_2">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label for="input-payment-zone" class="col-sm-4 control-label">Phone</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="input-payment-postcode" required="required" placeholder="Phone" value="<?php echo $customer_2->phone; ?>" name="phone_2">
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  
                </div>
                <div class="buttons ">
                  <div class="pull-right">
                    <input type="submit" name="submit" value="Save Shipping Info 2" class="btn btn-primary" data-loading-text="Loading...">
                  </div>
                </div>
              </form>
              <script type="text/javascript">
                $('input[name=\'shipping_address\']').on('change', function() {
                    if (this.value == 'new') {
                        $('#shipping-existing').hide();
                        $('#shipping-new').show();
                    } else {
                        $('#shipping-existing').show();
                        $('#shipping-new').hide();
                    }
                });
              </script>


              <hr style="margin: 30px;">


              <h4  style="color:#3fa9f5;">Step 3: Delivery Method</h4>

              <form action="<?php echo base_url('home/checkout'); ?>" method="post" enctype='multipart/form-data'>

                <p>Please select the preferred shipping method to use on this order.</p>
                <p><strong>Flat Rate</strong></p>
                <div class="radio">
                  <label>
                    <input type="radio" checked="checked" value="flat.flat" name="shipping_method">
                    Flat Shipping Rate - $5.00</label>
                </div>
                <p><strong>Add Comments About Your Order</strong></p>
                <p>
                  <textarea class="form-control" rows="4" required="required" name="comment_about_order"></textarea>
                </p>



                <hr style="margin: 30px;">


              <h4  style="color:#3fa9f5;">Step 4: Payment Method</h4>
              <p>Please select the preferred payment method to use on this order.</p>
              <div class="radio">
                <label>
                  <input type="radio" checked="checked" value="Cash On Delivery" name="payment_method">
                  Cash On Delivery </label>&nbsp; &nbsp;
                  <label>
                  <input type="radio" value="Bank Transfer" name="payment_method">
                  Bank Transfer </label>&nbsp; &nbsp;
                  <label>
                  <input type="radio" value="Self-Pickup From AA" name="payment_method">
                  Self-Pickup From AA </label>&nbsp; &nbsp;
                  <label>
                  <input type="radio" value="Self-Pickup/Home Delivery" name="payment_method">
                  Self-Pickup/Home Delivery </label>
                  <input type="radio" value="Jazz Cash" name="payment_method">
                  Jazz Cash </label>
                  <input type="radio" value="Easypaisa" name="payment_method">
                  Easypaisa </label>
              </div>
              <br>
              <br>
              <div>
                <label><b>Note: if bank Tranfer please upload bank recept Mustly.</b></label>
                <input type="file" name="bank_receipt" class="form-control">
              </div>
              <!-- <p><strong>Add Comments About Your Order</strong></p> -->
              <!-- <p>
                <textarea class="form-control" rows="8" name="comment"></textarea>
              </p> -->
              <div class="buttons">
                <div class="pull-right">I have read and agree to the <a class="agree" href="#"><b>Terms &amp; Conditions</b></a>
                  <input type="checkbox" class="submit"  value="1" name="agree">
                  &nbsp;
                 <!--  <input type="button" class="btn btn-primary" data-loading-text="Loading..." id="button-payment-method" value="Continue"> -->
                </div>
              </div>



              <hr style="margin: 30px;">


              <h4  style="color:#3fa9f5;">Step 5: Confirm Order</h4>
              <div class="table-responsive">
                <table class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <td class="text-left">Product Name</td>
                      <td class="text-right">Quantity</td>
                      <td class="text-right">Unit Price</td>
                      <td class="text-right">Total</td>
                    </tr>
                  </thead>
                  <tbody>

                                       
                                    
                                    <?php foreach ($cart_data as $cart):?>
                    <tr>
                      <td class="text-left"><a href="#"><?php echo $cart['name']; ?></a></td>
                      <td class="text-right"><?php echo $cart['qty']; ?></td>
                      <td class="text-right">$<?php echo $cart['price']; ?>.00</td>
                      <td class="text-right">$<?php echo $cart['subtotal']; ?>.00</td>
                    </tr>
                    <?php endforeach; ?>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td class="text-right" colspan="4"><strong>Sub-Total:</strong></td>
                      <td class="text-right">$<?php echo $cart['subtotal']; ?>.00</td>
                    </tr>
                    <tr>
                      <td class="text-right" colspan="4"><strong>Flat Shipping Rate:</strong></td>
                      <td class="text-right">$5.00</td>
                    </tr>
                    <tr>
                      <td class="text-right" colspan="4"><strong>Total:</strong></td>
                      <td class="text-right">$<?php
                                                $total = $this->cart->total() + 5;
                                                $coupon = $cart['discount_coupon'];
                                                $amount = $cart['discount_amount'];
                                                $delivery_price = $cart['delivery_price'];
                                                if($delivery_price !='Free'){
                                                    $delivery = $delivery_price;
                                                }
                                                else{
                                                    $delivery = 0;
                                                }
                                                if($coupon == ''){
                                                    echo $total;
                                                }elseif ($coupon != '') {
                                                    $total = $total - $amount + $delivery + 5;
                                                    echo $total;
                                                }
                                              ?>.00</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
              <div class="buttons">
               
                    <input type="hidden" name="subtotal" value="<?php echo $cart['subtotal']; ?>">
                                <input type="hidden" name="promo_id" value="<?php echo $cart['discount_coupon']; ?>">
                                <input type="hidden" name="promo_discount" value="<?php echo $cart['discount_amount']; ?>">
                                <input type="hidden" name="delivery_price" value="<?php echo $cart['delivery_price']; ?>">
                                <input type="hidden" name="delivery_coupon" value="<?php echo $cart['delivery_coupon']; ?>">
                                <input type="hidden" name="order_grand_total" value="<?php $total = $this->cart->total() + 5;
                                                $coupon = $cart['discount_coupon'];
                                                $amount = $cart['discount_amount'];
                                                $delivery_price = $cart['delivery_price'];
                                                if($delivery_price !='Free'){
                                                    $delivery = $delivery_price;
                                                }
                                                else{
                                                    $delivery = 0;
                                                }
                                                if($coupon == ''){
                                                    echo $total;
                                                }elseif ($coupon != '') {
                                                    $total = $total - $amount + $delivery;
                                                    echo $total;
                                                } ?>">
                

                <div class="pull-right">



                  <button type="submit" name="proceed" data-loading-text="Loading..." class="btn btn-primary" id="button-confirm" value="Proceed to Checkout">Submit</button>
                </div>
               
              </div>




            </div>



          </div>
        </div>

        </form>





</div>


</div>










</div>
</div>


<script type="text/javascript">
    $(document).on('click','.submit',function(){
        
            if ($(this).is(":checked")) {
              
                $("#button-confirm").attr('disabled',false);
            } else {
               
                $("#button-confirm").attr('disabled',true);
            }
        }); 
</script>



























































