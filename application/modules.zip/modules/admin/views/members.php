


                    <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item active"><a href="#"><?php echo $title; ?></a></li>
                                    <!-- <li class="breadcrumb-item active" aria-current="page">Library</li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="text-right upgrade-btn">
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">

                <div class="row">
                    <!-- column -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!-- title -->
                                <div class="d-md-flex align-items-center">
                                    <div>
                                        <h4 class="card-title">Members</h4>
                                    </div>
                                    <div class="ml-auto">
                                        <div class="dl">
                                          <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Add Member</button>
                                        </div>
                                    </div>
                                </div>
                                <!-- title -->
                            </div>
                            <div class="table-responsive">
                                <table id="member_table" class="table v-middle">
                                    <thead>
                                        <tr class="bg-light">
                                        
                                            <th class="border-top-0">id</th>
                                            <th class="border-top-0">Member Code</th>
                                            <th class="border-top-0">Member Name</th>
                                            <th class="border-top-0">Member Email</th>
                                            <th class="border-top-0">PP</th>
                                            <th class="border-top-0">RP</th>
                                            <th class="border-top-0">Referral Code</th>
                                            <th class="border-top-0">Status</th>
                                            <th class="border-top-0">Created</th>
                                            <th class="border-top-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
<!-- Member Modal -->
<div class="container">
 

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          
          <h4 class="modal-title">Register Member</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
   
       
                    <div class="card">
                      
                        <div class="card-body">
                          
                      <form action="<?php echo base_url();?>admin/members" method="post" enctype="multipart/form-data">
                       <div class="form-group">
                          <label>Member Code</label>
                          <input type="text" value="<?php echo rand(000000,999999); ?>" class="form-control" name="member_code" id="member_code" readonly placeholder="Enter Member Code">
                      </div> 

                       <div class="form-group">
                          <label>Member Name</label>
                          <input type="text" class="form-control" name="member_name" id="member_name" placeholder="Enter Member Name" value="<?php echo $value->member_name;?>">
                      </div> 
                      <div class="form-group">
                          <label>Member Email</label>
                          <input type="email" class="form-control" name="member_email" id="member_email" placeholder="Enter Email" value="<?php echo $value->member_email;?>">
                      </div> 
                      <div class="form-group">
                          <label>Member password</label>
                          <input type="password" class="form-control" name="member_password" id="member_password" placeholder="Enter Password" value="<?php echo $value->member_password;?>">
                      </div> 

                       <div class="form-group">
                          <label>Referral Code (Optional)</label>
                          <input type="text" class="form-control" name="referal_person_code" id="referal_person_code" placeholder="Enter Referral Code" value="<?php echo $value->referal_person_code;?>">
                      </div> 

                       <div class="form-group">
                          <label>Member Type</label>
                          <select class="form-control" name="member_type" id="member_type" >
                            <option value="I am Referee">I am Referee</option>
                            <option value="Referee is in my downline">Referee is in my downline</option>
                          </select>
                      </div> 
                      
                      
                 
                      <div class="form-group">

                       
                          <input type="submit" name="submit" id="submit" value="Submit" class="btn btn-success">
                         
                      </div>


                    </form>
                        </div>
                    </div>
           


        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
<!-- END Member Modal -->
        
            </div>