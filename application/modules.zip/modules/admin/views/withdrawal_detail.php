





























                    <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item active"><a href="#"><?php echo $title; ?></a></li>
                                    <!-- <li class="breadcrumb-item active" aria-current="page">Library</li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="text-right upgrade-btn">
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
               <?php 
             if($this->session->flashdata("error_msg") != ''){?>
             <div class="alert alert-danger">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("error_msg");?>
             </div>
          <?php
            }
          ?>
          <?php 
             if($this->session->flashdata("success") != ''){?>
             <div class="alert alert-success">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("success");?>
             </div>
          <?php
            }
          ?>
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <!-- ============================================================== -->


                <!-- ============================================================== -->
                <!-- Table -->
                <!-- ============================================================== -->
                <button type="button" class="btn btn-success" style="text-align: right;"  data-toggle="modal" data-target="#myModal">Confirm Withdraw Request</button>
          
         <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <!-- Model -->


                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Withdrawal Info</strong>
                        </div>
                        <div class="card-body">
                 <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Withdrawal ID</th>
                    <th>Member Name</th>
                    <th>Withdrawal Mode</th>
                    <th>Withdrawal Amount</th>
                    <th>Withdrawal STATUS</th>
                  </tr>
                </thead>
                <tbody>
        
                </tbody>
                
                <tfoot>
                    <?php if(!empty($withdaw_data)){ 
                         
                        ?>
                    <tr>
                        <td><?php echo $withdaw_data[0]->w_id; ?></td>
                        <td><?php echo $withdaw_data[0]->member_name; ?></td>
                        <td><?php echo $withdaw_data[0]->withdrawal_mode; ?></td>
                        <td><?php echo $withdaw_data[0]->w_amount; ?></td>
                        <td><?php echo $withdaw_data[0]->w_status; ?></td>
                    </tr>
                    <?php } ?>
                    
                </tfoot>

              </table>
                        </div>
                    </div>
                </div>


                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Available Withdrawal Balance</strong>
                        </div>
                        <div class="card-body">
                 <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>Referal Amount</th>
                    <th>Incentives</th>
                    <th>Cancelation Charges</th>
                    <th>Level Earnings</th>
                    <th>Remaining Amount for Withdraw</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
                
                <tfoot>
                    <?php if(!empty($withdaw_data)){ 
                         
                        ?>
                    <tr>
                        <td><?php echo $withdaw_data[0]->rank_id; ?></td>
                        <td><?php echo $withdaw_data[0]->referal_amount; ?></td>
                        <td><?php echo $withdaw_data[0]->incentive_amount; ?></td>
                        <td><?php echo $withdaw_data[0]->cancelation_charges; ?></td>
                        <td><?php echo $withdaw_data[0]->level_earnings; ?></td>
                        <td><?php echo $withdaw_data[0]->remain_amount; ?></td>
                    </tr>
                    <?php } ?>
                    
                </tfoot>

              </table>
                        </div>
                    </div>
                </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->







                        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <!-- Model -->


                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                
                                <div class="d-md-flex align-items-center">
                                    <div>
                                        <h4 class="card-title"><?php echo $withdaw_data[0]->member_name; ?> Withdraw List</h4>
                                    </div>

                                </div>

                           

                                    <div class="transaction" id="div_id" style=" margin-top: 20px;">     
                                        <form action="<?php echo base_url('member/withdrawal') ?>" method="post" enctype="multipart/form-data">
                                               
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Select Withdrawal Mode:</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <select name="withdrawal_mode" class="form-control" id="withdrawal_mode">
                                                                <option>--Select Mode--</option>
                                                                <option value="Referral Point Bonus (RPB)" <?php if($withdaw_data[0]->withdrawal_mode == 'Referral Point Bonus (RPB)'){ echo 'selected = "selected"';} ?>>Referral Point Bonus (RPB)</option>
                                                                <option value="Incentive" <?php if($withdaw_data[0]->withdrawal_mode == 'Incentive'){ echo 'selected = "selected"';} ?>>Incentive</option>
                                                                <option value="RPB + Incentive Both" <?php if($withdaw_data[0]->withdrawal_mode == 'RPB + Incentive Both'){ echo 'selected = "selected"';} ?>>RPB + Incentive Both</option>
                                                            </select>
                                                        </div>
                                                    </div> 
                                                    <input type="hidden" name="earning_id" value="<?php echo $earnings[0]->id; ?>"> 
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Select Withdrawal Source:</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <select name="withdrawal_source" class="form-control" id="withdrawal_source">
                                                                <option>--Select Option--</option>
                                                                <option value="Bank Transfer" <?php if($withdaw_data[0]->withdrawal_source == 'Bank Transfer'){ echo 'selected = "selected"';} ?>>Bank Transfer</option>
                                                                <option value="Easypaisa Transfer" <?php if($withdaw_data[0]->withdrawal_source == 'Easypaisa Transfer'){ echo 'selected = "selected"';} ?>>Easypaisa Transfer</option>
                                                                <option value="JazzCash Transfer" <?php if($withdaw_data[0]->withdrawal_source == 'JazzCash Transfer'){ echo 'selected = "selected"';} ?>>JazzCash Transfer</option>
                                                                
                                                            </select>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Bank Details: Account Holder Name</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <input type="text" value="" name="account_holder" <?php if(isset($withdaw_data)){echo $withdaw_data[0]->account_holder;} ?> placeholder="Bank Details: Account Holder Name" class="form-control" id="account_holder">
                                                        </div>
                                                    </div>

                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">IBAN/Account#</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <input type="text" name="account_number" value="<?php if(isset($withdaw_data)){echo $withdaw_data[0]->account_number;} ?>"  placeholder="IBAN/Account#" class="form-control" id="account_number">
                                                        </div>
                                                    </div>
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Account Holder CNIC</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <input type="text" placeholder="Account Holder CNIC"   name="holder_cnic" value="<?php if(isset($withdaw_data)){echo $withdaw_data[0]->holder_cnic;} ?>"  class="form-control" id="holder_cnic">
                                                        </div>
                                                    </div>
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Mobile#</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <input type="number" placeholder="Enter Your Mobile#"  name="holder_mobile" value="<?php if(isset($withdaw_data)){echo $withdaw_data[0]->holder_mobile;} ?>"  class="form-control" id="holder_mobile">
                                                        </div>
                                                    </div>
                                                   
                                                    
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Withdrawal Badge Name:</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <textarea placeholder="Write Badge Name Here( If more than 1 then write e.g. Star, Scarlet Star, Novel)" name="badge_name" class="form-control" id="badge_name"><?php if(isset($withdaw_data)){echo $withdaw_data[0]->badge_name;} ?> </textarea>
                                                        
                                                        </div>
                                                    </div>

                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Note:</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <textarea placeholder="Write notes here" rows="6" cols="6" name="note" class="form-control" id="note"><?php if(isset($withdaw_data)){echo $withdaw_data[0]->note;} ?> </textarea>
                                                      
                                                        </div>
                                                    </div>
                                                 
                                                   
                                                    
                                                      

                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <!-- <input type="submit" name="Submit_request" value="Submit Request" class="btn btn-success"> -->
                                                        </div>
                                                </div>

                                           

                                        </form>
                                
                  
                                </div>
                            </div>
                      
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->



                     <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <!-- Model -->


                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Withdrawal Confirmation</strong>
                        </div>
                        <div class="card-body">
                 <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Withdrawal ID</th>
                    <th>Member Name</th>
                    <th>Withdrawal Mode</th>
                    <th>Withdrawal Amount</th>
                    <th>Withdrawal STATUS</th>
                  </tr>
                </thead>
                <tbody>
        
                </tbody>
                
                <tfoot>
                    <?php if(!empty($withdaw_data)){ 
                         
                        ?>
                    <tr>
                        <td><?php echo $withdaw_data[0]->w_id; ?></td>
                        <td><?php echo $withdaw_data[0]->member_name; ?></td>
                        <td><?php echo $withdaw_data[0]->withdrawal_mode; ?></td>
                        <td><?php echo $withdaw_data[0]->withdraw_amount; ?></td>
                        <td><?php echo $withdaw_data[0]->w_status; ?></td>
                    </tr>
                    <?php } ?>
                    
                </tfoot>

              </table>
                        </div>
                    </div>
                </div>



                </div>
            </div><!-- .animated -->
        </div><!-- .content -->







        </div><!-- .content -->



        <!-- change order status modal -->
        <div class="container">
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          
          <h4 class="modal-title">Withdrawal Request Confirmation</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>


        <div class="modal-body">
                              <div class="card">
                      
                        <div class="card-body">
                          
                      <form action="<?php echo base_url();?>admin/withdrawal_detail/<?php echo $this->uri->segment(3); ?>" method="post" enctype="multipart/form-data">
                       <div class="form-group">
                          <label>Withdrawal Date</label>
                          <input type="date" class="form-control" name="withdrawal_date" id="withdrawal_date" placeholder="Enter Withdrawal Date">
                      </div> 
                      <input type="hidden" name="w_amount" value="<?php echo $withdaw_data[0]->w_amount; ?>">
                      <input type="hidden" name="remain_amount" value="<?php echo $withdaw_data[0]->remain_amount; ?>">
                      <input type="hidden" name="earning_id" value="<?php echo $withdaw_data[0]->earning_id; ?>">
                      <input type="hidden" name="withdrawal_mode" value="<?php echo $withdaw_data[0]->withdrawal_mode; ?>">
                     
                       <div class="form-group">
                          <label>Withdrawal Status</label>
                          <select class="form-control" name="withdrawal_status" id="withdrawal_status" required>
                            <option value="Received">Received</option>
                            <option value="Approved">Approved</option>
                            <option value="Partial Paid">Partial Paid</option>
                            <option value="Record Update">Record Update</option>
                            <option value="Completed">Completed</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancel By Member">Cancel By Member</option>
                            <option value="Pending">Pending</option>
                            <option value="Waiting For Payment">Waiting For Payment</option>
                            <option value="Canceled By Company">Canceled By Company</option>
                          </select>
                      </div> 
                      <div class="form-group">
                          <label>Bank Receipt</label>
                          <input type="file" class="form-control" required="" name="bank_receipts" id="bank_receipts">
                      </div> 
                      <div class="form-group">
                          <label>Description</label>
                          <textarea class="form-control" name="company_description" id="company_description" placeholder="Enter Withdrawal Note" cols="5" rows="5"></textarea>
                      </div> 
                 
                      <div class="form-group">

                       
                          <input type="submit" name="submit_request" id="submit_request" value="Submit Request" class="btn btn-success">
                         
                      </div>


                    </form>
                        </div>
                    </div>



        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
        <!-- change order status modal -->



        
            </div>
