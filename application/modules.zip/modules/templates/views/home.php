<!DOCTYPE html>
<html lang="en">

<head>
<title>E-Commerce</title>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="e-commerce site well design with responsive view." />
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<!-- Slick CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>new_adminfiles/assets/slick/slick.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>new_adminfiles/assets/slick/slick-theme.css">
<link href="<?php echo base_url();?>new_adminfiles/assets/image/catalog/cart.html" rel="icon" />
<script src="<?php echo base_url();?>new_adminfiles/assets/javascript/jquery-2.1.1.min.js" type="text/javascript"></script>
<link href="<?php echo base_url();?>new_adminfiles/assets/css/bootstrap.min.css" rel="stylesheet" media="screen" />
<!-- -------- fontawesome 5 --------- -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />

<link href="<?php echo base_url();?>new_adminfiles/assets/javascript/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Roboto+Slab' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Arimo' rel='stylesheet' type='text/css'>
<link href="<?php echo base_url();?>new_adminfiles/assets/css/stylesheet.css" rel="stylesheet">
<link href="<?php echo base_url();?>new_adminfiles/assets/css/responsive.css" rel="stylesheet">
<link href="<?php echo base_url();?>new_adminfiles/assets/javascript/owl-carousel/owl.carousel.css" type="text/css" rel="stylesheet" media="screen" />
<link href="<?php echo base_url();?>new_adminfiles/assets/javascript/owl-carousel/owl.transitions.css" type="text/css" rel="stylesheet" media="screen" />
<link rel="stylesheet" href="<?php echo base_url();?>new_adminfiles/assets/css/headerstyle.css">
<link rel="stylesheet" href="<?php echo base_url();?>new_adminfiles/assets/css/magnific-popup.css">
<script src="<?php echo base_url();?>new_adminfiles/assets/javascript/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url();?>new_adminfiles/assets/javascript/template_js/jstree.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>new_adminfiles/assets/javascript/template_js/template.js"></script>
<script src="<?php echo base_url();?>new_adminfiles/assets/javascript/common.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>new_adminfiles/assets/javascript/global.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>new_adminfiles/assets/javascript/owl-carousel/owl.carousel.min.js" type="text/javascript"></script>
    <style>
        .blink {
        animation: blinker 0.9s linear infinite;
      }
      @keyframes blinker {
        50% {
          opacity: 0;
        }
      }
    </style>
</head>
<body>
<div class="preloader loader" style="display: block;"> <img style="width: 200px;" src="<?php echo base_url();?>new_adminfiles/assets/image/giphy.gif"  alt="#"/></div>
<div id="menu_wrapper"></div>
<header id="header" class="other">
    <div class="header-nav">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 center-nav">
              <p style="margin-top: 20px;font-weight:bold;animation: blinker 1s linear infinite !important;
    color: #ffd800 !important;">The World's 1st Website, Send You Videos of Each Product At the Time of Delivery.</p>
    <p style="margin-top: 20px;font-weight:bold;
    color: #ffd800 !important;">دنیا کی پہلی ویب سائٹ ، ڈلیوری کے وقت آپ کو ہر پروڈکٹ کے ویڈیوز بھیجتی ہے</p>
          </div>
          <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-nav">
            <div id="ishiheaderblock" class="clearfix">
              <div>

                <span>
                  
                  <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                    <symbol id="headphones" viewBox="0 0 990 990">
                      <title>headphones</title>
                      <path
                        d="M467.2,235.7c0-62.4-24.3-121.1-68.4-165.2S296,2.1,233.6,2.1S112.5,26.4,68.4,70.5S0,173.3,0,235.7v110.6 c0,62.5,50.9,113.4,113.4,113.4c7.5,0,13.5-6,13.5-13.5V246.5c0-7.5-6-13.5-13.5-13.5c-34.6,0-65.6,15.5-86.4,40v-37.3 c0-113.9,92.7-206.6,206.6-206.6s206.6,92.7,206.6,206.6c0,0.9,0.1,1.8,0.3,2.7c-0.2,0.9-0.3,1.8-0.3,2.7v37.3 c-20.8-24.5-51.8-40-86.4-40c-7.5,0-13.5,6-13.5,13.5v199.7c0,7.5,6,13.5,13.5,13.5c62.5,0,113.4-50.9,113.4-113.4V241.1 c0-0.9-0.1-1.8-0.3-2.7C467.1,237.5,467.2,236.6,467.2,235.7z M99.8,261v170.6c-41.2-6.5-72.9-42.3-72.9-85.3 C27,303.3,58.6,267.5,99.8,261z M367.4,437V266.4c41.2,6.5,72.9,42.3,72.9,85.3C440.2,394.8,408.6,430.5,367.4,437z">
                      </path>
                    </symbol>
                  </svg>
                  <svg class="icon" viewBox="0 0 50 50">
                    <use xlink:href="#whatsapp-logo-variant" x="23%" y="20%"></use>
                  </svg>
                </span> Whatsapp No (+92) 316-1822446 <h6 style="color: white;margin:0;">Ask Any Question, WE will Respond You ASAP</h6><h6 style="color: white;margin:0;">صبح 10 بجے سے دوپہر 2 بجے تک (پیر سے جمعرات جواب دیں گے کوئی سوال پوچھیں ، ہم جلد سے جلد آپ کا </h6>
              </div>
            </div>
          </div>
        
        </div>
      </div>
    </div>
    <div class="header-top">
      <div class="container">
        <div class="row">
          <div class="desktop-logo header-top-left col-lg-2 col-md-2 col-sm-4">
            <div id="logo">
              <a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>new_adminfiles/assets/image/mainLogo.png" title="Your Store"
                  alt="Your Store" class="img-responsive" /></a>
            </div>
          </div>
          <div class="header-top-right col-lg-10 col-md-10 col-sm-8">
            <div class="row">
              <div id="_desktop_seach_widget" class="col-lg-8 col-md-6">
                <div id="search_widget" class="search-widget" style="padding: 26px 15px;">
                  <div class="search-logo hidden-lg hidden-md">
                    <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                      <symbol id="magnifying-glass" viewBox="0 0 910 910">
                        <title>magnifying-glass</title>
                        <path
                          d="M495,466.2L377.2,348.4c29.2-35.6,46.8-81.2,46.8-130.9C424,103.5,331.5,11,217.5,11C103.4,11,11,103.5,11,217.5 S103.4,424,217.5,424c49.7,0,95.2-17.5,130.8-46.7L466.1,495c8,8,20.9,8,28.9,0C503,487.1,503,474.1,495,466.2z M217.5,382.9 C126.2,382.9,52,308.7,52,217.5S126.2,52,217.5,52C308.7,52,383,126.3,383,217.5S308.7,382.9,217.5,382.9z" />
                      </symbol>
                    </svg>
                    <svg class="icon" viewBox="0 0 30 30">
                      <use xlink:href="#magnifying-glass" x="22%" y="20%"></use>
                    </svg>
                  </div>
                  <form>
                    <div id="search" class="input-group">
                      <div class="searchboxform">
                        <select name="category_id" class="ishicategory-select hidden-sm hidden-xs">
                          <option value="0">All Categories</option>
                           <?php foreach ($categories as $cat):?>
                            <option value="<?php echo $cat->id; ?>"><?php echo $cat->category_name; ?></option>
                      
                    <?php endforeach; ?>
                     
                        </select>
                      </div>
                      <input id="ajax-search-text" type="text" name="search" value="" placeholder="Search"
                        class="form-control input-lg" />
                      <div class="ajaxishi-search" style="display: none;">
                        <ul></ul>
                      </div>
                      <button id="ajax-search-btn" type="button" class="btn btn-default btn-lg"><i
                          class="fa fa-search"></i></button>
                    </div>

                    <script>
                      (function () {
                        document.getElementById('ajax-search-text').addEventListener('keypress', function (event) {
                          if (event.keyCode == 13) {
                            event.preventDefault();
                            document.getElementById('ajax-search-btn').click();
                          }
                        });
                      }());
                    </script>
                  </form>
                </div>
              </div>
              <div class="wrapper-right col-lg-4 col-md-6 col-sm-12" style="text-align: right;">
                <div class="contact-num">
                  <a href="<?php echo base_url('member/login'); ?>" class="btn btn-info">
                    
                    Register As A Member
                  </a>
                </div>
                <div id="_desktop_user_info">
                  <div class="user-info">
                    <div class="dropdown">
                      <a class="dropdown-toggle" data-toggle="dropdown">
                        <span class="account-logo expand-more hidden-sm hidden-xs">
                          <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                            <symbol id="account" viewBox="0 0 850 850">
                              <title>account</title>
                              <path
                                d="m512 256c0-141.488281-114.496094-256-256-256-141.488281 0-256 114.496094-256 256 0 140.234375 113.539062 256 256 256 141.875 0 256-115.121094 256-256zm-256-226c124.617188 0 226 101.382812 226 226 0 45.585938-13.558594 89.402344-38.703125 126.515625-100.96875-108.609375-273.441406-108.804687-374.59375 0-25.144531-37.113281-38.703125-80.929687-38.703125-126.515625 0-124.617188 101.382812-226 226-226zm-168.585938 376.5c89.773438-100.695312 247.421876-100.671875 337.167969 0-90.074219 100.773438-247.054687 100.804688-337.167969 0zm0 0" />
                              <path
                                d="m256 271c49.625 0 90-40.375 90-90v-30c0-49.625-40.375-90-90-90s-90 40.375-90 90v30c0 49.625 40.375 90 90 90zm-60-120c0-33.085938 26.914062-60 60-60s60 26.914062 60 60v30c0 33.085938-26.914062 60-60 60s-60-26.914062-60-60zm0 0" />
                            </symbol>
                          </svg>
                          <svg class="icon" viewBox="0 0 30 30">
                            <use xlink:href="#account" x="22%" y="22%"></use>
                          </svg>
                        </span>
                        <span class="account-logo expand-more hidden-lg hidden-md">
                          <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                            <symbol id="user" viewBox="0 0 980 980">
                              <title>user</title>
                              <path
                                d="m275.565 275.565c-75.972 0-137.783-61.81-137.783-137.783s61.811-137.782 137.783-137.782 137.783 61.81 137.783 137.783-61.811 137.782-137.783 137.782zm0-241.119c-56.983 0-103.337 46.353-103.337 103.337s46.353 103.337 103.337 103.337 103.337-46.354 103.337-103.337-46.354-103.337-103.337-103.337z" />
                              <path
                                d="m499.461 551.13h-447.793c-9.52 0-17.223-7.703-17.223-17.223v-118.558c0-17.795 9.099-34.513 23.732-43.663 129.339-80.682 305.554-80.665 434.759-.017 14.649 9.166 23.749 25.885 23.749 43.679v118.558c0 9.521-7.703 17.224-17.224 17.224zm-430.57-34.445h413.348v-101.336c0-6.004-2.893-11.555-7.552-14.464-118.256-73.819-279.905-73.87-398.26.017-4.642 2.893-7.535 8.443-7.535 14.448z" />
                            </symbol>
                          </svg>
                          <svg class="icon" viewBox="0 0 30 30">
                            <use xlink:href="#user" x="22%" y="20%"></use>
                          </svg>
                        </span>
                        <span class="account-name expand-more hidden-sm hidden-xs"><?php if($this->session->userdata('customer_id') != ''){ echo $this->session->userdata('first_name'); }else{ echo 'Account';} ?> </span>
                      </a>
                      <ul class="dropdown-menu dropdown-menu-right">
                        <?php $customer_id = $this->session->userdata('customer_id');
                            if(empty($customer_id) || $customer_id == ''){
                              ?>
                              <li><a href="<?php echo base_url('home/login/customer_dashboard'); ?>"><i class="fa fa-sign-in"></i> Customer Login</a></li>
                          <li>
                          <!-- <a href="<?php //echo base_url('home/login/?account=register'); ?>"><i class="fa fa-user"></i> Register</a> -->
                          <a href="<?php echo base_url('member/login'); ?>" target="_black"><i class="fa fa-user"></i> Member Login</a>
                        </li>
                        

                              <?php
                            } elseif (!empty($customer_id) || $customer_id !='') {?>
                               <li><a href="<?php echo base_url('home/account'); ?>"><i class="fa fa-user"></i> Account</a>
                               <!-- <li><a href="<?php //echo base_url('home/customer_orders'); ?>"><i class="fa fa-user"></i> Previous Orders</a> -->
                        </li>
                        <li><a href="<?php echo base_url('home/logout'); ?>"><i class="fa fa-sign-in"></i> Logout</a></li>
                          <?php  }
                         ?>
                        
                        <!-- <li><a href="indexe223.html?route=account/wishlist" id="wishlist-total"
                            title="Wish List (0)"><i class="fa fa-heart"></i> <span class="wishlist-text">Wish List
                              (0)</span></a></li> -->
                      </ul>
                    </div>
                  </div>
                </div>


                
                <div id="_desktop_cart" style="padding: 0;">

                  <style type="text/css">
                  #wishlist{
                        float: left;
                        padding-left: 23%;
                        padding-top: 3%;
                  }
                  #wishlist i{
                    font-size: 25px;
                  }
                  #wishlist i:hover{
                    color:#3fa9f5;
                    cursor: pointer;
                  }
                  #wishlist span:hover i{
                    color:#fedb22;
                  }
                  #wishlist span:hover{
                    cursor: pointer;
                  }
                  #wishlist span {
                    padding-left: 15px;
                    font-size: 14px;
                    line-height: 18px;
                    font-weight: 500;
                    margin-top: -15px;
                    font-family: system-ui;
                  }
                </style>

                <div id="wishlist">
                  <i class="fa fa-heart-o"></i><span>Wishlist Empty!</span>
                </div>


                  <div class="blockcart" style="border-left: 1px solid #263242;padding-left: 16px;padding-right: 16px;padding-top: 10px;">
                    <div id="cart" class="btn-group btn-block">
                      <button type="button" data-loading-text="Loading..." class="btn btn-inverse btn-block btn-lg">
                        <span class="cart-link">
                          <span class="cart-img hidden-sm hidden-xs">
                            <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                              <symbol id="Capa_1" viewBox="0 0 395 395">
                                <title>Capa_1</title>
                                <path
                                  d="M306.4,313.2l-24-223.6c-0.4-3.6-3.6-6.4-7.2-6.4h-44.4V69.6c0-38.4-31.2-69.6-69.6-69.6c-38.4,0-69.6,31.2-69.6,69.6v13.6H46c-3.6,0-6.8,2.8-7.2,6.4l-24,223.6c-0.4,2,0.4,4,1.6,5.6c1.2,1.6,3.2,2.4,5.2,2.4h278c2,0,4-0.8,5.2-2.4C306,317.2,306.8,315.2,306.4,313.2z M223.6,123.6c3.6,0,6.4,2.8,6.4,6.4c0,3.6-2.8,6.4-6.4,6.4c-3.6,0-6.4-2.8-6.4-6.4C217.2,126.4,220,123.6,223.6,123.6z M106,69.6c0-30.4,24.8-55.2,55.2-55.2c30.4,0,55.2,24.8,55.2,55.2v13.6H106V69.6zM98.8,123.6c3.6,0,6.4,2.8,6.4,6.4c0,3.6-2.8,6.4-6.4,6.4c-3.6,0-6.4-2.8-6.4-6.4C92.4,126.4,95.2,123.6,98.8,123.6z M30,306.4L52.4,97.2h39.2v13.2c-8,2.8-13.6,10.4-13.6,19.2c0,11.2,9.2,20.4,20.4,20.4c11.2,0,20.4-9.2,20.4-20.4c0-8.8-5.6-16.4-13.6-19.2V97.2h110.4v13.2c-8,2.8-13.6,10.4-13.6,19.2c0,11.2,9.2,20.4,20.4,20.4c11.2,0,20.4-9.2,20.4-20.4c0-8.8-5.6-16.4-13.6-19.2V97.2H270l22.4,209.2H30z" />
                              </symbol>
                            </svg>
                            <svg class="icon" viewBox="0 0 30 30">
                              <use xlink:href="#Capa_1" x="10%" y="9%"></use>
                            </svg>
                          </span>
                          <span class="cart-img hidden-lg hidden-md">
                            <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                              <symbol id="shopping-cart-empty-side-view" viewBox="0 0 740 740">
                                <title>shopping-cart-empty-side-view</title>
                                <path
                                  d="M444.274,93.36c-2.558-3.666-6.674-5.932-11.145-6.123L155.942,75.289c-7.953-0.348-14.599,5.792-14.939,13.708 c-0.338,7.913,5.792,14.599,13.707,14.939l258.421,11.14L362.32,273.61H136.205L95.354,51.179 c-0.898-4.875-4.245-8.942-8.861-10.753L19.586,14.141c-7.374-2.887-15.695,0.735-18.591,8.1c-2.891,7.369,0.73,15.695,8.1,18.591 l59.491,23.371l41.572,226.335c1.253,6.804,7.183,11.746,14.104,11.746h6.896l-15.747,43.74c-1.318,3.664-0.775,7.733,1.468,10.916 c2.24,3.184,5.883,5.078,9.772,5.078h11.045c-6.844,7.617-11.045,17.646-11.045,28.675c0,23.718,19.299,43.012,43.012,43.012 s43.012-19.294,43.012-43.012c0-11.028-4.201-21.058-11.044-28.675h93.777c-6.847,7.617-11.047,17.646-11.047,28.675 c0,23.718,19.294,43.012,43.012,43.012c23.719,0,43.012-19.294,43.012-43.012c0-11.028-4.2-21.058-11.042-28.675h13.432 c6.6,0,11.948-5.349,11.948-11.947c0-6.6-5.349-11.948-11.948-11.948H143.651l12.902-35.843h216.221 c6.235,0,11.752-4.028,13.651-9.96l59.739-186.387C447.536,101.679,446.832,97.028,444.274,93.36z M169.664,409.814 c-10.543,0-19.117-8.573-19.117-19.116s8.574-19.117,19.117-19.117s19.116,8.574,19.116,19.117S180.207,409.814,169.664,409.814z M327.373,409.814c-10.543,0-19.116-8.573-19.116-19.116s8.573-19.117,19.116-19.117s19.116,8.574,19.116,19.117 S337.916,409.814,327.373,409.814z" />
                              </symbol>
                            </svg>
                            <svg class="icon" viewBox="0 0 30 30">
                              <use xlink:href="#shopping-cart-empty-side-view" x="22%" y="20%"></use>
                            </svg>
                          </span>
                          <?php 
                                $this->load->library('cart');
                                $cart_data = $this->cart->contents();
                                if (empty($cart_data)){ ?>

                                      <span class="cart_quantity" style="color: white;">Cart Empty!</span>
                                <?php } elseif (!empty($cart_data)) {
                                    $count == 0;
                                    foreach ($cart_data as $cart) {
                                        $count++;
                                    }
                                    ?>


         


                          <span class="cart-content">
                            <a href="<?php echo base_url('home/cart'); ?>"><a href="<?php echo base_url('home/cart'); ?>"><span class="cart-products-count hidden-sm hidden-xs"><span class="cart-name">Cart</span> (<?php echo $count; ?>)</span></a></a>
                            <span class="cart-products-count hidden-lg hidden-md">0</span>
                          </span>
                          <?php } ?>
                        </span>
                      </button>
                      <ul class="cart-dropdown">
                        <li>
                          <p class="empty text-left">Your shopping cart is empty!</p>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>







              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.top-container {
  background-color: #f1f1f1;
  padding: 30px;
  text-align: center;
}

.header {
  padding: 10px 16px;
  z-index: 2;
  color: #f1f1f1;
}

.content {
  padding: 16px;
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 102px;
}
</style>

    <div class="nav-full-width header" id="myHeader" style="padding-top: 12px;">
      <div class="container">
        <div class="row">

          <div id="_desktop_top_menu" class="menu js-top-menu hidden-xs hidden-sm pl-0">
            <h2 class="home-title hidden-xs hidden-sm">Categories</h2>
            <div class="wrapper-menu">
              <div class="line-menu half start"></div>
              <div class="line-menu"></div>
              <div class="line-menu half end"></div>
            </div>
            <ul id="top-menu" class="top-menu" data-depth="0">







              


              <?php foreach ($categories as $categ):

                            $sub_cat = get_query_data('SELECT * FROM tbl_sub_category where category_id = '.$categ->id.'');
                            if(!empty($sub_cat)){
                                ?>

                                

                                

                                  


                                    <li class="top_level_category dropdown">
                <a class="dropdown-item" href="<?php echo base_url('home/products/'.$categ->id.''); ?>"><?php echo $categ->category_name; ?>
                  <i class="fa fa-angle-right add hidden-xs hidden-sm"></i>
                </a>
                <span class="pull-xs-right hidden-md hidden-lg">
                  <span data-target="#top_sub_menu_9300" data-toggle="collapse" class="navbar-toggler collapse-icons">
                    <i class="fa fa-angle-down add"></i>
                    <i class="fa fa-angle-up remove"></i>
                  </span>
                </span>
                <div id="top_sub_menu_9300" class="dropdown-menu popover sub-menu collapse">
                  <ul class="list-unstyled childs_1 category_dropdownmenu  multiple-dropdown-menu " data-depth="1">

                    <li class="category dropdown sub-category">
                      <a class="dropdown-item dropdown-submenu"
                        href="indexd9fe.html?route=product/category&amp;path=20_26">Sub Category</a>
                      <span class="pull-xs-right hidden-md hidden-lg">
                        <span data-target="#top_sub_menu_7995" data-toggle="collapse"
                          class="navbar-toggler collapse-icons">
                          <i class="fa fa-angle-down add"></i>
                          <i class="fa fa-angle-up remove"></i>
                        </span>
                      </span>
                      <div id="top_sub_menu_7995" class="dropdown-inner collapse">
                        <ul class="list-unstyled childs_2 top-menu" data-depth="2">
                          <?php foreach ($sub_cat as $value) {?>
                          <li class="category">
                            <a class="dropdown-item"
                              href="<?php echo base_url('home/products/'.$categ->id.'/'.$value->id.''); ?>"><?php echo $value->sub_category_name; ?></a>
                          </li>
                          <?php }
                                    

                                    ?>
                         
                        </ul>
                      </div>
                    </li>
                  </ul>
                  
                  
                </div>
              </li>                                
                      

                                <?php
                            }
                            else {?>
                      
                        <li class="maintitle"><a href="<?php echo base_url('home/products/'.$categ->id.''); ?>"><?php echo $categ->category_name; ?></a></li>
                   
                            <?php }

                            ?>


                        
                        
                        <?php endforeach;?>






            </ul>
          </div>
          <!-- <div id="menu-icon" class="menu-icon hidden-md hidden-lg">
            <i class="fa fa-bars" aria-hidden="true"></i>
          </div> -->
          <div id="_mobile_cart"></div>
          <div id="_mobile_user_info"></div>
          <div id="_mobile_seach_widget"></div>
          <div id="_mobile_link_menu"></div>



          <script type="text/javascript">
            $("#_desktop_top_menu").click(function () {
              $("#top-menu").slideToggle();
              $('.wrapper-menu').toggleClass('open');
            });
          </script>
                <nav id="menu" class="navbar">
                    <div class="nav-inner container">
                        <div class="navbar-header"><span id="category" class="visible-xs">Categories</span>
                            <button type="button" class="btn btn-navbar navbar-toggle" ><i class="fa fa-bars"></i></button>
                        </div>
                        <div class="navbar-collapse" style="width: 63%;">
                            <ul class="main-navigation">
                                <li><a href="<?php echo base_url('home'); ?>"   class="parent"  >Home</a> </li>
                                <li><a href="<?php echo base_url('aboutus'); ?>">About us</a></li>
                                <li><a href="<?php echo base_url('home/products'); ?>"   class="parent"  >Sell On ZSM</a> </li>
                                <li><a href="<?php echo base_url('home/products'); ?>"   class="parent"  >News & Updates</a> </li>
                                <li><a href="<?php echo base_url('home/products'); ?>"   class="parent"  >Shop</a> </li>
                                <li><a href="<?php echo base_url('home/products'); ?>"   class="parent"  >Summer Sale</a> </li>
                                <li><a href="<?php echo base_url('home/products'); ?>"   class="parent"  >Winter Sale</a> </li>
                                <li><a href="<?php echo base_url('home/products'); ?>"   class="parent"  >New Arrivals</a> </li>

                              <!--   <li><a href="#" class="active parent">Page</a>
                                    <ul>
                                        <li><a href="category.html">Category Page</a></li>
                                        
                                        <li><a href="checkout.html">Checkout Page</a></li>
                                        
                                        <li><a href="register.html">Register Page</a></li>
                                        <li><a href="<?php echo base_url('home/contactus'); ?>">Contact Page</a></li>
                                    </ul>
                                </li> -->
                                <!-- <li><a href="blog.html" class="parent"  >Blog</a></li> -->
                                
                                <li><a href="<?php echo base_url('contactus'); ?>" >Contact Us</a> </li>
                                
                            </ul>
                        </div>
                        <div id="ishioffersblock" style="width: 21%;">
                            <div class="offer-title" style=""> Special Offers! </div>
                            <p class="blink" style="padding: 6px 0px 0px 0; color: white;">Flat 25% Off All Purchase</p>
                           
                            <span id="typed"></span>
                           
                          </div>
                    </div>
                </nav>
          

        </div>
      </div>
    </div>
</header>



<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>


<?php if(isset($view_files))

          $this->load->view($view_module.'/'.$view_files);

       ?>




<footer>
  <div id="WAButton"></div>
    <div class="container">
        <div class="footer-top-cms">
            <div class="footer-logo"> <a href="<?php echo base_url();?>"><img style="width: 130px;"  alt="index.php" src="<?php echo base_url();?>new_adminfiles/assets/image/logo-footer.png"></a> </div>
            <div class="footer-desc"> <span>Zealous Smart Marketing Also Know As ZSM is Online Marketplace. We Deal In All Kind of Products With Best Price, Secure Payments & Fast Delivery At Your Doorstep. <br> Join Us To Become Smart By Our Vision "Steo Towards Smartness." </span> </div>
            <div class="footer-social">
                <h5>Social</h5>
                <ul>
                    <li class="facebook"><a href="https://m.facebook.com/ZSM_Zealous-Smart-Marketing-111662467327413/"><i class="fa fa-facebook"></i></a></li>
                    <li class="linkedin"><a href="https://www.instagram.com/invites/contact/?i=1cl61eyuxyst1&utm_content=i3870p9"><i class="fa fa-instagram"></i></a></li>
                   
                    <li class="gplus"><a href="#"><i class="fab fa-tiktok"></i></a></li>
                    <li class="youtube"><a href="https://youtube.com/channel/UCzzPMMJ8D22GEV0yYg1U6Yg"><i class="fa fa-youtube-play"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2 footer-block">
                <h5 class="footer-title">Information</h5>
                <ul class="list-unstyled ul-wrapper">
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="checkout.php">Delivery Information</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms &amp; Conditions</a></li>
                    <li><a href="#">Why We are Different from Other Marketing Platforms???</a></li>
                </ul>
            </div>
            <div class="col-sm-2 footer-block">
                <h5 class="footer-title">Customer Service</h5>
                <ul class="list-unstyled ul-wrapper">
                    <li><a href="<?php echo base_url('home/contactus'); ?>">Contact Us</a></li>
                    <li><a href="#">Returns</a></li>
                    <li><a href="#">Exchange & Returns</a></li>
                    <li><a href="#">Wish List</a></li>
                </ul>
            </div>
            <div class="col-sm-2 footer-block">
                <h5 class="footer-title">ZSM</h5>
                <ul class="list-unstyled ul-wrapper">
                    <li><a href="#">Want to Make Money From ZSM</a></li>
                    <li><a href="#">Want to become member</a></li>
                    <li><a href="#">Want to Sell On ZSM</a></li>
                    <li><a href="#">Want to become Vendor</a></li>
                  
                </ul>
            </div>
            <div class="col-sm-2 footer-block">
                <h5 class="footer-title">Extras</h5>
                <ul class="list-unstyled ul-wrapper">
                    <li><a href="#">Brands</a></li>
                    <li><a href="gift.html">Gift Vouchers</a></li>
                    <li><a href="affiliate.html">Affiliates</a></li>
                    <li><a href="#">Specials</a></li>
                </ul>
            </div>
            <div class="col-sm-2 footer-block">
                <div class="content_footercms_right">
                    <div class="footer-contact">
                        <h5 class="contact-title footer-title">Contact Us</h5>
                        <ul class="ul-wrapper">
                            <!-- <li><i class="fa fa-map-marker"></i><span class="location2"> Warehouse & Offices,<br>
                                12345 Street name, California<br>
                                USA</span></li> -->
                            <!-- <li><i class="fa fa-envelope"></i><span class="mail2"><a href="#">info@localhost.com</a></span></li> -->
                            <li><i class="fa fa-mobile"></i><span class="phone2">(+92) 316-1822446</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a id="scrollup">Scroll</a> 
</footer>
<div class="footer-bottom">
    <div class="container">
        <div class="copyright">Powered By<a class="yourstore">ZSMPK &copy; 2021 </a> </div>
        <div class="footer-bottom-cms">
            <div class="footer-payment">
                <ul>
                    <li class="mastero"><a href="#"><img alt="" src="<?php echo base_url();?>new_adminfiles/assets/image/payment/jazz.jpg"></a></li>
                    <li class="visa"><a href="#"><img alt="" src="<?php echo base_url();?>new_adminfiles/assets/image/payment/easypaisa.jpg"></a></li>
                    <!-- <li class="currus"><a href="#"><img alt="" src="<?php echo base_url();?>new_adminfiles/assets/image/payment/currus.jpg"></a></li>
                    <li class="discover"><a href="#"><img alt="" src="<?php echo base_url();?>new_adminfiles/assets/image/payment/discover.jpg"></a></li>
                    <li class="bank"><a href="#"><img alt="" src="<?php echo base_url();?>new_adminfiles/assets/image/payment/bank.jpg"></a></li> -->
                </ul>
            </div>
        </div>
    </div>
</div>


<!--Jquery-->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script> -->
<!--Floating WhatsApp css-->
<link rel="stylesheet" href="<?php echo base_url();?>new_adminfiles/assets/whatsapp/floating-wpp.min.css">
<!--Floating WhatsApp javascript-->
<script type="text/javascript" src="<?php echo base_url();?>new_adminfiles/assets/whatsapp/floating-wpp.min.js"></script>

<script type="text/javascript">
  $(function() {
  $('#WAButton').floatingWhatsApp({
    phone: '1231231231', //WhatsApp Business phone number International format-
    //Get it with Toky at https://toky.co/en/features/whatsapp.
    headerTitle: 'Chat with us on WhatsApp!', //Popup Title
    popupMessage: 'Hello, how can we help you?', //Popup Message
    showPopup: true, //Enables popup display
    buttonImage: '<img src="https://rawcdn.githack.com/rafaelbotazini/floating-whatsapp/3d18b26d5c7d430a1ab0b664f8ca6b69014aed68/whatsapp.svg" />', //Button Image
    //headerColor: 'crimson', //Custom header color
    //backgroundColor: 'crimson', //Custom background button color
    position: "right"    
  });
});
</script>



<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script type="text/javascript">
    $(document).ready(function(){

        $('.add_to_cart').click(function(){

          var cart_product_id = $('#cart_product_id').val();
          var cart_qty = parseInt($('#cart_qty').val());
           var product_name = $(this).data('product_name');
           var product_price = $(this).data('product_price');
           var product_id = $(this).data('product_id');
           var quantity = parseInt($('#product_quantity').val());
           var size_id = $('#size').val();
           var check_qty = parseInt($('#qty_check').val());
           var product_image = $(this).data('product_image');
           var p_info_id = $(this).data('p_info_id');

            // alert(cart_qty);
                // 10      <=  34


                if(cart_product_id == product_id){
                    checking_cart_qty = cart_qty;
                  }else{
                    checking_cart_qty = 0;
                  }


                if(cart_qty == '' || cart_qty == 0){
                  total_used_qty = quantity;

                }
                else{
                  total_used_qty = checking_cart_qty + quantity;
                }

                
              // alert(total_used_qty);
         
              if(quantity  <= check_qty){

                 if(quantity !=''  && quantity > 0)
           {
              if(total_used_qty <= check_qty){


                $.ajax({
                    url: '<?php echo base_url();?>home/cart',
                    method: 'POST',
                    data:{product_id:product_id, product_name:product_name, product_price:product_price, quantity:quantity,product_image:product_image,size_id:size_id,p_info_id:p_info_id},
                    success:function(data){

                        // alert('Product Added to Cart');
                             Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: 'Product Added to Cart Successfully!',
                                
                              })
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                     
                    }

                });

                }
            else{
              alert('Product is Out of Stock or maybe already in cart');
            }


           }
           else{

            alert('Please Enter Quantity');
           }




           }
           else{
            alert('Not Enough stock. Please select right quantity');
           }

            

           

           // alert(quantity);
      


        });

    });

 
        // Member wishlist
        $(document).ready(function(){

        $('.wishlist').click(function(){


           var product_id = $(this).data('product_id');
        
                $.ajax({
                    url: '<?php echo base_url();?>home/add_to_wishlist',
                    method: 'POST',
                    data:{product_id:product_id},
                    success:function(data){
//e.preventDefault();
    // your code here
   // return false;
     Swal.fire({
  icon: 'success',
  title: 'Success',
  text: 'Product Added to Wishlist!',
  
})
                         // alert('Product Added to Cart');
                        
                        // $('#cart_detail').html(data);
                        // top.location.href="<?php// echo base_url();?>member/products";//redirection
                    }

                });
         

        });

    });

    // END member wishlist
    /////// Zeeshan Project Frontpage modal //////////////

    $(document).on('click','.home_modal', function(){

var id= $(this).attr('id');
var dollar_sign = '$';
  $.ajax({
    url: "<?php echo base_url(). 'home/fetch_product_data'?>",
    method: 'post',
    data: {id:id},
    dataType: 'json',
    success:function(data){
      console.log(data);
      $.each(data, function(key, value){
        product_name = value.product_name;
        new_price = value.new_price;
        price = value.price;
        description = value.description;
        sub_image = value.sub_image;
        store_sub_item_id = value.id;
      })

      // if(sub_image == '')
      // {

      // }

      $('#product_name').html(product_name);
      $('#new_price').html(new_price);
      $('#price').html(price);
      $('#description').html(description);
      $('#sub_image').html(sub_image);
      // $('#store_sub_item_id').val(store_sub_item_id);

    $('#modal_box1').modal('show');



    }

  })



});

    $(document).on('change','#size', function(){

  var size = $('#size').val();
  var product_id = $('#product_id').val();
  // var size_name = $(this).data('size_name');
// alert(size_name);
  if(size !=''){
    $.ajax({
      url: '<?php echo base_url();?>home/fetch_size',
      method: 'post',
      data: {size:size,product_id:product_id},
      success:function(data){
        
       $('#color').html(data);
       // alert(data);

      }

    })  

  }


});

            $(document).on('change','#size', function(){

  var size = $('#size').val();
  var product_id = $('#product_id').val();
  // var size_name = $(this).data('size_name');
// alert(size_name);
  if(size !=''){
    $.ajax({
      url: '<?php echo base_url();?>home/fetch_stock',
      method: 'post',
      data: {size:size,product_id:product_id},
      success:function(data){
        
       $('#stock').html(data);
       // alert(data);

      }

    })  

  }


});
    // END stock
</script>


  <script src="<?php echo base_url();?>new_adminfiles/assets/slick/slick.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    $(document).on('ready', function() {
      $(".vertical-center-4").slick({
        dots: true,
        vertical: true,
        centerMode: true,
        slidesToShow: 4,
        slidesToScroll: 2
      });
      $(".vertical-center-3").slick({
        dots: true,
        vertical: true,
        centerMode: true,
        slidesToShow: 3,
        slidesToScroll: 3
      });
      $(".vertical-center-2").slick({
        dots: true,
        vertical: true,
        centerMode: true,
        slidesToShow: 2,
        slidesToScroll: 2
      });
      $(".vertical-center").slick({
        dots: true,
        vertical: true,
        centerMode: true,
      });
      $(".vertical").slick({
        dots: true,
        vertical: true,
        slidesToShow: 3,
        slidesToScroll: 3
      });
      $(".regular").slick({
        dots: true,
        infinite: true,
        autoplay:true,
        centerMode: true,
        slidesToShow: 5,
        slidesToScroll: 1
      });
      $('.multiple-items').slick({
        infinite: true,
        slidesToShow: 2,
        slidesToScroll: 1
      });
      $(".center").slick({
        dots: true,
        infinite: true,
        autoplay:true,
        centerMode: true,
        slidesToShow: 1,
        slidesToScroll: 1
      });
      $(".variable").slick({
        dots: true,
        infinite: true,
        variableWidth: true
      });
      $(".lazy").slick({
        lazyLoad: 'ondemand', // ondemand progressive anticipated
        infinite: true
      });
    });
</script>


</body>

</html>
