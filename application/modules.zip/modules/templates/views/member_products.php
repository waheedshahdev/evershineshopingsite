<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Product Grid View || Sellshop</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">

        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
		<!-- google fonts -->
		<link href='https://fonts.googleapis.com/css?family=Lato:400,900,700,300' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Bree+Serif' rel='stylesheet' type='text/css'>
		<!-- all css here -->
		<!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>member_product_assets/css/bootstrap.min.css">
		<!-- animate css -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>member_product_assets/css/animate.css">
		<!-- pe-icon-7-stroke -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>member_product_assets/css/materialdesignicons.min.css">
		<!-- pe-icon-7-stroke -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>member_product_assets/css/jquery.simpleLens.css">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>member_product_assets/css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>member_product_assets/css/meanmenu.min.css">
		<!-- nivo.slider css -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>member_product_assets/css/nivo-slider.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>member_product_assets/css/owl.carousel.css">
		<!-- style css -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>member_product_assets/style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>member_product_assets/css/responsive.css">
		<!-- modernizr js -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- header section start -->
		<header class="header-one header-two header-page">
			<div class="header-top-two">
				<div class="container text-center">
					<div class="row">
						<div class="col-sm-12">
							<div class="middel-top">
								<div class="left floatleft">
									<p><i class="mdi mdi-clock"></i> Mon-Fri : 09:00-19:00</p>
								</div>
							</div>
							<div class="middel-top clearfix">
								<ul class="clearfix right floatright">
									
									<li>
										<a href="#"><i class="mdi mdi-settings"></i></a>
										<ul>
											<li><a href="<?php echo base_url('member/profile'); ?>">My account</a></li>
											<li><a href="<?php echo base_url('member/new_cart'); ?>">My cart</a></li>
											<li><a href="<?php echo base_url('member/wishlist'); ?>">My wishlist</a></li>
											<li><a href="<?php echo base_url('member/checkout'); ?>">Check out</a></li>
										</ul>
									</li>
								</ul>
								<div class="right floatright">
									<form action="#" method="get">
										<button type="submit"><i class="mdi mdi-magnify"></i></button>
										<input type="text" placeholder="Search within these results..." />
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="container text-center">
				<div class="row">
					<div class="col-sm-2">
						<!-- <div class="logo">
							<a href="index.html"><img src="<?php// echo base_url(); ?>member_product_assets/img/logo2.png" alt="Sellshop" /></a>
						</div> -->
					</div>
					<div class="col-sm-8">
						<div class="header-middel">
							<div class="mainmenu">
								<nav>
									<ul>
										
										<li><a href="<?php echo base_url('member'); ?>">Dashboard</a></li>
										<li><a href="<?php echo base_url('member/products'); ?>">Products</a></li>
									</ul>
								</nav>
							</div>
							<!-- mobile menu start -->
						
						</div>
					</div>
					<div class="col-sm-2">
						<div class="cart-itmes">
							<a class="cart-itme-a" href="<?php echo base_url('member/new_cart'); ?>">
								<i class="mdi mdi-cart"></i>
								<strong>pkr <?php $this->load->library('cart');  echo $this->cart->total(); ?>.00</strong>
							</a>
							<div class="cartdrop">
									<?php  
            							$cart_data = $this->cart->contents(); 
            							foreach ($cart_data as $cart):
            							?>
								<div class="sin-itme clearfix">
									<a href="<?php echo base_url();?>member/remove_cart_item/<?php echo $cart['rowid'];?>"><i class="mdi mdi-close"> </i></a>
									<a class="cart-img" href="<?php echo base_url('member/new_cart'); ?>"><img src="<?php echo base_url($cart['product_image']); ?>" alt="" /></a>
									<div class="menu-cart-text">
										<a href="#"><h5><?php echo $cart['name']; ?></h5></a>
										<!-- <span>Color :  <?php //echo $cart['name']; ?></span> -->
										<span>QTY :     <?php echo $cart['qty']; ?></span>
										<span>CV :     <?php echo $cart['cv']; ?></span>
										<strong><?php echo $cart['price']; ?>.00</strong>
									</div>
								</div>
							<?php endforeach; ?>

								<div class="total">
									<span>total <strong>= <?php echo $this->cart->total(); ?>.00</strong></span>
								</div>
								<a class="goto" href="<?php echo base_url('member/new_cart'); ?>">go to cart</a>
								<a class="out-menu" href="<?php echo base_url('member/checkout'); ?>">Check out</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
        <!-- header section end -->


     <?php if(isset($view_files))

          $this->load->view($view_module.'/'.$view_files);

       ?>



        
		<!-- all js here -->
		<!-- jquery latest version -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/vendor/jquery-1.12.3.min.js"></script>
		<!-- bootstrap js -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/bootstrap.min.js"></script>
		<!-- owl.carousel js -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/owl.carousel.min.js"></script>
		<!-- meanmenu js -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/jquery.meanmenu.js"></script>
		<!-- countdown JS -->
        <!-- <script src="<?php //echo base_url(); ?>member_product_assets/js/countdown.js"></script> -->
		<!-- nivo.slider JS -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/jquery.nivo.slider.pack.js"></script>
		<!-- simpleLens JS -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/jquery.simpleLens.min.js"></script>
		<!-- jquery-ui js -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/jquery-ui.min.js"></script>
		<!-- load-more js -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/load-more.js"></script>
		<!-- plugins js -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/plugins.js"></script>
		<!-- main js -->
        <script src="<?php echo base_url(); ?>member_product_assets/js/main.js"></script>
         <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js" ></script>
        <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
           <script type="text/javascript">
    // start users list




    $(document).ready(function(){

        $('.add_to_cart_member').click(function(){

          var cart_product_id = $('#cart_product_id').val();
           var cart_qty = parseInt($('#cart_qty').val());
           var product_name = $(this).data('product_name');
           var product_price = $(this).data('product_price');
           var product_id = $(this).data('product_id');
           var cv = $(this).data('no_of_cv');
           var size_id = $('#size').val();
           var quantity = parseInt($('#product_quantity').val());
           var product_image = $(this).data('product_image');
           var check_qty = parseInt($('#qty_check').val());
           var p_info_id = $(this).data('p_info_id');
                // 10      <=  34
      		

      		if(cart_product_id == product_id){
      			checking_cart_qty = cart_qty;
      		}else{
      			checking_cart_qty = 0;
      		}
         

            if(cart_qty == '' || cart_qty == 0){
                  total_used_qty = quantity;

                }
                else{
                  total_used_qty = checking_cart_qty + quantity;
                }


         		
              if(quantity  <= check_qty){

                 if(quantity !=''  && quantity > 0)
           {

   // alert(cart_product_id);

              if(total_used_qty <= check_qty || total_used_qty == ''){


                $.ajax({
                    url: '<?php echo base_url();?>member/add_cart',
                    method: 'POST',
                    data:{product_id:product_id,cv:cv,product_name:product_name, product_price:product_price, quantity:quantity,product_image:product_image,size_id:size_id,p_info_id:p_info_id},
                    success:function(data){

                        // alert('Product Added to Cart');
                             Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: 'Product Added to Cart Successfully!',
                                
                              })
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                     
                    }

                });

                }
            else{
              alert('Product is Out of Stock or maybe already in cart');
            }


           }
           else{

            alert('Please Enter Quantity');
           }




           }
           else{
            alert('Not Enough stock. Please select right quantity');
           }

            

           

           // alert(quantity);
      


        });

    });












    // Member wishlist
        $(document).ready(function(){

        $('.wishlist').click(function(){


           var product_id = $(this).data('product_id');
        
                $.ajax({
                    url: '<?php echo base_url();?>member/add_to_wishlist',
                    method: 'POST',
                    data:{product_id:product_id},
                    success:function(data){
					//e.preventDefault();
					    // your code here
					   // return false;
					     Swal.fire({
					  icon: 'success',
					  title: 'Success',
					  text: 'Product Added to Wishlist!',
					  
					})
                         // alert('Product Added to Cart');
                        
                        // $('#cart_detail').html(data);
                        // top.location.href="<?php// echo base_url();?>member/products";//redirection
                    }

                });
         

        });

    });

    // END member wishlist




//////////// Add user DropDown //////////////////
$(document).on('change','#size', function(){

  var size = $('#size').val();
  var product_id = $('#product_id').val();
  // var size_name = $(this).data('size_name');
// alert(size_name);
  if(size !=''){
    $.ajax({
      url: '<?php echo base_url();?>member/fetch_size',
      method: 'post',
      data: {size:size,product_id:product_id},
      success:function(data){
        
       $('#color').html(data);
       // alert(data);

      }

    })  

  }


});

///////////// END add User DropDown ////////////
            $(document).on('change','#size', function(){

  var size = $('#size').val();
  var product_id = $('#product_id').val();
  // var size_name = $(this).data('size_name');
// alert(size_name);
  if(size !=''){
    $.ajax({
      url: '<?php echo base_url();?>home/fetch_stock',
      method: 'post',
      data: {size:size,product_id:product_id},
      success:function(data){
        
       $('#stock').html(data);
       // alert(data);

      }

    })  

  }


});
    // END stock

    $(document).ready(function(){

 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search == '')
  {
   
  }
  else
  {
   $('#search_result').html('');
        $.ajax({
           url:"<?php echo base_url(). 'member/fetch_member_search'?>",
           method:"POST",
           data:{search:search},
           dataType: 'text',
           success:function(data)
           {
            $('#search_result').html(data);
           }
          });

  }
 });
});

    </script>
    </body>
</html>
