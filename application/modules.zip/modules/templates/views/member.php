




<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords"
        content="">
    <meta name="description"
        content="Xtreme Admin Lite is powerful and clean admin dashboard template, inpired from Bootstrap Framework">
    <meta name="robots" content="noindex,nofollow">
    <title>Ibad Project | Member Area</title>
    <link rel="canonical" href="" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url(); ?>new_adminfiles/assets/image/favicon.png">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <!-- Custom CSS -->
    <link href="<?php echo base_url(); ?>new_adminfiles/assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url(); ?>new_adminfiles/assets/dist/css/style.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>new_adminfiles/assets/dist/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url();?>adminfiles/assets/css/lib/datatable/dataTables.bootstrap.min.css">
    <!-- <link rel="stylesheet" href="<?php //echo base_url();?>new_adminfiles/assets/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="<?php echo base_url();?>new_adminfiles/assets/css/stylesheet.css">
    <link rel="stylesheet" href="<?php echo base_url();?>new_adminfiles/assets/css/headerstyle.css">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style type="text/css">
         #product_img img{
                                    width: 100%;
                                    height: 250px;
                                }
                                #product_img p{
                                    margin-bottom: 0px;
                                }
                                #product_img i{
                                    font-family: 'Font Awesome 5 Free';
                                }
                                #product_img button{
                                    margin-top: 3%;
                                    background: red;
                                }
                                #product_img button:hover{
                                    background: black;
                                    border-color: black;
                                }
                                #product_img span{
                                    color: green;
                                    font-weight: bold;
                                }
                              
                                .overlay {
                                  position: absolute;
                                  top: 0;
                                  bottom: 0;
                                  left: 0;
                                  right: 0;
                                  height: 100%;
                                  width: 100%;
                                  opacity: 0;
                                  transition: .3s ease;
                                  background-color: white;
                                }
                                /* When you mouse over the container, fade in the overlay icon*/
                                .col-md-3:hover .overlay {
                                  opacity: 0.8;
                                }
                              
                                .icon {
                                  color: white;
                                  font-size: 100px;
                                  position: absolute;
                                  top: 50%;
                                  left: 50%;
                                  transform: translate(-50%, -50%);
                                  -ms-transform: translate(-50%, -50%);
                                  text-align: center;
                                }

                                .fa-user:hover {
                                  color: #eee;
                                }
    </style>
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <a class="navbar-brand" href="<?php echo base_url('member'); ?>">
                        <!-- Logo icon -->
                        <b class="logo-icon">
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            <img src="<?php echo base_url(); ?>new_adminfiles/assets/image/logo-icon.png" alt="homepage" class="dark-logo" />
                            <!-- Light Logo icon -->
                            <img src="<?php echo base_url(); ?>new_adminfiles/assets/image/logo-light-icon.png" alt="homepage" class="light-logo" />
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text -->
                        <span class="logo-text">
                            <!-- dark Logo text -->
                            <img src="<?php echo base_url(); ?>new_adminfiles/assets/image/logo-text.png" alt="homepage" class="dark-logo" />
                            <!-- Light Logo text -->
                            <img src="<?php echo base_url(); ?>new_adminfiles/assets/image/logo-light-text.png" class="light-logo" alt="homepage" />
                        </span>
                    </a>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i
                            class="ti-menu ti-close"></i></a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-left mr-auto">
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                        <li class="nav-item search-box"> <a class="nav-link waves-effect waves-dark"
                                href="javascript:void(0)"><i class="ti-search fa-1x"></i></a>
                            <form class="app-search position-absolute">
                                <input style="height: 65px;" type="text" class="form-control" placeholder="Search &amp; enter"> <a
                                    class="srh-btn"><i class="ti-close"></i></a>
                            </form>
                        </li>
                    </ul>
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-right">
                    
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="<?php echo base_url('member/products'); ?>" aria-expanded="false"><span style="font-size: 15px;">Shop</span> </a>
                            
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="<?php echo base_url('member/cart'); ?>" style="color: white;"><i class="fa fa fa-2x fa-shopping-cart"></i></a>
                            
                        </li>
                        <!-- ============================================================== -->
                        
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url(); ?>new_adminfiles/assets/image/users/1.jpg" alt="user" class="rounded-circle" width="31"></a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated flipInY">
                                <span class="with-arrow"><span class="bg-primary"></span></span>
                                <div class="d-flex no-block align-items-center p-15 bg-primary text-white mb-2">
                                    <div class=""><img src="<?php echo base_url(); ?>new_adminfiles/assets/image/users/1.jpg" alt="user" class="img-circle" width="60"></div>
                                    <div class="ml-2">
                                        <h4 class="mb-0"><?php echo $this->session->userdata('member_name');?></h4>
                                        <p class=" mb-0"><?php echo $this->session->userdata('member_email');?></p>
                                    </div>
                                </div>
                                <a class="dropdown-item" href="<?php echo base_url('member/profile'); ?>"><i class="ti-user mr-1 ml-1"></i> My Profile</a>
                                <a class="dropdown-item" href="javascript:void(0)"><i class="ti-wallet mr-1 ml-1"></i> My Balance</a>
                                <a class="dropdown-item" href="javascript:void(0)"><i class="ti-email mr-1 ml-1"></i> Inbox</a>
                                <div class="dropdown-divider"></div>
                                <!-- <a class="dropdown-item" href="javascript:void(0)"><i class="ti-settings mr-1 ml-1"></i> Account Setting</a> -->
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo base_url('member/logout'); ?>"><i class="fa fa-power-off mr-1 ml-1"></i> Logout</a>
                                <div class="dropdown-divider"></div>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <!-- User Profile-->
                        <li>
                            <!-- User Profile-->
                            <div class="user-profile d-flex no-block dropdown m-t-20">
                                <div class="user-pic"><img src="<?php echo base_url(); ?>new_adminfiles/assets/image/users/1.jpg" alt="users"
                                        class="rounded-circle" width="40" /></div>
                                <div class="user-content hide-menu m-l-10">
                                    <a href="javascript:void(0)" class="" id="Userdd" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <h5 class="m-b-0 user-name font-medium">Member <i
                                                class="fa fa-angle-down"></i></h5>
                                        <span class="op-5 user-email"><?php echo $this->session->userdata('member_name'); ?></span>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="Userdd">
                                        <a class="dropdown-item" href="<?php echo base_url('member/profile'); ?>"><i
                                                class="ti-user m-r-5 m-l-5"></i> My Profile</a>
                                        <!-- <a class="dropdown-item" href="javascript:void(0)"><i
                                                class="ti-wallet m-r-5 m-l-5"></i> My Balance</a>
                                        <a class="dropdown-item" href="javascript:void(0)"><i
                                                class="ti-email m-r-5 m-l-5"></i> Inbox</a> -->
                                        <!-- <div class="dropdown-divider"></div> -->
                                        <!-- <a class="dropdown-item" href="javascript:void(0)"><i
                                                class="ti-settings m-r-5 m-l-5"></i> Account Setting</a> -->
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="<?php echo base_url('member/logout'); ?>"><i
                                                class="fa fa-power-off m-r-5 m-l-5"></i> Logout</a>
                                    </div>
                                </div>
                            </div>
                            <!-- End User Profile-->
                        </li>
                        
                        <!-- User Profile-->
                        <li class="sidebar-item selected"> 
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo base_url('member'); ?>" aria-expanded="false">
                                <i class="mdi mdi-view-dashboard"></i>
                                <span class="hide-menu">Dashboard </span>
                            </a>
                        </li>
                        <li class="sidebar-item selected"> 
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo base_url('member/products'); ?>" aria-expanded="false">
                                <i class="fa fa fa-shopping-cart"></i>
                                <span class="hide-menu">Shop </span>
                            </a>
                        </li>
                        <li class="sidebar-item selected"> 
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo base_url('member/orders'); ?>" aria-expanded="false">
                                <i class="fa fa-usd"></i>
                                <span class="hide-menu">Orders </span>
                            </a>
                        </li>
                        <li class="sidebar-item selected"> 
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo base_url('member/team'); ?>" aria-expanded="false">
                                <i class="fa fa-users"></i>
                                <span class="hide-menu">Referals </span>
                            </a>
                        </li>
                        <li class="sidebar-item selected"> 
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo base_url('member/ranking'); ?>" aria-expanded="false">
                                <i class="fa fa-bar-chart"></i>
                                <span class="hide-menu">Badges </span>
                            </a>
                        </li>
                        <li class="sidebar-item selected"> 
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo base_url('member/wishlist'); ?>" aria-expanded="false">
                                <i class="fa fa-bar-chart"></i>
                                <span class="hide-menu">Wishlist </span>
                            </a>
                        </li>
                        <!-- <li class="sidebar-item selected"> 
                            <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
                                <i class="mdi mdi-border-all"></i>
                                <span class="hide-menu">Network </span>
                            </a>
                             <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item active"><a href="" class="sidebar-link"><i class="mdi mdi-adjust"></i><span class="hide-menu"> Genealogy tree </span></a></li>
                                <li class="sidebar-item active"><a href="" class="sidebar-link"><i class="mdi mdi-adjust"></i><span class="hide-menu"> Add New Member </span></a></li>
                                <li class="sidebar-item active"><a href="" class="sidebar-link"><i class="mdi mdi-adjust"></i><span class="hide-menu"> Downlines </span></a></li>
                            </ul>
                        </li> -->
                        <li class="sidebar-item"> 
                            <a class="sidebar-link has-arrow waves-effect waves-dark active" href="javascript:void(0)" aria-expanded="false">
                                <i class="fa fa-credit-card"></i>
                                <span class="hide-menu">E-Wallet </span>
                            </a>
                             <ul aria-expanded="false" class="collapse first-level in">
                                <li class="sidebar-item active"><a href="" class="sidebar-link"><i class="mdi mdi-adjust"></i><span class="hide-menu"> Summary </span></a></li>
                                <li class="sidebar-item"><a href="" class="sidebar-link"><i class="mdi mdi-adjust"></i><span class="hide-menu"> Transactions </span></a></li>
                                <li class="sidebar-item"><a href="<?php echo base_url('member/withdrawal'); ?>" class="sidebar-link"><i class="mdi mdi-adjust"></i><span class="hide-menu"> Withdrawal </span></a></li>
                                <li class="sidebar-item"><a href="" class="sidebar-link"><i class="mdi mdi-adjust"></i><span class="hide-menu"> Earning & Incentives </span></a></li>
                            </ul>
                        </li>
                        <li class="sidebar-item"> 
                            <a class="sidebar-link has-arrow waves-effect waves-dark active" href="javascript:void(0)" aria-expanded="false">
                                <i class="fa fa-thumbs-o-up"></i>
                                <span class="hide-menu">Promotion Tools </span>
                            </a>
                             <ul aria-expanded="false" class="collapse first-level in">
                                <li class="sidebar-item active"><a href="" data-toggle="modal" data-target="#myModal" class="sidebar-link"><i class="mdi mdi-adjust"></i><span class="hide-menu"> Referral Links </span></a></li>
                            </ul>
                        </li>
                        <li class="sidebar-item"> 
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo base_url('member'); ?>" aria-expanded="false">
                                <i class="fa fa-cogs"></i>
                                <span class="hide-menu">Settings </span>
                            </a>
                        </li>
                        <li class="sidebar-item"> 
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo base_url('member/logout'); ?>" aria-expanded="false">
                                <i class="fa fa-sign-out"></i>
                                <span class="hide-menu">Logout </span>
                            </a>
                        </li>
                    </ul>

                </nav>
                <!-- End Sidebar navigation -->                
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        








     




<div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
   <?php if(isset($view_files))

          $this->load->view($view_module.'/'.$view_files);

       ?>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center">
                All Rights Reserved by Zeeshan. Designed and Developed by <a
                    href="">Zeeshan</a>.
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>


        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
       <script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
    
    <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
    <script src="<?php echo base_url(); ?>new_adminfiles/assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo base_url(); ?>new_adminfiles/assets/libs/popper.js/dist/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>new_adminfiles/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>new_adminfiles/assets/dist/js/app-style-switcher.js"></script>
    <!--Wave Effects -->
    <script src="<?php echo base_url(); ?>new_adminfiles/assets/dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?php echo base_url(); ?>new_adminfiles/assets/dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo base_url(); ?>new_adminfiles/assets/dist/js/custom.js"></script>
    <!--This page JavaScript -->
    <!--chartis chart-->
    <script src="<?php echo base_url(); ?>new_adminfiles/assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="<?php echo base_url(); ?>new_adminfiles/assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="<?php echo base_url(); ?>new_adminfiles/assets/dist/js/pages/dashboards/dashboard1.js"></script>
        <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js" ></script>
        <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script type="text/javascript">
    // start users list


    // add shop

      // $(document).on('submit','#add_shop',function(event){
      //       event.preventDefault();
      //       var shop_name = $('#shop_name').val();
      //       var shop_phone = $('#shop_phone').val();
      //       var shop_password = $('#shop_password').val();
      //       var shop_email = $('#shop_email').val();
      //       var shop_address = $('#shop_address').val();
      //       var shop_image = $('#shop_image').val();

                     
      //           $.ajax({
      //               url: "<?php echo base_url();?>admin/add_shop",
      //               method: 'POST',
      //               data: new FormData(this),
      //               contentType: false,
      //               processData: false,
      //               success: function(data)
      //               {
                        
      //                   //alert(data);
      //                   location.reload();
      //                    $('#add_shop')[0].reset();
      //                   // var id = $('#vendor_id').val();
      //                   // location.href = '<?php echo base_url();?>admin/update_vendor/'+id;
      //               }
      //           });
          

      //   });





        // add shop product

      // $(document).on('submit','#withdrawal_request',function(event){
      //       event.preventDefault();
      //       var withdrawal_mode = $('#withdrawal_mode').val();
      //       var withdrawal_source = $('#withdrawal_source').val();
      //       var account_holder = $('#account_holder').val();
      //       var account_number = $('#account_number').val();
      //       var holder_cnic = $('#holder_cnic').val();
      //       var holder_mobile = $('#holder_mobile').val();
      //       var badge_name = $('#badge_name').val();
      //       var note = $('#note').val();
      //       var submit = $('#submit').val();



      //          if(confirm('Are you sure you want to Request for Withdrawal?')){
      //           $.ajax({
      //               url: "<?php //echo base_url();?>member/withdrawal",
      //               method: 'POST',
      //               data: new FormData(this),
      //               contentType: false,
      //               processData: false,
      //               success: function(data)
      //               {
                        
      //                   alert(data);
                      
      //               }
      //           });
      //          }
      //          else{
      //           return false;
      //          }      
                
          

      //   });


//       $(function() {
//     $("#submit_checkout").submit(function(event) {


//         $('.check_conditions').click(function(){
//             shipping_phone = $('#shipping_phone').val();
//             shipping_country = $('#shipping_country').val();
//             shipping_city = $('#shipping_city').val();
//             shipping_state = $('#shipping_state').val();
//             shipping_street = $('#shipping_street').val();
//             shipping_address = $('#shipping_address').val();
//             shipping_zip = $('#shipping_zip').val();


//             if(shipping_phone == '' || shipping_country == '' || shipping_city == '' || shipping_state == '' || shipping_street == '' || shipping_address == '' || shipping_zip == ''){

//                 alert('Shipping address Fields are Required');
//                 return false;
//             }
//             else{
//                 // $('#submit_checkout').submit();
//                   document.getElementById("submit_checkout").submit();

//                 // alert('we are here');
//             }

         

//         });

//     });

// });
$(document).on('click','#request_withdrawal', function(){

   // $('.transaction').show();
const targetDiv = document.getElementById("div_id");
const btn = document.getElementById("request_withdrawal");
btn.onclick = function () {
  if (targetDiv.style.display !== "none") {
    targetDiv.style.display = "none";
  } else {
    targetDiv.style.display = "block";
  }
};



});

    function p_m(){
        var p = $('#payment_meth').val();
        if (p=='Cash on Delivery') {
          
            $('#img').removeAttr('required');


        }else{
           $('#img').attr('required', 'required');
        }
    }
    $(document).ready(function(){

        $('.add_to_cart_member').click(function(){

           var cart_product_id = $('#cart_product_id').val();
           var cart_qty = parseInt($('#cart_qty').val());
           var product_name = $(this).data('product_name');
           var product_price = $(this).data('product_price');
           var product_id = $(this).data('product_id');
           var cv = $(this).data('no_of_cv');
           var size_id = $('#size').val();
           var quantity = $('#product_quantity').val();
           var product_image = $(this).data('product_image');
           var check_qty = parseInt($('#qty_check').val());
           var p_info_id = $(this).data('p_info_id');

           alert(cv);

           

                if(cart_product_id == product_id){
                    checking_cart_qty = cart_qty;
                  }else{
                    checking_cart_qty = 0;
                  }

                  if(cart_qty == '' || cart_qty == 0){
                  total_used_qty = quantity;

                }
                else{
                  total_used_qty = checking_cart_qty + quantity;
                }



                alert(check_qty);
                 if(quantity  <= check_qty){

                if(quantity !=''  && quantity > 0)
                {

                    if(total_used_qty <= check_qty){







                                    $.ajax({
                    url: '<?php echo base_url();?>member/add_cart',
                    method: 'POST',
                    data:{product_id:product_id,cv:cv,product_name:product_name, product_price:product_price, quantity:quantity,product_image:product_image,size_id:size_id,p_info_id:p_info_id},
                    success:function(data){
//e.preventDefault();
    // your code here
   // return false;
                         Swal.fire({
                      icon: 'success',
                      title: 'Success',
                      text: 'Product Added to Cart Successfully!',
                      
                    })
                                             // alert('Product Added to Cart');
                        
                        // $('#cart_detail').html(data);
                        // top.location.href="<?php// echo base_url();?>member/products";//redirection
                    }

                });


                     }
            else{
              alert('Product is Out of Stock or maybe already in cart');
            }












                }
               else{

                alert('Please Enter Quantity');
               }


                }
                   else{
                    alert('Not Enough stock. Please select right quantity');
                   }
           


        });

    });













    // Member wishlist
        $(document).ready(function(){

        $('.wishlist').click(function(){


           var product_id = $(this).data('product_id');
        
                $.ajax({
                    url: '<?php echo base_url();?>member/add_to_wishlist',
                    method: 'POST',
                    data:{product_id:product_id},
                    success:function(data){
//e.preventDefault();
    // your code here
   // return false;
     Swal.fire({
  icon: 'success',
  title: 'Success',
  text: 'Product Added to Wishlist!',
  
})
                         // alert('Product Added to Cart');
                        
                        // $('#cart_detail').html(data);
                        // top.location.href="<?php// echo base_url();?>member/products";//redirection
                    }

                });
         

        });

    });

    // END member wishlist




        // Order list
    var tbl_category;
    $(document).ready(function(){ 
        var member_id = '<?php echo $this->session->userdata('member_code'); ?>';
      tbl_category = $('#order_table').DataTable({  
           "processing":true,  
           "serverSide":true,  
           "order":[],  
           "ajax":{  
                url:"<?php echo base_url() . 'member/order_list/'; ?>"+member_id,  
                type:"POST"  
           },  
           "columnDefs":[  
                {  
                     "targets":[0, 3, 4],  
                     "orderable":false,  
                },  
           ],  
      });  
 });
    // END order list
//////////// Add user DropDown //////////////////
$(document).on('change','#size', function(){

  var size = $('#size').val();
  var product_id = $('#product_id').val();
  // var size_name = $(this).data('size_name');
// alert(size_name);
  if(size !=''){
    $.ajax({
      url: '<?php echo base_url();?>member/fetch_size',
      method: 'post',
      data: {size:size,product_id:product_id},
      success:function(data){
        
       $('#color').html(data);
       // alert(data);

      }

    })  

  }


});

///////////// END add User DropDown ////////////

    </script>
</body>

</html>
