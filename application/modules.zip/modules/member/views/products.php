
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo $title; ?></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <style type="text/css">
                        .search-widget{
                            padding:0;
                        }
                        #search:focus .btn-lg:focus{
                            outline: none !important;
                        }
                        #search:focus .btn-lg:active{
                            outline: none !important;
                        }
                        .search-widget form button:focus{
                            outline: none !important;
                        }
                    </style>
                    <div class="col-7" style="text-align: right;">
                        <div id="search_widget" class="search-widget">
                          <div class="search-logo hidden-lg hidden-md">
                            <svg class="icon" viewBox="0 0 30 30">
                              <use xlink:href="#magnifying-glass" x="22%" y="20%"></use>
                            </svg>
                          </div>
                          <form>
                            <div id="search" class="input-group">
                              <div class="searchboxform">
                                <select name="category_id" class="ishicategory-select hidden-sm hidden-xs">
                                  <option value="0">All Categories</option>
                                   <?php foreach ($categories as $cat):?>
                                    <option value="<?php echo $cat->id; ?>"><?php echo $cat->category_name; ?></option>
                              
                            <?php endforeach; ?>
                             
                                </select>
                              </div>
                              <input id="ajax-search-text" type="text" name="search" value="" placeholder="Search"
                                class="form-control input-lg" />
                              <div class="ajaxishi-search" style="display: none;">
                                <ul></ul>
                              </div>
                              <button id="ajax-search-btn" type="button" class="btn btn-default btn-lg"><i
                                  class="fa fa-search"></i></button>
                            </div>

                            <script>
                              (function () {
                                document.getElementById('ajax-search-text').addEventListener('keypress', function (event) {
                                  if (event.keyCode == 13) {
                                    event.preventDefault();
                                    document.getElementById('ajax-search-btn').click();
                                  }
                                });
                              }());
                            </script>
                          </form>
                        </div>
                    </div>
                </div>
            </div>
          
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <!-- ============================================================== -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                            <style type="text/css">
                                #mycart_button .btn:hover .fa{
                                    color: white !important;
                                }
                            </style>
                            <div class="card-header bg-info" id="mycart_button" style="padding: 0.75rem 0.75rem;">
                                <h4 class="mb-0 mt-0 text-white" style="line-height: 34px;">Products <a href="<?php echo base_url('member/cart'); ?>" class="btn btn-success float-right"><i class="fa fa fa-shopping-cart"></i> Cart</a></h4>
                            </div>
                            <div class="d-flex no-block align-items-center">
                                       <!--  <button class="btn btn-dark btn-outline"><i class="fas fa-arrow-left"></i> Continue shopping</button> -->
                                        <div class="ml-auto">
                                        
                                            
                                        </div>
                                    </div>
                          
                            <div id="product_img" class="container">
                                <div class="row text-center">
                                  <?php foreach ($products as $items):


                                    if(empty($items->member_retail_price_new) || $items->member_retail_price_new == 0)
                                    {
                                        $pr_price = $items->member_retail_price;
                                        $product_price = '<span class="current_price">PKR '.$items->member_retail_price.'.00</span>';
                                    }
                                    else{
                                        $pr_price = $items->member_retail_price_new;
                                        $product_price = '
                                                <span class="price-new">PKR '.$items->member_retail_price_new.'.00</span>   <span class="price-old" style="color:#b5b4b4; font-size:12px;">PKR '.$items->member_retail_price.'.00</span>';
                                    }


                                      if(empty($items->sub_image))
                                    {
                                        $img = 'frontfiles/assets/img/product/product6.jpg';
                                    }
                                    else{
                                        $img = 'product_images/'.$items->sub_image.'';
                                    }
                                    ?>
                                    <div class="col-md-3" style="margin-top: 30px;">
                                        <img src="<?php echo base_url($img); ?>" alt="<?php echo $items->product_name; ?>">
                                        <h5 class="font-500 mt-2 mb-0"><?php echo $items->product_name; ?></h5>
                                        <p><?php echo $items->description; ?></p>
                                        <input type="hidden" name="product_quantity" id="product_quantity" value="1">
                                        <span>Price - <?php echo $product_price; ?> PKR - CV <?php echo $items->no_of_cv; ?></span><br>
                                        <a href="<?php echo base_url('member/product_details/'.$items->product_id.'/'.$items->p_info_id.''); ?>" class="overlay button "  title="Add to cart"><button class="btn btn-danger add_to_cart" type="button"data-product_name="<?php echo $items->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-cv="<?php echo $items->no_of_cv; ?>" data-product_id="<?php echo $items->product_id; ?>" data-product_image="<?php echo $img; ?>" style="opacity: 1; display: none;"><i class="fa fa fa-shopping-cart"> Add to Cart</i></button></a>

                                    </div>

                                
                                  <?php endforeach; ?>
                                    
                                </div>
                               
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <hr>
                                  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                            <style type="text/css">
                                #mycart_button .btn:hover .fa{
                                    color: white !important;
                                }
                            </style>
                            <div class="card-header bg-danger" id="mycart_button" style="padding: 0.75rem 0.75rem;">
                                <h4 class="mb-0 mt-0 text-white" style="line-height: 34px;">Featured <a href="<?php echo base_url('member/cart'); ?>" class="btn btn-blue float-right"><i class="fa fa fa-shopping-cart"></i> Cart</a></h4>
                            </div>
                            <div class="d-flex no-block align-items-center">
                                       <!--  <button class="btn btn-dark btn-outline"><i class="fas fa-arrow-left"></i> Continue shopping</button> -->
                                        <div class="ml-auto">
                                        
                                            
                                        </div>
                                    </div>
                          
                            <div id="product_img" class="container">
                                <div class="row text-center">
                                  <?php foreach ($products as $items):

                                    if(empty($items->member_retail_price_new) || $items->member_retail_price_new == 0)
                                    {
                                        $pr_price = $items->member_retail_price;
                                        $product_price = '<span class="current_price">PKR '.$items->member_retail_price.'.00</span>';
                                    }
                                    else{
                                        $pr_price = $items->member_retail_price_new;
                                        $product_price = '
                                                <span class="price-new">PKR '.$items->member_retail_price_new.'.00</span>   <span class="price-old" style="color:#b5b4b4; font-size:12px;">PKR '.$items->member_retail_price.'.00</span>';
                                    }


                                      if(empty($items->sub_image))
                                    {
                                        $img = 'frontfiles/assets/img/product/product6.jpg';
                                    }
                                    else{
                                        $img = 'product_images/'.$items->sub_image.'';
                                    }
                                    ?>
                                    <div class="col-md-3" style="margin-top: 30px;">
                                        <img src="<?php echo base_url($img); ?>" alt="<?php echo $items->product_name; ?>">
                                        <h5 class="font-500 mt-2 mb-0"><?php echo $items->product_name; ?></h5>
                                        <p><?php echo $items->description; ?></p>
                                        <input type="hidden" name="product_quantity" id="product_quantity" value="1">
                                        <span>Price - <?php echo $product_price; ?>$ - CV <?php echo $items->no_of_cv; ?></span><br>
                                        <a href="<?php echo base_url('member/product_details/'.$items->product_id.'/'.$items->p_info_id.''); ?>" class="overlay button "  title="Add to cart"><button class="btn btn-danger add_to_cart" type="button"data-product_name="<?php echo $items->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-cv="<?php echo $items->no_of_cv; ?>" data-product_id="<?php echo $items->product_id; ?>" data-product_image="<?php echo $img; ?>" style="opacity: 1; display: none;"><i class="fa fa fa-shopping-cart"> Add to Cart</i></button></a>

                                    </div>

                              
                                  <?php endforeach; ?>
                                    
                                </div>
                               
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <hr>
                                 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <!-- Column -->
                    <div class="col-md-12 col-lg-12">
                        <div class="card">
                            <style type="text/css">
                                #mycart_button .btn:hover .fa{
                                    color: white !important;
                                }
                            </style>
                            <div class="card-header bg-warning" id="mycart_button" style="padding: 0.75rem 0.75rem;">
                                <h4 class="mb-0 mt-0 text-white" style="line-height: 34px;">Features <a href="<?php echo base_url('member/cart'); ?>" class="btn btn-info float-right"><i class="fa fa fa-shopping-cart"></i> Cart</a></h4>
                            </div>
                            <div class="d-flex no-block align-items-center">
                                       <!--  <button class="btn btn-dark btn-outline"><i class="fas fa-arrow-left"></i> Continue shopping</button> -->
                                        <div class="ml-auto">
                                        
                                            
                                        </div>
                                    </div>
                          
                            <div id="product_img" class="container">
                                <div class="row text-center">
                                  <?php foreach ($products as $items):
                                     if(empty($items->member_retail_price_new) || $items->member_retail_price_new == 0)
                                    {
                                        $pr_price = $items->member_retail_price;
                                        $product_price = '<span class="current_price">PKR '.$items->member_retail_price.'.00</span>';
                                    }
                                    else{
                                        $pr_price = $items->member_retail_price_new;
                                        $product_price = '
                                                <span class="price-new">PKR '.$items->member_retail_price_new.'.00</span>  <span class="price-old" style="color:#b5b4b4; font-size:12px;">PKR '.$items->member_retail_price.'.00</span>';
                                    }


                                      if(empty($items->sub_image))
                                    {
                                        $img = 'frontfiles/assets/img/product/product6.jpg';
                                    }
                                    else{
                                        $img = 'product_images/'.$items->sub_image.'';
                                    }
                                    ?>
                                    <div class="col-md-3" style="margin-top: 30px;">
                                        <img src="<?php echo base_url($img); ?>" alt="<?php echo $items->product_name; ?>">
                                        <h5 class="font-500 mt-2 mb-0"><?php echo $items->product_name; ?></h5>
                                        <p><?php echo $items->description; ?></p>
                                        <input type="hidden" name="product_quantity" id="product_quantity" value="1">
                                        <span>Price - <?php echo $product_price; ?>$ - CV <?php echo $items->no_of_cv; ?></span><br>
                                        <a href="<?php echo base_url('member/product_details/'.$items->product_id.'/'.$items->p_info_id.''); ?>" class="overlay button "  title="Add to cart"><button class="btn btn-danger add_to_cart" type="button"data-product_name="<?php echo $items->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-cv="<?php echo $items->no_of_cv; ?>" data-product_id="<?php echo $items->product_id; ?>" data-product_image="<?php echo $img; ?>" style="opacity: 1; display: none;"><i class="fa fa fa-shopping-cart"> Add to Cart</i></button></a>

                                    </div>

                                  <?php endforeach; ?>
                                    
                                </div>
                               
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <hr>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             
            </div>
