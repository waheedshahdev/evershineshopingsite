
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="text-right upgrade-btn">
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
                <?php 
    if($this->session->flashdata("error_msg") != ''){?>
       <div class="alert alert-danger">
           <button class="close" data-dismiss="alert"></button>
           <?php echo $this->session->flashdata("error_msg");?>
       </div>
       <?php
   }
   ?>
   <?php 
   if($this->session->flashdata("success") != ''){?>
       <div class="alert alert-success">
           <button class="close" data-dismiss="alert"></button>
           <?php echo $this->session->flashdata("success");?>
       </div>
       <?php
   }
   ?> 
            <div class="container-fluid">
               
                <!-- ============================================================== -->
                <!-- Table -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">PRODUCT SUMMARY</h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Photo</th>
                                                <th>Product</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>CV</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php foreach ($cart_data as $cart):
                                            $cart_qty_1 += $cart['qty']; 
                                   
                                        $cv_1 = $cart['cv'];
                                                $cv += $cart['cv'];

                                                $total_cv = $cv_1 * $cart_qty_1;

                                            ?>
                                            <tr>
                                                <td><img src="<?php echo base_url($cart['product_image']); ?>" alt="<?php echo $cart['name']; ?>" width="80"></td>
                                                <td><?php echo $cart['name']; ?></td>
                                                <td><?php echo $cart['price']; ?></td>
                                                <td><?php echo $cart['qty']; ?></td>
                                                <td><?php echo $cart['cv']; ?></td>
                                                <td class="font-500">PKR <?php echo $cart['subtotal']; ?></td>
                                            </tr>
                                           <?php endforeach; ?>
                                            
                                            <tr>
                                                <td></td>
                                                <td colspan="3" class="font-500" align="right">Total</td>
                                                <td><?php echo $total_cv; ?></td>
                                                <td class="font-500">PKR <?php echo $this->cart->total(); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>






                                <div class="col-lg-8 col-xlg-9 col-md-7">
                       
                        <div class="card">
                            <h3>Shipping Address</h3>
                            <div class="card-body">
                                <form class="form-horizontal form-material" action="<?php echo base_url('member/checkout'); ?>" method="post">
                                    <div class="form-group">
                                        <label class="col-md-12">Phone Number</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Entry Your Phone Number"
                                                class="form-control form-control-line" required="required" value="<?php echo $get_data[0]->phone_number; ?>" name="phone_number" id="shipping_phone">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Country</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Entry Your Country"
                                                class="form-control form-control-line" required="required" value="<?php echo $get_data[0]->country; ?>" name="country" id="shipping_country">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">City</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Enter Your City Name"
                                                class="form-control form-control-line" name="city"
                                                id="shipping_city" required="required" value="<?php echo $get_data[0]->city
                                                ; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Province</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Enter Your Province Name"
                                                class="form-control form-control-line" name="state"
                                                id="shipping_state" required="required" value="<?php echo $get_data[0]->state
                                                ; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Street</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Enter Your Street Address"
                                                class="form-control form-control-line" name="street"
                                                id="shipping_street" required="required" value="<?php echo $get_data[0]->street
                                                ; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Address</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Enter Your Address"
                                                class="form-control form-control-line" name="address"
                                                id="shipping_address" required="required" value="<?php echo $get_data[0]->address
                                                ; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Postal Code</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Enter Your Postal Code"
                                                class="form-control form-control-line" name="postal_code"
                                                id="shipping_zip" required="required" value="<?php echo $get_data[0]->postal_code
                                                ; ?>">
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Shipping Option</label>
                                        <div class="col-md-12">
                                           
                                                <select class="form-control form-control-line" name="shipping_option">
                                                    <option value="TCS">TCS</option>
                                                    <option value="FedEx">FedEx</option>
                                                </select>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                   
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button type="text" name="update_member_1" value="Update Shipping" class="btn btn-success">Update Shipping</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Shipping Address -->
                    </div>























                                <hr>
                                <h5 class="card-title">Choose payment Option</h5>
                                <ul class="nav nav-tabs" role="tablist">
                                    <li role="presentation" class="nav-item">
                                        <a href="#iprofile" class="nav-link active" aria-controls="home" role="tab" data-toggle="tab" aria-expanded="true" aria-selected="true">
                                        <!-- <span class="visible-xs"><i class="ti-home"></i></span> -->
                                        <span class="hidden-xs"> JAZZCASH</span>
                                    </a>
                                    </li>
                                    <li role="presentation" class="nav-item">
                                        <a href="#ihome" class="nav-link" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="false" aria-selected="false">
                                        
                                        <span class="hidden-xs">EASYPAISA</span>
                                    </a>
                                    </li>
                                    <li role="presentation" class="nav-item">
                                        <a href="#ihome1" class="nav-link" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="false" aria-selected="false">
                                        
                                        <span class="hidden-xs">Bank Transfer</span>
                                    </a>
                                    </li>
                                </ul>
                                <div class="tab-content">
                                    <div role="tabpanel" class="tab-pane" id="ihome">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <br> You can pay your money through EASYPAISA
                                                <br><br>
                                                <ul>
                                                    <li>Account Title: ZSMK</li>
                                                    <li>Account Number: +923015224144</li>
                                        
                                                </ul>
                                            </div>
                                            <div class="col-md-4 ml-auto">
                                                <h4 class="card-title mt-4">General Info</h4>
                                                <h2><i class="fab fa-cc-visa text-info"></i> 
                                                    <!-- <i class="fab fa-cc-mastercard text-danger"></i> <i class="fab fa-cc-discover text-success"></i> <i class="fab fa-cc-amex text-warning"></i> -->
                                                </h2>
                                                <p>Easypaisa enables its customers with the freedom of making payments for their online purchases in a convenient, secure and swift manner!</p>
                                                <p>Easypaisa, Pakistan’s first mobile banking platform launched in 2009, is the only GSMA mobile money certified service in the country. Initially launched as a money transfer service, Easypaisa empowers underserved masses by bringing convenience and freedom to their lives, and has today become the category name for money transfers, synonymous with convenience and reliability. </p>

                                            </div>
                                        </div>
                                    </div>
                                    <div role="tabpanel" class="tab-pane active" id="iprofile">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <br> You can pay your money through JAZZCASH
                                                <br><br>
                                                <ul>
                                                    <li>Account Title: ZSMK</li>
                                                    <li>Account Number: +923015224144</li>
                                               
                                                </ul>
                                            </div>
                                            <div class="col-md-4 ml-auto">
                                                <h4 class="card-title mt-4">General Info</h4>
                                                <h2><i class="fab fa-cc-visa text-info"></i> 
                                                    <!-- <i class="fab fa-cc-mastercard text-danger"></i> <i class="fab fa-cc-discover text-success"></i> <i class="fab fa-cc-amex text-warning"></i> -->
                                                </h2>
                                                <p>JazzCash enables its customers with the freedom of making payments for their online purchases in a convenient, secure and swift manner!</p>
                                                <p>With a variety of channels to make payments including vouchers, Mobile Accounts and Credit / Debit cards we ensure that our customers are no more limited to the traditional payment methods as they can choose one that suits their needs better. </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="tabpanel" class="tab-pane" id="ihome1">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <br> You can pay your money through BANK TRANSFER
                                                <br><br>
                                                <ul>
                                                    <li>Account Title: ZEALOUS SMART MARKETING</li>
                                                    <li>Account Number: PK92HABB0024567000498103</li>
                                           
                                                </ul>
                                            </div>
                                            <div class="col-md-4 ml-auto">
                                                <h4 class="card-title mt-4">General Info</h4>
                                                <h2><i class="fab fa-cc-visa text-info"></i> 
                                                    <i class="fab fa-cc-mastercard text-danger"></i> <i class="fab fa-cc-discover text-success"></i> <i class="fab fa-cc-amex text-warning"></i>
                                                </h2>
                                                <p>JazzCash enables its customers with the freedom of making payments for their online purchases in a convenient, secure and swift manner!</p>
                                                <p>With a variety of channels to make payments including vouchers, Mobile Accounts and Credit / Debit cards we ensure that our customers are no more limited to the traditional payment methods as they can choose one that suits their needs better. </p>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                  <form id="submit_checkout"  action="<?php echo base_url('member/checkout'); ?>" method='post' enctype='multipart/form-data'>
                                  <div class="col-md-12">
                                    <div class="form-group">
                                      <select class="form-control" required="required" id="payment_meth" name="payment_method" onchange="p_m()">
                                        <option value="">Select Option</option>
                                        <option value="Bank Transfer">Bank Transfer</option>
                                        <option value="Jazz Cash">Jazz Cash</option>
                                        <option value="Easy Paisa">Easy Paisa</option>
                                        <option value="Cash on Delivery">Cash on Delivery</option>
                                        <option value="Self-Pickup/Home Delivery">Self-Pickup/Home Delivery</option>
                                        <option value="Self-Pickup From AA">Self-Pickup From AA</option>
                                        
                                         
                                       </select>
                                    </div>
                                  </div>
                                  <div>
                                        <label><b>Note: if bank Tranfer please upload bank recept Mustly.</b></label>
                                        <input type="file" name="bank_receipt" id="img" class="form-control" required="required">
                                      </div>
                                  <input type="hidden" name="subtotal" value="<?php echo $cart['subtotal']; ?>">
                                <input type="hidden" name="promo_id" value="<?php echo $cart['discount_coupon']; ?>">
                                <input type="hidden" name="promo_discount" value="<?php echo $cart['discount_amount']; ?>">
                                <input type="hidden" name="delivery_price" value="<?php echo $cart['delivery_price']; ?>">
                                <input type="hidden" name="cv" value="<?php echo $total_cv; ?>">
                           
                                <input type="hidden" name="order_grand_total" value="<?php $total = $this->cart->total();
                                                $coupon = $cart['discount_coupon'];
                                                $amount = $cart['discount_amount'];
                                                $delivery_price = $cart['delivery_price'];
                                                if($delivery_price !='Free'){
                                                    $delivery = $delivery_price;
                                                }
                                                else{
                                                    $delivery = 0;
                                                }
                                                if($coupon == ''){
                                                    echo $total;
                                                }elseif ($coupon != '') {
                                                    $total = $total - $amount + $delivery;
                                                    echo $total;
                                                } ?>">
                                                <br>
                                                <button type="submit" name="proceed" value="Proceed to Checkout" class="btn btn-success" >Proceed to Checkout</button>
                                </form>
                                </div>
                                

                                 
                                  
                                
                            </div>
                        </div>
                    </div>
                </div>
              
            </div>


