            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item active"><a href="#"><?php echo $title; ?></a></li>
                                    <!-- <li class="breadcrumb-item active" aria-current="page">Library</li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="text-right upgrade-btn">
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                   <?php 
             if($this->session->flashdata("error_msg") != ''){?>
             <div class="alert alert-danger">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("error_msg");?>
             </div>
          <?php
            }
          ?>
          <?php 
             if($this->session->flashdata("success") != ''){?>
             <div class="alert alert-success">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("success");?>
             </div>
          <?php
            }
          ?>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body border-top">
                                <div class="row mb-0">
                                    
                                    <div class="col-lg-4 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <div class="mr-2"><span class="text-orange display-5"><i class="mdi mdi-wallet"></i></span></div>
                                            <div><span style="font-size: 20px;">Amount Available For Withdraw</span>
                                                <center><h3 class="font-medium mb-0"><?php if(!empty($earnings)){ echo $earnings[0]->level_earnings; } else{ echo '0';} ?><h3></center>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="col-lg-4 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <div class="mr-2"><span class="text-cyan display-5"><i class="mdi mdi-star-circle"></i></span></div>
                                            <div><span style="font-size: 20px;">Misc./ Cancelling Charges</span>
                                               <center> <h3 class="font-medium mb-0"><?php if(!empty($earnings)){ echo $earnings[0]->cancelation_charges; } else{ echo '0';} ?></h3></center>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="col-lg-4 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <div class="mr-2"><span class="text-primary display-5"><i class="mdi mdi-currency-usd"></i></span></div>
                                            <div><span style="font-size: 20px;">Total Amount Available For Withdraw</span>
                                                <center><h3 class="font-medium mb-0"><?php if(!empty($earnings)){ echo $earnings[0]->withdraw_amount; } else{ echo '0';}?></h3></center>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <b><center><font style="font-size: 20px;"><?php if(!empty($earnings)){ echo $earnings[0]->status; } else{ echo 'Nothing Made Yet';} ?></font></center></b>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="card">
                            <div class="card-body border-top">
                                <div class="row mb-0">
                                    
                                    <div class="col-lg-4 col-md-6">
                                        <div class="d-flex align-items-center">
                                  
                                            <div><span style="font-size: 15px;">Referral Bonus RPB Available: <b><?php if(!empty($earnings)){ echo $earnings[0]->referal_amount; } else{ echo '0';}  ?></b></span>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="col-lg-4 col-md-6">
                                        <div class="d-flex align-items-center">
                                     
                                            <div><span style="font-size: 15px;">Incentive Available: <b>PKR <?php if(!empty($earnings)){ echo $earnings[0]->incentive_amount; } else{ echo '0';}?></b></span>
                                               
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="col-lg-4 col-md-6">
                                        <div class="d-flex align-items-center">
                                          
                                            <div><span style="font-size: 15px;">Cash Out Amount: <b>PKR 34</b></span>
                                               
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ============================================================== -->
                <!-- Sales chart -->
                <!-- ============================================================== -->

                <div class="row">
                
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                
                                <div class="d-md-flex align-items-center">
                                    <div>
                                        <h4 class="card-title">Your Withdraw List</h4>
                                    </div>

                                </div>

                                <div class="d-md-flex align-items-center">
                                    <button class="btn btn-success" id="request_withdrawal">+Request for Withdrawal</button>
                                </div>
                                 

                                    <div class="transaction" id="div_id" style="display: none; margin-top: 20px;">     
                                        <form action="<?php echo base_url('member/withdrawal') ?>" method="post" enctype="multipart/form-data">
                                               
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Select Withdrawal Mode:</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <select name="withdrawal_mode" class="form-control" id="withdrawal_mode">
                                                                <option>--Select Mode--</option>
                                                                <option value="Referral Point Bonus (RPB)">Referral Point Bonus (RPB)</option>
                                                                <option value="Incentive">Incentive</option>
                                                                <option value="RPB + Incentive Both">RPB + Incentive Both</option>
                                                            </select>
                                                        </div>
                                                    </div> 
                                                    <input type="hidden" name="earning_id" value="<?php echo $earnings[0]->id; ?>"> 
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Select Withdrawal Source:</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <select name="withdrawal_source" class="form-control" id="withdrawal_source">
                                                                <option>--Select Option--</option>
                                                                <option value="Bank Transfer">Bank Transfer</option>
                                                                <option value="Easypaisa Transfer">Easypaisa Transfer</option>
                                                                <option value="JazzCash Transfer">JazzCash Transfer</option>
                                                                
                                                            </select>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Bank Details: Account Holder Name</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <input type="text" value="" name="account_holder" placeholder="Bank Details: Account Holder Name" class="form-control" id="account_holder">
                                                        </div>
                                                    </div>

                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">IBAN/Account#</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <input type="text" name="account_number" placeholder="IBAN/Account#" class="form-control" id="account_number">
                                                        </div>
                                                    </div>
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Account Holder CNIC</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <input type="text" placeholder="Account Holder CNIC"  name="holder_cnic" class="form-control" id="holder_cnic">
                                                        </div>
                                                    </div>
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Mobile#</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <input type="number" placeholder="Enter Your Mobile#"  name="holder_mobile" class="form-control" id="holder_mobile">
                                                        </div>
                                                    </div>
                                                   
                                                    
                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Withdrawal Badge Name:</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <textarea placeholder="Write Badge Name Here( If more than 1 then write e.g. Star, Scarlet Star, Novel)" name="badge_name" class="form-control" id="badge_name"></textarea>
                                                        
                                                        </div>
                                                    </div>

                                                    <div class="col-6 offset-lg-3">
                                                        <div class="form-group">
                                                            <label for="recipient-name" class="control-label" style="color: black;">Note:</label><span style="font-weight: bolder;color: red;font-size: 25px;line-height: 0;">*</span>
                                                            <textarea placeholder="Write notes here" rows="6" cols="6" name="note" class="form-control" id="note"></textarea>
                                                      
                                                        </div>
                                                    </div>
                                                 
                                                   
                                                    
                                                      

                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <input type="submit" name="Submit_request" value="Submit Request" class="btn btn-success">
                                                        </div>
                                                </div>

                                           

                                        </form>
                                
                  
                                </div>
                            </div>
                      
                        </div>
                    </div>

                </div>



                <!-- ============================================================== -->
                <!-- Table -->
                <!-- ============================================================== -->

                 <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="card">
                            <div class="card-body border-top">
                                <center><h3>Terminologies</h3></center>
                              
                                    
                                 
                                        <div class="d-flex align-items-center justify-content-center">
                                  
                                            <span style="font-size: 15px;">Referral Bonus RPB Available: <b>PKR <?php if(!empty($earnings)){ echo $earnings[0]->referal_amount; } else{ echo '0';}  ?> </b> <b style="color: red;">Depending Upon Points</b></span>
                                
                                        </div>
                                        <br>
                                        <div class="d-flex align-items-center justify-content-center">
                                     
                                            <div><span style="font-size: 15px;">Incentive Available: <b>PKR <?php if(!empty($earnings)){ echo $earnings[0]->incentive_amount; } else{ echo '0';}  ?> </b>  <b style="color: red;">Fixed amount for each badge</b></span>
                                               
                                            </div>
                                        </div>
                                        <br>
                                        <div class="d-flex align-items-center justify-content-center">
                                          
                                            <div><span style="font-size: 15px;">Cash Out Amount: <b>PKR 34</b> <b style="color: red;">Amount Out till Now</b></span>
                                               
                                            </div>
                                     
                                        </div>
                         
                              
                            </div>
                        </div>
                    </div>
                </div>







                <div class="row">
                    <div style="float: right;"><b><font style="font-size: 20px; color: red;"><?php if(!empty($withdraw_request)){ echo $withdraw_request[0]->status; } else{ echo 'Nothing Made Yet';} ?></font></b></div>
                    <!-- column -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                
                                <div class="d-md-flex align-items-center">
                                    <div>
                                        <h4 class="card-title">Withdrawal Requests</h4>
                                        <h5 class="card-subtitle">Overview of withdrawal request</h5>
                                    </div>
                                
                                </div>
                              
                            </div>
                            <div class="table-responsive">
                                <table class="table v-middle">
                                    <thead>
                                        <tr class="bg-light">
                                            <th class="border-top-0">W Mode</th>
                                            <th class="border-top-0">W Source</th>
                                            <th class="border-top-0">A/C Holder</th>
                                            <th class="border-top-0">A/C #</th>
                                            <th class="border-top-0">A/C CNIC</th>
                                            <th class="border-top-0"># Mobile</th>
                                            <th class="border-top-0">Badge</th>
                                            <th class="border-top-0">W Amount</th>
                                            <th class="border-top-0">Status</th>
                                            <th class="border-top-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($withdraw_request as $withdraw):?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="m-r-10"><a
                                                            class="btn btn-circle d-flex btn-info text-white">EA</a>
                                                    </div>
                                                    <div class="">
                                                        <h4 class="m-b-0 font-16"><?php echo $withdraw->withdrawal_mode; ?></h4>
                                                    </div>
                                                </div>
                                            </td>
                                  
                                            <td><?php echo $withdraw->withdrawal_source; ?></td>
                                            <td><?php echo $withdraw->account_holder; ?></td>
                                            <td><?php echo $withdraw->account_number; ?></td>
                                            <td><?php echo $withdraw->holder_cnic; ?></td>
                                            <td><?php echo $withdraw->holder_mobile; ?></td>
                                            <td><?php echo $withdraw->badge_name; ?></td>
                                            <td><?php echo $withdraw->withdraw_amount; ?></td>
                                            <td>
                                                <label class="label label-danger"><?php echo $withdraw->status; ?></label>
                                            </td>
                                            <td><a href="<?php echo base_url('admin/withdraw_view/'.$withdraw->id.''); ?>">View</a></td>
                                           
                                        </tr>
                                    <?php endforeach; ?>
                                 
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- Table -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Recent comment and chats -->
                <!-- ============================================================== -->
          <!--       <div class="row">
                   
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Recent Comments</h4>
                            </div>
                            <div class="comment-widgets scrollable">
                               
                                <div class="d-flex flex-row comment-row m-t-0">
                                    <div class="p-2"><img src="<?php echo base_url(); ?>new_adminfiles/assets/image/users/1.jpg" alt="user" width="50"
                                            class="rounded-circle"></div>
                                    <div class="comment-text w-100">
                                        <h6 class="font-medium">James Anderson</h6>
                                        <span class="m-b-15 d-block">Lorem Ipsum is simply dummy text of the printing
                                            and type setting industry. </span>
                                        <div class="comment-footer">
                                            <span class="text-muted float-right">April 14, 2016</span> <span
                                                class="label label-rounded label-primary">Pending</span> <span
                                                class="action-icons">
                                                <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                                <a href="javascript:void(0)"><i class="ti-check"></i></a>
                                                <a href="javascript:void(0)"><i class="ti-heart"></i></a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                               
                                <div class="d-flex flex-row comment-row">
                                    <div class="p-2"><img src="<?php echo base_url(); ?>new_adminfiles/assets/image/users/4.jpg" alt="user" width="50"
                                            class="rounded-circle"></div>
                                    <div class="comment-text active w-100">
                                        <h6 class="font-medium">Michael Jorden</h6>
                                        <span class="m-b-15 d-block">Lorem Ipsum is simply dummy text of the printing
                                            and type setting industry. </span>
                                        <div class="comment-footer ">
                                            <span class="text-muted float-right">April 14, 2016</span>
                                            <span class="label label-success label-rounded">Approved</span>
                                            <span class="action-icons active">
                                                <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                                <a href="javascript:void(0)"><i class="icon-close"></i></a>
                                                <a href="javascript:void(0)"><i class="ti-heart text-danger"></i></a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                             
                                <div class="d-flex flex-row comment-row">
                                    <div class="p-2"><img src="<?php echo base_url(); ?>new_adminfiles/assets/image/users/5.jpg" alt="user" width="50"
                                            class="rounded-circle"></div>
                                    <div class="comment-text w-100">
                                        <h6 class="font-medium">Johnathan Doeting</h6>
                                        <span class="m-b-15 d-block">Lorem Ipsum is simply dummy text of the printing
                                            and type setting industry. </span>
                                        <div class="comment-footer">
                                            <span class="text-muted float-right">April 14, 2016</span>
                                            <span class="label label-rounded label-danger">Rejected</span>
                                            <span class="action-icons">
                                                <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                                <a href="javascript:void(0)"><i class="ti-check"></i></a>
                                                <a href="javascript:void(0)"><i class="ti-heart"></i></a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                </div> -->
        
            </div>