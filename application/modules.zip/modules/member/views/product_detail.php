





























            <div class="page-breadcrumb" style="padding:20px 20px 20px 20px;">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item active"><a href="#"><?php echo $title; ?></a></li>
                                    <!-- <li class="breadcrumb-item active" aria-current="page">Library</li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="text-right upgrade-btn">
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid bg-white" >
               <?php 
             if($this->session->flashdata("error_msg") != ''){?>
             <div class="alert alert-danger">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("error_msg");?>
             </div>
          <?php
            }
          ?>
          <?php 
             if($this->session->flashdata("success") != ''){?>
             <div class="alert alert-success">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("success");?>
             </div>
          <?php
            }
          ?>
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <!-- ============================================================== -->


                <!-- ============================================================== -->
                <!-- Table -->
                <!-- ============================================================== -->

         <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <!-- Model -->


                <div class="col-md-12">
                      <?php foreach ($product_detail as $detail) {

                         if(empty($detail->member_retail_price_new) || $detail->member_retail_price_new == 0)
                                    {
                                        $pr_price = $detail->member_retail_price;
                                        $product_price = '<span class="current_price">PKR '.$detail->member_retail_price.'.00</span>';
                                    }
                                    else{
                                        $pr_price = $detail->member_retail_price_new;
                                        $product_price = '
                                                <span class="price-new">PKR '.$detail->member_retail_price_new.'.00</span>  <span class="price-old" style="color:#b5b4b4; font-size:12px;">PKR '.$detail->member_retail_price.'.00</span>';
                                    }


                   

                                    if(empty($detail->sub_image))
                                    {
                                        $img = 'frontfiles/assets/image/product/product8.jpg';
                                    }
                                    else{
                                        $img = 'product_images/'.$detail->sub_image.'';
                                    }
                } ?>


            <div class="row" id="member_product">
                <div class="col-sm-6">
                    <ul class="thumbnails pl-0" style="list-style: none;">
                        <li><a class="thumbnail fancybox" href="<?php echo base_url($img); ?>" title="<?php echo $detail->product_name; ?>"><img src="<?php echo base_url($img); ?>" title="<?php echo $detail->product_name; ?>" alt="<?php echo $detail->product_name; ?>" style="width:100%;" /></a></li>
                        <div id="product-thumbnail" class="owl-carousel">
                           
                        </div>
                    </ul>
                </div>
                <div class="col-sm-6">
                    <h1 class="productpage-title"><?php echo $detail->product_name; ?></h1>
                    <div class="rating product"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-1x"></i><i class="fa fa-star-o fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span> <span class="review-count"> <a href="#" onClick="$('a[href=\'#tab-review\']').trigger('click'); return false;">1 reviews</a> / <a href="#" onClick="$('a[href=\'#tab-review\']').trigger('click'); return false;">Write a review</a></span>
                        <hr>
                        <!-- AddThis Button BEGIN -->
                        <div class="addthis_toolbox addthis_default_style"><a class="addthis_button_facebook_like" ></a> <a class="addthis_button_tweet"></a> <a class="addthis_button_pinterest_pinit"></a> <a class="addthis_counter addthis_pill_style"></a></div>
                        <script type="text/javascript" src="../s7.addthis.com/js/300/addthis_widget.html#pubid=ra-515eeaf54693130e"></script> 
                        <!-- AddThis Button END --> 
                    </div>
                    <ul class="list-unstyled productinfo-details-top">
                        <li>
                            <h2 class="productpage-price"><?php echo $product_price; ?></h2>
                        </li>
                        <!-- <li><span class="productinfo-tax">Ex Tax: $100.00</span></li> -->
                    </ul>
                    <hr>
                    <ul class="list-unstyled product_info">
                        <li>
                            <label>Product Category:</label>
                            <span> <a href="#"><?php echo $detail->category_name; ?></a></span></li>
                        <li>
                            <label>Product Code: </label>
                            <span> <?php echo $detail->product_id; ?></span></li>
                        <li>
                            <label>Availability:</label>
                            <span> In Stock</span>
                        </li>
                        <li>

                            <label>Size:</label>
                            <input type="hidden" name="product_id" id="product_id" value="<?php echo $detail->product_id; ?>">
                            <select class="form-control" style="width: 40%;" name="size" id="size">
                                <?php foreach ($sizes as $value) {?>
                                <option value="<?php echo $value->id.','.$value->size; ?>" ><?php echo $value->size; ?></option>        
                                <?php } ?>
                                
                            </select>
                        </li>
                        <li>
                            <label>Color:</label>
                            <select class="form-control" style="width: 40%;" name="color" id="color">
                                
                                
                            </select>
                        </li>
                        <li>
                            <label>video Link:</label>
                            <span><a href="https://www.youtube.com/embed/sq6UEMh7bHk" target="_blank"><?php echo $detail->video_url; ?></a></span>
                        </li>
                    </ul>
                    <hr>
                    <p class="product-desc"> More room to move.     
                        With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.    
                        Cover Flow.     
                        Browse through your music collection by flipping..</p>
                    <div id="product">
                        <div class="form-group">
                            <label class="control-label qty-label" for="input-quantity">Qty</label>
                            <input type="number" name="product_quantity" id="product_quantity" value="1" size="2" class="form-control productpage-qty" />
                            <input type="hidden" name="product_id" value="48" />

                            <?php    $p_id = $this->uri->segment(3);
                                    foreach ($cart_data as $cart) {
                                        $c_id = $cart['id'];
                                        $c_qty = $cart['qty'];

                                        if($p_id == $c_id){
                                            $now_id = $c_id;
                                            $now_qty = $c_qty;
                                        }

                                    } ?>
                            <input type="hidden" name="cart_product_id" id="cart_product_id" value="<?php echo $now_id; ?>" />
                            <input type="hidden" name="cart_qty" id="cart_qty" value="<?php if(empty($cart_data)){ echo '0';}else{ echo $c_qty; }   ?>" />


                            
                            <div class="btn-group" style="margin:20px 0;">
                                <button type="button" data-toggle="tooltip" class="btn btn-default wishlist" title="Add to Wish List" data-product_id="<?php echo $detail->product_id; ?>"><i class="fa fa-heart-o"></i></button>


                                <a class="btn btn-primary btn-lg btn-block add_to_cart" type="button"data-product_name="<?php echo $detail->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-product_id="<?php echo $detail->product_id; ?>" data-product_image="<?php echo $img; ?>"  data-cv="<?php echo $detail->no_of_cv; ?>" data-p_info_id = "<?php echo $this->uri->segment(4); ?>" title="Add to cart" style="padding:7.2px 20px;">Add to cart</a>
                                
                                <!-- <button class="btn btn-primary btn-lg btn-block add_to_cart" type="button"data-product_name="<?php echo $products->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-product_id="<?php echo $products->product_id; ?>" data-product_image="<?php echo $img; ?>" title="Add to cart">Add to Cart</button> -->

                                <button type="button" data-toggle="tooltip" class="btn btn-default compare" title="Compare this Product" ><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>




            <iframe id="youtube" width="100%" height="400px" src="https://www.youtube.com/embed/sq6UEMh7bHk" frameborder="0" allow="encrypted-media" allowfullscreen></iframe>


            <!-- <div class="productinfo-tab">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#tab-description" data-toggle="tab">Description</a></li>
                    <li><a href="#tab-review" data-toggle="tab">Reviews (1)</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="tab-description">
                        <div class="cpt_product_description ">
                            <div>
                                <p> <strong>More room to move.</strong></p>
                                <p> With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.</p>
                                <p> <strong>Cover Flow.</strong></p>
                                <p> Browse through your music collection by flipping through album art. Select an album to turn it over and see the track list.</p>
                                <p> <strong>Enhanced interface.</strong></p>
                                <p> Experience a whole new way to browse and view your music and video.</p>
                                <p> <strong>Sleeker design.</strong></p>
                                <p> Beautiful, durable, and sleeker than ever, iPod classic now features an anodized aluminum and polished stainless steel enclosure with rounded edges.</p>
                            </div>
                        </div>
                        </div>
                  
                </div>
            </div> -->


            <div class="productinfo-tab">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#tab-description" data-toggle="tab">Description</a></li>
                    <li><a href="#tab-review" data-toggle="tab">Reviews (1)</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="tab-description">
                        <div class="cpt_product_description ">
                            <div>
                                <p> <strong>More room to move.</strong></p>
                                <p> With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.</p>
                                <p> <strong>Cover Flow.</strong></p>
                                <p> Browse through your music collection by flipping through album art. Select an album to turn it over and see the track list.</p>
                                <p> <strong>Enhanced interface.</strong></p>
                                <p> Experience a whole new way to browse and view your music and video.</p>
                                <p> <strong>Sleeker design.</strong></p>
                                <p> Beautiful, durable, and sleeker than ever, iPod classic now features an anodized aluminum and polished stainless steel enclosure with rounded edges.</p>
                            </div>
                        </div>
                        <!-- cpt_container_end --></div>
                    <div class="tab-pane" id="tab-review">
                        <form class="form-horizontal">
                            <div id="review"></div>
                            <h2>Write a review</h2>
                            <div class="form-group required">
                                <div class="col-sm-12">
                                    <label class="control-label" for="input-name">Your Name</label>
                                    <input type="text" name="name" value="" id="input-name" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group required">
                                <div class="col-sm-12">
                                    <label class="control-label" for="input-review">Your Review</label>
                                    <textarea name="text" rows="5" id="input-review" class="form-control"></textarea>
                                    <div class="help-block"><span class="text-danger">Note:</span> HTML is not translated!</div>
                                </div>
                            </div>
                            <div class="form-group required">
                                <div class="col-sm-12">
                                    <label class="control-label">Rating</label>
                                    &nbsp;&nbsp;&nbsp; Bad&nbsp;
                                    <input type="radio" name="rating" value="1" />
                                    &nbsp;
                                    <input type="radio" name="rating" value="2" />
                                    &nbsp;
                                    <input type="radio" name="rating" value="3" />
                                    &nbsp;
                                    <input type="radio" name="rating" value="4" />
                                    &nbsp;
                                    <input type="radio" name="rating" value="5" />
                                    &nbsp;Good</div>
                            </div>
                            <div class="buttons clearfix">
                                <div class="pull-right">
                                    <button type="button" id="button-review" data-loading-text="Loading..." class="btn btn-primary">Continue</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <h3 class="productblock-title">Related Products</h3>
            <div class="box">
                <div id="related-slidertab" class="row owl-carousel product-slider">
                    <div class="item">
                        <div class="product-thumb transition">
                            <div class="image product-imageblock"> <a href="#"> <img src="assets/image/product/pro-1-220x294.jpg" alt="iPhone" title="iPhone" class="img-responsive" /> </a>
                                <div class="button-group">
                                    <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                    <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                </div>
                            </div>
                            <div class="caption product-detail">
                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                            </div>
                            <div class="button-group">
                                <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product"><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                
                    
                   
                    <div class="item">
                        <div class="product-thumb transition">
                            <div class="image product-imageblock"> <a href="#"> <img src="assets/image/product/pro-7-220x294.jpg" alt="iPhone" title="iPhone" class="img-responsive" /> </a>
                                <div class="button-group">
                                    <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                    <button type="button" class="addtocart-btn">Add to Cart</button>
                                    <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product"><i class="fa fa-exchange"></i></button>
                                </div>
                            </div>
                            <div class="caption product-detail">
                                <h4 class="product-name"><a href="product.html" title="iPhone">iPhone</a></h4>
                                <p class="price product-price"> <span class="price-new">$254.00</span> <span class="price-old">$272.00</span> <span class="price-tax">Ex Tax: $210.00</span> </p>
                            </div>
                            <div class="button-group">
                                <button type="button" class="wishlist" data-toggle="tooltip" title="Add to Wish List"><i class="fa fa-heart-o"></i></button>
                                <button type="button" class="addtocart-btn">Add to Cart</button>
                                <button type="button" class="compare" data-toggle="tooltip" title="Compare this Product"><i class="fa fa-exchange"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->

        <!-- Shipping Info 1 -->








        
            </div>






















          

              
       
    























  
      



















