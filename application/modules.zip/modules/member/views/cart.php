
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="text-right upgrade-btn">
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
                  
            <div class="container-fluid">
                 <?php 
             if($this->session->flashdata("error_msg") != ''){?>
             <div class="alert alert-danger">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("error_msg");?>
             </div>
          <?php
            }
          ?>
          <?php 
             if($this->session->flashdata("success") != ''){?>
             <div class="alert alert-success">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("success");?>
             </div>
          <?php
            }
          ?>
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <!-- ============================================================== -->
          
                <div class="row">
                    <!-- Column -->
                    <div class="col-md-9 col-lg-9">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h5 class="mb-0 text-white">Your Cart </h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table product-overview">
                                        <thead>
                                            <tr>
                                                <th>Image</th>
                                                <th>Product info</th>
                                                <th>Price</th>
                                                <th>CV</th>
                                                <th>Quantity</th>
                                                <th style="text-align:center">Total</th>
                                                <th style="text-align:center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        	 <?php 
                                $this->load->library('cart');
                                $cart_data = $this->cart->contents();
                                if (empty($cart_data)){ $count = 0;} elseif (!empty($cart_data)) {
                                    $count == 1;
                                    foreach ($cart_data as $cart) {
                                    	$cv += $cart['cv'];
                                        $count++;
                                   
                                    ?>
                                            <tr>
                                                <td width="150"><img src="<?php echo base_url($cart['product_image']); ?>" alt="<?php echo $cart['name']; ?>" width="80"></td>
                                                <td width="550">
                                                    <h5 class="font-500"><?php echo $cart['name']; ?></h5>
                                                    <!-- <p>Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look</p>
 -->                                                </td>
                                                <td> <?php echo $cart['price'] ?></td>
                                                <td><?php echo $cart['cv']; ?></td>

                                                <td width="70">
                                                    <!-- <input type="text" class="form-control" placeholder="1" value="<?php echo $cart['qty']; ?>"> -->
                                                    <form action="<?php echo base_url(); ?>member/update_quantity/<?php echo $cart['rowid'];?>" method = 'POST'>
                                                        <div class="input-container">
                                                        <input type="text" class="form-control quantity" size="1" value="<?php echo $cart['qty']; ?>" name="quantity">
                                                        <input type="hidden" class="form-control" size="1" value="<?php echo $cart['cv']; ?>" name="cv">
                                                       
                                                        <button class="btn btn-primary" title="" data-toggle="tooltip" type="submit" data-original-title="Update"><i class="ti-pencil"></i></button>
                                                        </div>
                                                        </form>
                                                </td>
                                                <td width="150" align="center" class="font-500">$<?php echo $cart['subtotal']; ?></td>
                                                <td align="center"><a href="<?php echo base_url();?>member/remove_cart_item/<?php echo $cart['rowid'];?>"  class="text-inverse" title="" data-toggle="tooltip" data-original-title="Delete"><i class="ti-trash text-dark"></i></a></td>
                                            </tr>

                                        <?php  } } ?>
                                       
                                          
                                        </tbody>
                                    </table>
                                    <hr>
                                    <style type="text/css">
                                        #mycart_button .btn:hover .fa{
                                            color: white !important;
                                        }
                                    </style>
                                    <div class="d-flex no-block align-items-center" id="mycart_button">
                                        <a href="<?php echo base_url('member/products'); ?>" class="btn btn-dark btn-outline"><i class="fas fa-arrow-left"></i> Continue shopping</a>
                                        <div class="ml-auto">
                                            <a href="<?php echo base_url('member/checkout'); ?>" class="btn btn-danger"><i class="fa fa fa-shopping-cart mr-2"></i>Checkout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <div class="col-md-3 col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">CART SUMMARY</h5>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6 col-lg-6">
                                        <small>Total Price</small>
                                        <h2>PKR <?php echo $this->cart->total(); ?></h2>
                                    </div>
                                    <div class="col-md-6 col-lg-6">
                                        <small>Total CV</small>
                                        <h2><?php echo $cv; ?></h2>
                                    </div>
                                </div>
                                <hr>
                                <a href="<?php echo base_url('member/checkout'); ?>" class="btn btn-success">Checkout</a>
                                <button class="btn btn-secondary btn-outline" style="padding:6.5px 20px;">Cancel</button>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">For Any Support</h5>
                                <hr>
                                <h4><i class="ti-mobile"></i> 0900 78601 <br> (Toll Free)</h4> <small>Please contact with us if you have any questions. We are avalible 24h.</small>
                            </div>
                        </div>
                    </div>
                </div>
               
      
             
            </div>
