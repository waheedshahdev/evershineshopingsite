
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Profile Page</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="text-right upgrade-btn">
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="container-fluid">
            	  <?php 
             if($this->session->flashdata("error_msg") != ''){?>
             <div class="alert alert-danger">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("error_msg");?>
             </div>
          <?php
            }
          ?>
          <?php 
             if($this->session->flashdata("success") != ''){?>
             <div class="alert alert-success">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("success");?>
             </div>
          <?php
            }
          ?>
             
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal" style="float: right;">Change Picture</button>
                                <?php if($get_data[0]->profile_pic == ''){ $pro_pic = 'new_adminfiles/assets/image/users/5.jpg';} else{ $pro_pic = 'member_pic/'.$get_data[0]->profile_pic;} ?>
                                <center class="m-t-30"> <img src="<?php echo base_url($pro_pic); ?>"
                                        class="rounded-circle" width="150" height="150" />
                                    <h4 class="card-title m-t-10"><?php echo $get_data[0]->member_name; ?></h4>
                                    <!-- <h6 class="card-subtitle">Member</h6> -->
                                    <div class="row text-center justify-content-md-center">
                                        <div class="col-4"><a href="javascript:void(0)" class="link">
                                                PCV: <?php echo $get_data[0]->pcv; ?>
                                            </a></div>
                                        <div class="col-4"><a href="javascript:void(0)" class="link">
                                                TCV: <?php echo $get_data[0]->tcv; ?>
                                            </a></div>
                                    </div>
                                    <br>
                                    <h4>Referee: <?php echo $get_data[0]->referal_person_code; ?></h4>
                                    <h4>Referee Name: <?php $get_name = select_columns('member_name','tbl_member', 'member_code = '.$get_data[0]->referal_person_code.''); echo $get_name[0]->member_name; ?></h4>
                                </center>
                            </div>
                            <div>
                                <hr>
                            </div>

                            <div class="card-body">
                             <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal_1" style="float: right;">Upload CNIC</button> 

                                <small class="text-muted">Email address </small>

                                <h6><?php echo $get_data[0]->member_email; ?></h6> <small class="text-muted p-t-30 db">Member Code</small>
                                <h6><?php echo $get_data[0]->member_code; ?></h6> 
                                <small class="text-muted p-t-30 db">Address</small>
                                <h6>71 Pilgrim Avenue Chevy Chase, MD 20815</h6>
                                <br>
                                <br>
                                <div class="map-box">
                                    <h6>CNIC Pictures</h6>
                                     <table>
                                            <?php foreach ($get_cnic as $cnic):?>
                                            <tr>
                                                <td><img src="<?php echo base_url(); ?>member_pic/<?php echo $cnic->cnic_pic; ?>" style="width: 400px; height:260px;"></td>
                                                <td><a href="<?php echo base_url('member/delete_cnic_pic/'.$cnic->id); ?>" class="btn btn-danger">Delete</a></td>
                                            </tr>
                                             <?php endforeach; ?>
                                        </table>
                                       

                                   
                                   
                                </div>
                                 <!-- <small class="text-muted p-t-30 db">Social Profile</small> -->
                                <br />
                                <!-- <button class="btn btn-circle btn-secondary"><i class="fab fa-facebook-f"></i></button>
                                <button class="btn btn-circle btn-secondary"><i class="fab fa-twitter"></i></button>
                                <button class="btn btn-circle btn-secondary"><i class="fab fa-youtube"></i></button> -->
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <div class="card-body">
                                <form class="form-horizontal form-material" action="<?php echo base_url('member/profile'); ?>" method="post">
                                    <div class="form-group">
                                        <label class="col-md-12">Full Name</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Ex: Member"
                                                class="form-control form-control-line" value="<?php echo $get_data[0]->member_name; ?>" name="member_name" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Email</label>
                                        <div class="col-md-12">
                                            <input type="email" placeholder="abc@member.com"
                                                class="form-control form-control-line" name="member_email"
                                                id="example-email" value="<?php echo $get_data[0]->member_email
                                                ; ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Password</label>
                                        <div class="col-md-12">
                                            <input type="password"
                                                class="form-control form-control-line" name="password" placeholder="Enter New Password">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Confirm Password</label>
                                        <div class="col-md-12">
                                            <input type="password"
                                                class="form-control form-control-line" name="confirm_password" placeholder="Confirm Password">
                                        </div>
                                    </div>
                                    
                                    
                                   
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button type="text" name="update_member" value="Update Profile" class="btn btn-success">Update Profile</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Shipping Address -->
                        <div class="card">
                        	<h3>Shipping Address</h3>
                            <div class="card-body">
                                <form class="form-horizontal form-material" action="<?php echo base_url('member/profile'); ?>" method="post">
                                    <div class="form-group">
                                        <label class="col-md-12">Phone Number</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Entry Your Phone Number"
                                                class="form-control form-control-line" value="<?php echo $get_data[0]->phone_number; ?>" name="phone_number">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Country</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Entry Your Country"
                                                class="form-control form-control-line" value="<?php echo $get_data[0]->country; ?>" name="country">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">City</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Enter Your City Name"
                                                class="form-control form-control-line" name="city"
                                                id="example-email" value="<?php echo $get_data[0]->city
                                                ; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Province</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Enter Your Province Name"
                                                class="form-control form-control-line" name="state"
                                                id="example-email" value="<?php echo $get_data[0]->state
                                                ; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Street</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Enter Your Street Address"
                                                class="form-control form-control-line" name="street"
                                                id="example-email" value="<?php echo $get_data[0]->street
                                                ; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Address</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Enter Your Address"
                                                class="form-control form-control-line" name="address"
                                                id="example-email" value="<?php echo $get_data[0]->address
                                                ; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Postal Code</label>
                                        <div class="col-md-12">
                                            <input type="text" placeholder="Enter Your Postal Code"
                                                class="form-control form-control-line" name="postal_code"
                                                id="example-email" value="<?php echo $get_data[0]->postal_code
                                                ; ?>">
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Shipping Option</label>
                                        <div class="col-md-12">
                                           
                                                <select class="form-control form-control-line" name="shipping_option">
                                                	<option value="TCS">TCS</option>
                                                	<option value="FedEx">FedEx</option>
                                                </select>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                   
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button type="text" name="update_member" value="Update Shipping" class="btn btn-success">Update Shipping</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Shipping Address -->
                    </div>
                    <!-- Column -->


                    <!-- Upload Pic Modal -->
                    <div class="container">
                          

                          <!-- Modal -->
                          <div class="modal fade" id="myModal" role="dialog">
                            <div class="modal-dialog">
                            
                              <!-- Modal content-->
                              <div class="modal-content">
                                <div class="modal-header">
                                     <h4 class="modal-title">Choose Profile Picture</h4>
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                 
                                </div>
                                <div class="modal-body">
                                    <form method="post" accept="<?php echo base_url('member/profile'); ?>" enctype="multipart/form-data">
                                        <input type="file" name="profile_pic">
                                        <input type="submit" name="profile_pic" value="Change Profile Pic" class="btn btn-success">      
                                    </form>
                                  
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                              </div>
                              
                            </div>
                          </div>
                          
                        </div>
                    <!--END Upload Pic Modal -->

                    <!-- Upload CNIC Modal -->
                    <div class="container">
                          

                          <!-- Modal -->
                          <div class="modal fade" id="myModal_1" role="dialog">
                            <div class="modal-dialog">
                            
                              <!-- Modal content-->
                              <div class="modal-content">
                                <div class="modal-header">
                                     <h4 class="modal-title">Choose Your CNIC</h4>
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                 
                                </div>
                                <div class="modal-body">
                                    <form method="post" accept="<?php echo base_url('member/profile'); ?>" enctype="multipart/form-data">
                                        <input type="file" name="userfile[]" multiple="multiple">
                                        <input type="submit" name="upload_cnic" value="Upload CNIC" class="btn btn-success">      
                                    </form>
                                  
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                              </div>
                              
                            </div>
                          </div>
                          
                        </div>
                    <!--END Upload CNIC Modal -->

                </div>
            </div>
