<style type="text/css">
    *{
    margin: 0;
    padding: 0;
}
.rate {
    float: left;
    height: 46px;
    padding: 0 10px;
}
.rate:not(:checked) > .inpt {
    position:fixed;
    top:-9999px;
}
.rate:not(:checked) > .str {
    float:right;
    width:1em;
    overflow:hidden;
    white-space:nowrap;
    cursor:pointer;
    font-size:30px;
    color:#ccc;
}
.rate:not(:checked) > .str:before {
    content: '★ ';
}
.rate > .inpt:checked ~ .str {
    color: #ffc700;    
}
.rate:not(:checked) > .str:hover,
.rate:not(:checked) > .str:hover ~ .str {
    color: #deb217;  
}
.rate > .inpt:checked + .str:hover,
.rate > .inpt:checked + .str:hover ~ .str,
.rate > .inpt:checked ~ .str:hover,
.rate > .inpt:checked ~ .str:hover ~ .str,
.rate > .str:hover ~ .inpt:checked ~ .str {
    color: #c59b08;
}

/* Modified from: https://github.com/mukulkant/Star-rating-using-pure-css */
  </style>
        <!-- product-details-section-start -->
		<div class="product-details pages section-padding-top">
			<div class="container">
				<div class="row">
					 <?php foreach ($product_detail as $detail) {

                         if(empty($detail->member_retail_price_new) || $detail->member_retail_price_new == 0)
                                    {
                                        $pr_price = $detail->member_retail_price;
                                        $product_price = '<span class="current_price">PKR '.$detail->member_retail_price.'.00</span>';
                                    }
                                    else{
                                        $pr_price = $detail->member_retail_price_new;
                                        $product_price = '
                                                <span class="price-new">PKR '.$detail->member_retail_price_new.'.00</span>  <del><span class="price-old" style="color:#b5b4b4; font-size:12px;">PKR '.$detail->member_retail_price.'.00</span></del>';
                                    }


                   

                                    if(empty($detail->sub_image))
                                    {
                                        $img = 'member_product_assets/img/products/z1.jpg';
                                    }
                                    else{
                                        $img = 'product_images/'.$detail->sub_image.'';
                                    }
                } ?>
					<div class="single-list-view">
						<div class="col-xs-12 col-sm-5 col-md-4">
							<div class="quick-image">
								<div class="single-quick-image text-center">
									<div class="list-img">
										<div class="product-img tab-content">
											<div class="simpleLens-container tab-pane fade in" id="sin-1">
												<div class="pro-type">
													<!-- <span>new</span> -->
												</div>
												<a class="simpleLens-image" data-lens-image="<?php echo base_url($img); ?>" href="#"><img src="<?php echo base_url($img); ?>" alt="" class="simpleLens-big-image"></a>
											</div>
											<div class="simpleLens-container tab-pane active fade in" id="sin-2">
												<div class="pro-type sell">
													<span>sell</span>
												</div>
												<a class="simpleLens-image" data-lens-image="<?php echo base_url(); ?>member_product_assets/img/products/z2.jpg" href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/z2.jpg" alt="" class="simpleLens-big-image"></a>
											</div>
											<div class="simpleLens-container tab-pane fade in" id="sin-3">
												<div class="pro-type">
													<span>-15%</span>
												</div>
												<a class="simpleLens-image" data-lens-image="<?php echo base_url(); ?>member_product_assets/img/products/z3.jpg" href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/z3.jpg" alt="" class="simpleLens-big-image"></a>
											</div>
											<div class="simpleLens-container tab-pane fade in" id="sin-4">
												<div class="pro-type">
													<span>new</span>
												</div>
												<a class="simpleLens-image" data-lens-image="<?php echo base_url(); ?>member_product_assets/img/products/z4.jpg" href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/z4.jpg" alt="" class="simpleLens-big-image"></a>
											</div>
										</div>
									</div>
								</div>
								<div class="quick-thumb">
									<ul class="product-slider">
										<li class="active"><a data-toggle="tab" href="#sin-1"> <img src="<?php echo base_url($img); ?>" alt="quick view" /> </a></li>
										<li ><a data-toggle="tab" href="#sin-2"> <img src="<?php echo base_url(); ?>member_product_assets/img/products/s2.jpg" alt="small image" /> </a></li>
										<li><a data-toggle="tab" href="#sin-3"> <img src="<?php echo base_url(); ?>member_product_assets/img/products/s3.jpg" alt="small image" /> </a></li>
										<li><a data-toggle="tab" href="#sin-4"> <img src="<?php echo base_url(); ?>member_product_assets/img/products/s4.jpg" alt="small image" /> </a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-sm-7 col-md-8">
							<div class="quick-right">
								<div class="list-text">
									<h3><?php echo $detail->product_name; ?></h3>
									<span><?php echo $detail->category_name; ?></span>
									<br>
									<br>
									<br>
									<h6><?php echo $detail->product_id; ?></h6>
									<h6><?php echo $detail->brand; ?></h6>
									
									<h5> <?php echo $product_price; ?>

									<p><?php $str = $detail->description; $head = explode(' ', $str, 4);  echo $head[0].' '.$head[1].' '.$head[2]; ?></p>

									<div class="all-choose">
										
										<div class="s-shoose">
											<h5>P</h5>
											<div class="size-drop">
												<input type="hidden" name="product_id" id="product_id" value="<?php echo $detail->product_id; ?>">
												<div class="btn-group">
													
													<!-- <input type="text" name="no_of_cv" value="<?php// echo $detail->no_of_cv; ?>"> -->
													<h4><?php echo $detail->no_of_cv; ?></h4>
												</div>
											</div>
										</div>

										<div class="s-shoose">
											<h5>size</h5>
											<div class="size-drop">
												<input type="hidden" name="product_id" id="product_id" value="<?php echo $detail->product_id; ?>">
												<div class="btn-group">
													
													<select class="form-control" style="width: 100%;" name="size" id="size" required="required">
														<option>Select Size</option>
						                                <?php foreach ($sizes as $value) {?>
						                                <option value="<?php echo $value->id.','.$value->size; ?>"><?php echo $value->size; ?></option>        
						                                <?php } ?>
						                                
						                            </select>
												</div>
											</div>
										</div>

										<div class="s-shoose">
											<h5>Color</h5>
											<div class="size-drop">
												
												<div class="btn-group">
													
													<select class="form-control"  name="color" id="color">
                               
                                
                            						</select>
												</div>
											</div>
											 <div id="stock"></div>
										</div>

									
											<h5>Availability</h5>
											<div class="size-drop">
												<div class="btn-group">
													  <?php if(empty($sizes)){?>
							                                <span style="color: red;">Out of Stock</span>
							                            <?php } elseif (!empty($sizes)) {?>
							                            <p> In Stock</p>    
							                            <?php } ?>
												</div>
											</div>
										

										<div class="s-shoose">
											<h5>qty</h5>
											<form action="#" method="POST">
												<div class="plus-minus">
													<a class="dec qtybutton">-</a>
													<input type="text" value="1" name="product_quantity" id="product_quantity" class="plus-minus-box">
													<a class="inc qtybutton">+</a>
												</div>
											</form>
										</div>
									</div>
									<?php   $p_id = $this->uri->segment(3);
                                    foreach ($cart_data as $cart) {
                                        $c_id = $cart['Product_id'];
                                        $c_qty += $cart['qty'];

                                        if($p_id == $c_id){
                                            $now_id = $c_id;
                                            $now_qty = $c_qty;
                                        }

                                    } ?>
                            <input type="hidden" name="cart_product_id" id="cart_product_id" value="<?php echo $now_id ?>" />
                            <input type="hidden" name="cart_qty" id="cart_qty" value="<?php if(empty($cart_data)){ echo '0';}else{ echo $c_qty; }   ?>" />

									<div class="list-btn">
										<?php if(!empty($sizes)){?>
										<a href="#" class="add_to_cart_member" type="button" data-product_name="<?php echo $detail->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-product_id="<?php echo $detail->product_id; ?>" data-product_image="<?php echo $img; ?>"  data-no_of_cv="<?php echo $detail->no_of_cv; ?>" data-p_info_id = "<?php echo $this->uri->segment(4); ?>">add to cart</a>
										 <?php } ?>
										<a type="button" data-product_id="<?php echo $detail->product_id; ?>" class="wishlist">wishlist</a>

										
									</div>
									<div class="share-tag clearfix">
									<!-- 	<ul class="blog-share floatleft">
											<li><h5>share </h5></li>
											<li><a href="#"><i class="mdi mdi-facebook"></i></a></li>
											<li><a href="#"><i class="mdi mdi-twitter"></i></a></li>
											<li><a href="#"><i class="mdi mdi-linkedin"></i></a></li>
											<li><a href="#"><i class="mdi mdi-vimeo"></i></a></li>
											<li><a href="#"><i class="mdi mdi-dribbble"></i></a></li>
											<li><a href="#"><i class="mdi mdi-instagram"></i></a></li>
										</ul> -->
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- single-product item end -->
				<!-- reviews area start -->
								<div class="row">
					<div class="col-xs-12">
						<div class="reviews padding60 margin-top">
							<ul class="reviews-tab clearfix">
								<li class="active"><a data-toggle="tab" href="#moreinfo">Product Video</a></li>
								<!-- <li ><a data-toggle="tab" href="#reviews">Reviews</a></li>
								<li><a data-toggle="tab" href="#tags">tags</a></li> -->
							</ul>
							<div class="tab-content">
								<div class="info-reviews moreinfo tab-pane fade in active" id="moreinfo">
									<iframe id="youtube" width="100%" height="400px" src="<?php echo $detail->video_url; ?>" frameborder="0" allow="encrypted-media" allowfullscreen></iframe>
								</div>
								
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12">
						<div class="reviews padding60 margin-top">
							<ul class="reviews-tab clearfix">
								<li class="active"><a data-toggle="tab" href="#moreinfo">more info</a></li>
								<!-- <li ><a data-toggle="tab" href="#reviews">Reviews</a></li>
								<li><a data-toggle="tab" href="#tags">tags</a></li> -->
							</ul>
							<div class="tab-content">
								<div class="info-reviews moreinfo tab-pane fade in active" id="moreinfo">
									<p><?php $str = $detail->description; $head = explode(' ', $str, 4);  echo $head[0].' '.$head[1].' '.$head[2]; ?></p>
									<p><p><?php echo $detail->description; ?></p></p>
								</div>

								
							</div>
						</div>
					</div>
				</div>
				<!-- reviews area end -->
			

				<div class="row">
					<div class="col-xs-12">
						<div class="reviews padding60 margin-top">
							<ul class="reviews-tab clearfix">
								<li class="active"><a data-toggle="tab" href="#moreinfo">Recent Comments</a></li>
								<!-- <li ><a data-toggle="tab" href="#reviews">Reviews</a></li>
								<li><a data-toggle="tab" href="#tags">tags</a></li> -->
							</ul>
							                <div class="card">
                    <div class="card-body">
                        <h6 class="card-subtitle">Latest Comments section by users</h6>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url('member/new_product_details/'.$this->uri->segment(3).'/'.$this->uri->segment(4).''); ?>" method="post" enctype='multipart/form-data'>
                            <div id="review"></div>
                            <h2>Write a review</h2>
                            <div class="form-group required">
                                <div class="col-sm-12">
                                    <label class="control-label" for="input-name">Your Name</label>
                                    <input type="text" name="name" value="" id="input-name" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group required">
                                <div class="col-sm-12">
                                    <label class="control-label" for="input-review">Your Review</label>
                                    <textarea name="review" rows="5" id="input-review" class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="form-group required">
                                <div class="col-sm-12">
                                    <label class="control-label">Rating</label>
                                       <div class="rate">
                                        <input type="radio" class="inpt" id="star5" name="rating" value="5" />
                                        <label for="star5" title="text" class="str">5 stars</label>
                                        <input type="radio" class="inpt" id="star4" name="rating" value="4" />
                                        <label for="star4" title="text" class="str">4 stars</label>
                                        <input type="radio" class="inpt" id="star3" name="rating" value="3" />
                                        <label for="star3" title="text" class="str">3 stars</label>
                                        <input type="radio" class="inpt" id="star2" name="rating" value="2" />
                                        <label for="star2" title="text" class="str">2 stars</label>
                                        <input type="radio" class="inpt" id="star1" name="rating" value="1" />
                                        <label for="star1" title="text" class="str">1 star</label>
                                      </div>


                                </div>
                            </div>
                            <div class="form-group">
                                    <label>Choose Multiple Images</label>
                                    <input type="file" name="userfile[]" class="form-control" id="userfile" placeholder="Enter Product Images" required="" multiple="multiple">
                                </div> 
                            <div class="buttons clearfix">
                                <div class="pull-right">
                                    <button type="submit" id="button-review" data-loading-text="Loading..." name="submit_review" value="Submit Review" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    <div class="comment-widgets m-b-20">



                    	<?php foreach ($rating as $review):?>
                        <div class="d-flex flex-row comment-row">

                            <div class="comment-text w-100">
                                <h5><?php echo $review->customer_name; ?></h5>

                                <div class="form-group required">
                                
                                       <div class="rate">
                                        <input type="radio" <?php if($review->rating == '5'){ echo 'checked="checked"';} ?> class="inpt" id="star5" name="rating_<?php echo $review->id; ?>" value="5" />
                                        <label for="star5" title="text" class="str">5 stars</label>
                                        <input type="radio" <?php if($review->rating == '4'){ echo 'checked="checked"';} ?> class="inpt" id="star4" name="rating_<?php echo $review->id; ?>" value="4" />
                                        <label for="star4" title="text" class="str">4 stars</label>
                                        <input type="radio" <?php if($review->rating == '3'){ echo 'checked="checked"';} ?> class="inpt" id="star3" name="rating_<?php echo $review->id; ?>" value="3" />
                                        <label for="star3" title="text" class="str">3 stars</label>
                                        <input type="radio" <?php if($review->rating == '2'){ echo 'checked="checked"';} ?> class="inpt" id="star2" name="rating_<?php echo $review->id; ?>" value="2" />
                                        <label for="star2" title="text" class="str">2 stars</label>
                                        <input type="radio" <?php if($review->rating == '1'){ echo 'checked="checked"';} ?> class="inpt" id="star1" name="rating_<?php echo $review->id; ?>" value="1" />
                                        <label for="star1" title="text" class="str">1 star</label>
                                      </div>


                               
                            </div>
                            <!-- <button class="btn btn-danger" style="float: right;">Delete Review</button> -->
                                <div class="comment-footer"> <span class="date">	<?php echo date('M, d Y', strtotime($review->created_at)); ?></span>  <span class="action-icons"> <a href="<?php echo base_url('admin/delete_review/'.$review->product_id.'/'.$review->id.''); ?>" data-abc="true"><i class="fa fa-trash"></i></a> </span> </div>
                                <p class="m-b-5 m-t-10"><?php echo $review->review; ?></p>
                            </div>
                        </div>
                        <hr>
                    <?php endforeach; ?>
                       
                       
                        
                    
                    </div>
                </div>
						</div>
					</div>
				</div>


				














			</div>
		</div>
		<!-- product-details section end -->
        <!-- related-products section start -->
		<!-- <section class="single-products section-padding">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="section-title text-center">
							<h2>related Products</h2>
						</div>
					</div>
				</div>
				<div class="row text-center">
					<div class="col-xs-12 col-sm-6 col-md-3">
						<div class="single-product">
							<div class="product-img">
								<div class="pro-type">
									<span>new</span>
								</div>
								<a href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/1.jpg" alt="Product Title" /></a>
								<div class="actions-btn">
									<a href="#"><i class="mdi mdi-cart"></i></a>
									<a href="#" data-toggle="modal" data-target="#quick-view"><i class="mdi mdi-eye"></i></a>
									<a href="#"><i class="mdi mdi-heart"></i></a>
								</div>
							</div>
							<div class="product-dsc">
								<p><a href="#">men’s Black t-shirt</a></p>
								<span>$65.20</span>
							</div>
						</div>
					</div>
					
					<div class="col-xs-12 col-sm-6 col-md-3">
						<div class="single-product">
							<div class="product-img">
								<div class="pro-type sell">
									<span>sell</span>
								</div>
								<a href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/2.jpg" alt="Product Title" /></a>
								<div class="actions-btn">
									<a href="#"><i class="mdi mdi-cart"></i></a>
									<a href="#" data-toggle="modal" data-target="#quick-view"><i class="mdi mdi-eye"></i></a>
									<a href="#"><i class="mdi mdi-heart"></i></a>
								</div>
							</div>
							<div class="product-dsc">
								<p><a href="#">men’s White t-shirt</a></p>
								<span>$57.00</span>
							</div>
						</div>
					</div>
					
					<div class="col-xs-12 col-sm-6 col-md-3 r-margin-top">
						<div class="single-product">
							<div class="product-img">
								<div class="pro-type">
									<span>-15%</span>
								</div>
								<a href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/3.jpg" alt="Product Title" /></a>
								<div class="actions-btn">
									<a href="#"><i class="mdi mdi-cart"></i></a>
									<a href="#" data-toggle="modal" data-target="#quick-view"><i class="mdi mdi-eye"></i></a>
									<a href="#"><i class="mdi mdi-heart"></i></a>
								</div>
							</div>
							<div class="product-dsc">
								<p><a href="#">men’s Blue t-shirt</a></p>
								<span>$56.00</span>
							</div>
						</div>
					</div>
					
					<div class="col-xs-12 col-sm-6 col-md-3 r-margin-top">
						<div class="single-product">
							<div class="product-img">
								<a href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/4.jpg" alt="Product Title" /></a>
								<div class="actions-btn">
									<a href="#"><i class="mdi mdi-cart"></i></a>
									<a href="#" data-toggle="modal" data-target="#quick-view"><i class="mdi mdi-eye"></i></a>
									<a href="#"><i class="mdi mdi-heart"></i></a>
								</div>
							</div>
							<div class="product-dsc">
								<p><a href="#">men’s White t-shirt</a></p>
								<span>$96.20</span>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</section> -->
		<!-- related-products section end -->
        <!-- quick view start -->
		<!-- <div class="product-details quick-view modal animated zoomInUp" id="quick-view">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="d-table">
							<div class="d-tablecell">
								<div class="modal-dialog">
									<div class="main-view modal-content">
										<div class="modal-footer" data-dismiss="modal">
											<span>x</span>
										</div>
										<div class="row">
											<div class="col-xs-12 col-sm-5 col-md-4">
												<div class="quick-image">
													<div class="single-quick-image text-center">
														<div class="list-img">
															<div class="product-img tab-content">
																<div class="simpleLens-container tab-pane fade in" id="q-sin-1">
																	<div class="pro-type">
																		<span>new</span>
																	</div>
																	<a class="simpleLens-image" data-lens-image="<?php echo base_url(); ?>member_product_assets/img/products/z1.jpg" href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/z1.jpg" alt="" class="simpleLens-big-image"></a>
																</div>
																<div class="simpleLens-container tab-pane active fade in" id="q-sin-2">
																	<div class="pro-type sell">
																		<span>sell</span>
																	</div>
																	<a class="simpleLens-image" data-lens-image="<?php echo base_url(); ?>member_product_assets/img/products/z2.jpg" href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/z2.jpg" alt="" class="simpleLens-big-image"></a>
																</div>
																<div class="simpleLens-container tab-pane fade in" id="q-sin-3">
																	<div class="pro-type">
																		<span>-15%</span>
																	</div>
																	<a class="simpleLens-image" data-lens-image="<?php echo base_url(); ?>member_product_assets/img/products/z3.jpg" href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/z3.jpg" alt="" class="simpleLens-big-image"></a>
																</div>
																<div class="simpleLens-container tab-pane fade in" id="q-sin-4">
																	<div class="pro-type">
																		<span>new</span>
																	</div>
																	<a class="simpleLens-image" data-lens-image="<?php echo base_url(); ?>member_product_assets/img/products/z4.jpg" href="#"><img src="<?php echo base_url(); ?>member_product_assets/img/products/z4.jpg" alt="" class="simpleLens-big-image"></a>
																</div>
															</div>
														</div>
													</div>
													<div class="quick-thumb">
														<ul class="product-slider">
															<li><a data-toggle="tab" href="#q-sin-1"> <img src="<?php echo base_url(); ?>member_product_assets/img/products/s1.jpg" alt="quick view" /> </a></li>
															<li class="active"><a data-toggle="tab" href="#q-sin-2"> <img src="<?php echo base_url(); ?>member_product_assets/img/products/s2.jpg" alt="small image" /> </a></li>
															<li><a data-toggle="tab" href="#q-sin-3"> <img src="<?php echo base_url(); ?>member_product_assets/img/products/s3.jpg" alt="small image" /> </a></li>
															<li><a data-toggle="tab" href="#q-sin-4"> <img src="<?php echo base_url(); ?>member_product_assets/img/products/s4.jpg" alt="small image" /> </a></li>
														</ul>
													</div>
												</div>						
											</div>
											<div class="col-xs-12 col-sm-7 col-md-8">
												<div class="quick-right">
													<div class="list-text">
														<h3>men’s White t-shirt</h3>
														<span>Summer men’s fashion</span>
														<div class="ratting floatright">
															<p>( 27 Rating )</p>
															<i class="mdi mdi-star"></i>
															<i class="mdi mdi-star"></i>
															<i class="mdi mdi-star"></i>
															<i class="mdi mdi-star-half"></i>
															<i class="mdi mdi-star-outline"></i>
														</div>
														<h5><del>$79.30</del> $69.30</h5>
														<p>There are many variations of passages of Lorem Ipsum available, but the majority have be suffered alteration in some form, by injected humour, or randomised words which donot look even slightly believable. If you are going to use a passage of Lorem Ipsum, you neede be sure there isn't anything embarrassing hidden in the middle of text. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
														<div class="all-choose">
															<div class="s-shoose">
																<h5>Color</h5>
																<div class="color-select clearfix">
																	<span></span>
																	<span class="outline"></span>
																	<span></span>
																	<span></span>
																</div>
															</div>
															<div class="s-shoose">
																<h5>size</h5>
																<div class="size-drop">
																	<div class="btn-group">
																		<button type="button" class="btn">XL</button>
																		<button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
																			<span class=""><i class="mdi mdi-chevron-down"></i></span>
																		</button>
																		<ul class="dropdown-menu">
																			<li><a href="#">Xl</a></li>
																			<li><a href="#">SL</a></li>
																			<li><a href="#">S</a></li>
																			<li><a href="#">L</a></li>
																		</ul>
																	</div>
																</div>
															</div>
															<div class="s-shoose">
																<h5>qty</h5>
																<form action="#" method="POST">
																	<div class="plus-minus">
																		<a class="dec qtybutton">-</a>
																		<input type="text" value="02" name="qtybutton" class="plus-minus-box">
																		<a class="inc qtybutton">+</a>
																	</div>
																</form>
															</div>
														</div>
														<div class="list-btn">
															<a href="#">add to cart</a>
															<a href="#">wishlist</a>
															<a href="#">zoom</a>
														</div>
														<div class="share-tag clearfix">
															<ul class="blog-share floatleft">
																<li><h5>share </h5></li>
																<li><a href="#"><i class="mdi mdi-facebook"></i></a></li>
																<li><a href="#"><i class="mdi mdi-twitter"></i></a></li>
																<li><a href="#"><i class="mdi mdi-linkedin"></i></a></li>
																<li><a href="#"><i class="mdi mdi-vimeo"></i></a></li>
																<li><a href="#"><i class="mdi mdi-dribbble"></i></a></li>
																<li><a href="#"><i class="mdi mdi-instagram"></i></a></li>
															</ul>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div> -->
		<!-- quick view end -->
