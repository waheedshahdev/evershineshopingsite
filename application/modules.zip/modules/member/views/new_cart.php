
        <!-- cart content section start -->
        <section class="pages cart-page section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="table-responsive padding60">
                            <table class="wishlist-table text-center">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Price</th>
                                        <th>P</th>
                                        <th>quantity</th>
                                        <th>Total Price</th>
                                        <th>Remove</th>
                                    </tr>
                                </thead>
                                <tbody>
                                	  	 <?php 
                                $this->load->library('cart');
                                $cart_data = $this->cart->contents();
                                if (empty($cart_data)){ $count = 0;} elseif (!empty($cart_data)) {
                                    $count == 1;
                                    foreach ($cart_data as $cart) {
                                    	$cart_qty_1 += $cart['qty']; 
                                    	$cv += $cart['cv'];
                                    	$cv_1 = $cart['cv'];
                                        $count++;
                                   		$get_size = get_query_data('SELECT * FROM tbl_product_sizes where id = '.$cart['size_id'].'');
                                    ?>
                                    <tr>
                                        <td class="td-img text-left">
                                            <a href="#"><img src="<?php echo base_url($cart['product_image']); ?>" alt="Add Product" /></a>
                                            <div class="items-dsc">
                                                <h5><a href="#"><?php echo $cart['name']; ?></a></h5>
                                                <p class="itemcolor">Color : <span><?php echo $get_size[0]->color; ?></span></p>
                                                <p class="itemcolor">Size   : <span><?php echo $get_size[0]->size; ?></span></p>
                                            </div>
                                        </td>
                                        <td>PKR <?php echo $cart['price'] ?>.00</td>
                                        <td><?php echo $cart['cv'] ?></td>
                                        <td>
                                            <form action="<?php echo base_url(); ?>member/update_quantity/<?php echo $cart['rowid'];?>" method = 'POST'>
                                                <div class="plus-minus">
                                                    <!-- <a class="dec qtybutton">-</a> -->
                                                    <input type="text" value="<?php echo $cart['qty']; ?>" name="quantity" class="plus-minus-box">
                                                    <input type="hidden" class="form-control" size="1" value="<?php echo $cart['cv']; ?>" name="cv">
                                                    <!-- <a href="" class="inc qtybutton">+</a> -->
                                                    <button data-toggle="tooltip" type="submit" data-original-title="Update" type="submit" class="btn btn-info"><i class="mdi mdi-pencil"></i></button>
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <strong>PKR <?php echo $cart['subtotal']; ?>.00</strong>
                                        </td>
                                        <td><a href="<?php echo base_url();?>member/remove_cart_item/<?php echo $cart['rowid'];?>"  class="text-inverse" title="" data-toggle="tooltip" data-original-title="Delete"><i class="mdi mdi-close" title="Remove this product"></i></a></td>
                                    </tr>
                                      <?php  } } ?>
                                    
                                  
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row margin-top">
                    <div class="col-sm-6">
                        <div class="single-cart-form padding60">
                            <div class="log-title">
                                <h3><strong>coupon discount</strong></h3>
                            </div>
                            <div class="cart-form-text custom-input">
                                <p>Enter your coupon code if you have one!</p>
                                <form action="mail.php" method="post">
                                    <input type="text" name="subject" placeholder="Enter your code here..." />
                                    <div class="submit-text coupon">
                                        <button type="submit">apply coupon </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- <?php //print_r($cart_data); ?> -->
                    <div class="col-sm-6">
                        <div class="single-cart-form padding60">
                            <div class="log-title">
                                <h3><strong>payment details</strong></h3>
                            </div>
                            <div class="cart-form-text pay-details table-responsive">
                                <table>
                                    <tbody>
                                        <tr>
                                            <th>Cart Subtotal</th>
                                            <td>PKR <?php echo $this->cart->total(); ?>.00</td>
                                        </tr>
                                        <!-- <tr>
                                            <th>Shipping and Handing</th>
                                            <td>$15.00</td>
                                        </tr> -->

                                       
                                        <tr>
                                            <th>Total CV</th>
                                            <td><?php $total_cv = $cv_1 * $cart_qty_1; echo $total_cv; ?></td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th class="tfoot-padd">Order total</th>
                                            <td class="tfoot-padd">PKR <?php echo $this->cart->total(); ?>.00</td>
                                        </tr>
                                        <tr>
                                        	<th class="tfoot-padd"></th>
                                        	<td class="tfoot-padd"><?php if(empty($cart_data)){?><a href="#" class="btn btn-danger" style="float: right;" disabled> Cart is Empty!</a> <?php }else{?><a href="<?php echo base_url('member/checkout'); ?>" class="btn btn-danger" style="float: right;"> Proceed to Checkout</a><?php } ?></td>
                                        </tr>
                                    </tfoot>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>

