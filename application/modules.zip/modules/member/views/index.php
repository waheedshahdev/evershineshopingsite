            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item active"><a href="#"><?php echo $title; ?></a></li>
                                    <!-- <li class="breadcrumb-item active" aria-current="page">Library</li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="text-right upgrade-btn">
                            
                        </div>
                    </div>
                </div>
            </div>
            








            <div class="container-fluid">


                 <?php 
             if($this->session->flashdata("error_msg") != ''){?>
             <div class="alert alert-danger" style="text-align: center;">
                 <button class="close" data-dismiss="alert" ></button>
                 <?php echo $this->session->flashdata("error_msg");?>
             </div>
          <?php
            }
          ?>
          <?php 
             if($this->session->flashdata("success") != ''){?>
             <div class="alert alert-success">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("success");?>
             </div>
          <?php
            }
          ?>














                <div class="row">
                <div class="col-lg-12 col-xlg-12 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                 <button class="btn btn-primary" style="float: right;">Guide</button>
                                <div class="row">

                                    <div class="col-md-2 text-center">
                                        <?php if($get_data[0]->profile_pic == ''){ $pro_pic = 'new_adminfiles/assets/image/users/5.jpg';} else{ $pro_pic = 'member_pic/'.$get_data[0]->profile_pic;} ?>
                                        <img src="<?php echo base_url($pro_pic); ?>"
                                        class="rounded-circle" width="150" height="150" />
                                    </div>
                                    <div class="col-md-2">
                                        <h4 class="card-title mt-3"><?php echo $get_data[0]->member_name; ?></h4>
                                        <?php $rank = $get_data[0]->rank;
                                                            $get_next_rank = get_query_data('SELECT * FROM tbl_ranking where id = '.$rank.'');
                                                                ?>
                                        <p><?php if(empty($get_data[0]->rank))
                                                        { echo 'No Rank yet';
                                                        $rank_image = '';
                                                        } else{
                                                            
                                                            $rank_image = '<img src="'.base_url('ranks/'.$get_next_rank[0]->rank_image).'" style="width: 100px; height: 100px;">';
                                                         echo $get_next_rank[0]->rank;
                                                        } ?> | <?php echo $get_data[0]->member_code; ?></p>
                                        <h6 class="card-subtitle">Joined <?php echo $get_data[0]->create_date; ?></h6>
                                        <a href="#" data-toggle="modal" data-target="#myModal">Referral Link</a>
                                    </div>
                                    <div class="col-md-3 pt-3">
                                        <!-- <i class="fab fa-big fa-facebook-f fa-4x"></i> -->
                                        <!-- <img src="<?php //echo base_url(); ?>new_adminfiles/assets/image/users/3.png"> -->
                                        
                                       <?php echo $rank_image; ?>
                                    </div>
                                </div>
                                
                            </div>
                            <?php if(!empty($get_current_orders)){?>
                            <div>
                                <div class="alert alert-danger mb-0" role="alert" style="text-align: center;">
                                  Your Payment is Pending! Please go back to your order and complete the order.
                                </div>
                                <hr class="mt-0 mb-0">
                            </div>
                            <?php } ?>
                        
                        </div>
                    </div>



                    </div>



                    <!-- Referal Link Modal -->
                    <div class="container">
                          <div class="modal fade" id="myModal" role="dialog">
                            <div class="modal-dialog modal-lg">
                              <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Your Referal Link</h4>
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  
                                </div>
                               

                                     <div class="modal-body">
                                        <p>Copy the below link and send it to your friends and family.</p>
                              <div class="card">
                      
                                        <div class="card-body">
                                     
                                 
                                      <div class="form-group">

                                       
                                          <!-- <a href="#"></a> -->
                                          <input class="form-control" type="text" value="<?php echo base_url('member/referal_member/'.encode_id($get_data[0]->member_code).'/IFi2W51JCg76Dovr6yFU'); ?>" id="textInput" readonly>
                                         <button onclick="copyText()" style="margin-top: 10px; float: right;" class="btn btn-success">Copy Link</button>
                                      </div>


                                        </div>
                                    </div>



                        </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                    <!-- Referal Modal -->





<script>
function copyText(){
    var text = document.getElementById("textInput");
    text.select();
    document.execCommand("copy");
    Swal.fire({ icon: 'success', title: 'Success', text: 'Referal Link Copied!', })

}
</script>





                <?php 

                foreach ($get_data as $value) {
                    
                } ?>

                <div class="row">
                    
                    <div class="col-sm-12">
                        <h3 style="text-align: right;"><?php $rank = $value->rank;
                                                            $get_next_rank = get_query_data('SELECT * FROM tbl_ranking where id = '.$rank.'');
                                                                if($rank == ''){ 
                                                                    echo 'No Rank yet';
                                                                }else{
                                                                    echo $get_next_rank[0]->rank;
                                                                } ?>
                                                                    
                                                                </h3>
                        <div class="card order-widget">
                            <div class="card-body">

                                <div class="row">
                                    <!-- column -->
                                       
                                    <div class="col-sm-12 col-md-12">
                                        <div class="row">
                                            <div class="col-md-6 border-right text-center">
                                                <h4 class="card-title" style="font-weight: bold;">Current Status</h4>
                                                <h5 class="card-subtitle mb-0">Current Level</h5>
                                                <div class="row mt-3">
                                                    <div class="col-6 border-right">
                                                        <i class="fa fa-circle text-orange"></i>
                                                        <h3 class="mb-0 font-medium"><?php echo $value->pcv; ?></h3>
                                                        <!-- <span>PCV</span> -->
                                                        <span>PP</span>
                                                    </div>
                                                    <div class="col-6">
                                                        <i class="fa fa-circle text-cyan"></i>
                                                        <h3 class="mb-0 font-medium"><?php echo $value->tcv; ?></h3>
                                                        <!-- <span>TCV</span> -->
                                                        <span>RP</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 text-center">
                                                <h4 class="card-title"  style="font-weight: bold;">Required Status</h4>
                                                <h5 class="card-subtitle mb-0">Next Level</h5>
                                                <?php 
                                                    $rank = $value->rank;
                                                    // $get_rank_id = get_query_data('SELECT id FROM tbl_ranking where rank = "'.$rank.'"');

                                                    if($rank == '')
                                                    {
                                                        $where = 'order by id ASC LIMIT 1';
                                                    }
                                                    else{
                                                        $where = ' where id > '.$rank.' LIMIT 1';
                                                    }
                                                    
                                                    $get_next_rank = get_query_data('SELECT * FROM tbl_ranking '.$where.'');

                                                 ?>
                                                <div class="row mt-3">
                                                    <div class="col-6 border-right">
                                                        <i class="fa fa-circle text-orange"></i>
                                                        <h3 class="mb-0 font-medium"><?php echo $get_next_rank[0]->rank_pcv; ?></h3>
                                                        <!-- <span>PCV</span> -->
                                                        <span>PP</span>
                                                    </div>
                                                    <div class="col-6">
                                                        <i class="fa fa-circle text-cyan"></i>
                                                        <h3 class="mb-0 font-medium"><?php echo $get_next_rank[0]->rank_tcv; ?></h3>
                                                        <!-- <span>TCV</span> -->
                                                        <span>RP</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
                <!-- ============================================================== -->
                <!-- Sales chart -->
                <!-- ============================================================== -->

            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-md-flex align-items-center">
                                <div>
                                    <h4 style="font-weight: bold;" class="card-title">Credit Balance</h4>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table no-wrap v-middle">
                                    <thead>
                                        <tr class="border-0">
                                            <th class="border-0">Available Credit (Balance in E-Wallet)</th>
                                            <th class="border-0">In Rs.</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Team Downlines Direct</td>
                                            <td><?php echo $team_direct; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Team Downlines 1st Indirect</td>
                                            <td><?php echo $team_first_indirect; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-md-flex align-items-center">
                                <div>
                                    <h4 style="font-weight: bold;" class="card-title">Team Performance</h4>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table no-wrap v-middle">
                                    <thead>
                                        <tr class="border-0">
                                            <th class="border-0">Top Earners</th>
                                            <th class="border-0">Rank</th>
                                            <th class="border-0">Direct Members</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>010216 <i class="mdi mdi-pin"></i></td>
                                            <td>Scarlet Star</td>
                                            <td>12</td>
                                        </tr>
                                        <tr>
                                            <td>1472 <i class="mdi mdi-pin"></i></td>
                                            <td>Novel Star</td>
                                            <td>5</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                
            <div class="row">
                    <!-- col -->
                    <div class="col-lg-12 col-md-6">
                        <div class="card ">
                            <div class="card-body">
                                <h4 class="card-title mb-4" style="color: #002aaa; font-size: 30px;"><center>ZEALOUS SMART MARKETING ZSM</center></h4>
                                <p style="text-align: justify; color: black !important;
    font-size: 16px;">We welcome you to Zealous Smart Marketing. It's a wise decision for you to join us. We hope that you will find ease and success in your life by working according to our rules & regulations.</p>
                                            <p style="text-align: justify;     color: black !important;
    font-size: 16px;">There are exclusive videos to guide you, watch and understand them & if you have any queries, feel free to contact us on our WhatsApp Number
                                             Do like us on our Facebook page and follow us on Instagram, Tik Tok & also Subscribe to our YouTube channel to stay updated.
                                             You can also join the WhatsApp group and for that you should contact your referee (who has joined you).
                                            Thank You,
                                            </p>
                                            <br>
                                            <p style="color: black !important;
    font-size: 16px;">ہم آپ کو ذائلس اسمارٹ مارکیٹنگ میں خوش آمدید کہتے ہیں یہ آپ کا بہت ہی مدبرانہ فیصلہ ہے کے آپ نے ہمیں جوائن کیا۔ ہم امید کرتے ہیں کہ آپ ہمارے دیے گئے اصول و ضوابط کے مطابق کام کرتے ہوئے  اپنی زندگی میں آسانیاں اور کامیابیاں پائیں گے۔
                                                آپ کی رہنمائی کے لیے خصوصی ویڈیوز موجود ہے انہیں دیکھے اور سمجھے اور پھر بھی اگر کسی قسم کا کوئی سوال ہو تو ہمارے دیے گئے واٹس ایپ نمبر پر بلا جھجک رابطہ فرمائیں۔ 

                                                آپ ہمارے فیس بک پیج کو لائک کرلیں اور انسٹاگرام اور ٹک ٹوک پر ہمیں فالو بھی کرے ساتھ ہی ساتھ ہمارے یوٹیوب چینل کو سبسکرائب بھی کر لیں تاکہ ہر قسم کی معلومات سے آپ کو جلد از جلد آگاہ کیا جاسکے۔
                                                 آپ واٹس ایپ گروپ بھی جوائن کر سکتے ہیں اور اس کے لئے آپ کو اپنے ریفری( جس نے آپ کو جوائن کروایا ہے) سے کانٹیکٹ کرے۔ 
                                                شکریہ
                                                </p>
                              
                            </div>
                        </div>
                    </div>
                    
                </div>

                            <div class="row">
                    <!-- col -->
                    <div class="col-lg-6 col-md-6">
                        <div class="card ">
                            <div class="card-body">
                                <h4 class="card-title mb-4" style="color: #002aaa; font-size: 25px;">Links</h4>
                                <button class="btn btn-info btn-lg">SOCIAL LINKS</button>
                                
                              
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-6">
                        <div class="card ">
                            <div class="card-body">
                                <h4 class="card-title mb-4" style="color: #002aaa; font-size: 25px;">Documents</h4>
                                <button class="btn btn-info btn-lg">GUIDE/TRAINING VIDEOS</button>
                              
                            </div>
                        </div>
                    </div>
                    
                </div>



            <div class="row">
                    <!-- col -->
                    <div class="col-lg-12 col-md-6">
                        <div class="card ">
                            <div class="card-body">
                                <h4 class="card-title mb-4">Current Order Details</h4>
                                <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Tracking</th>
                                    <th>Sub Total</th>
                                    <!-- <th>Promo Discount</th> -->
                                    <th>Grand Total</th>
                                    <th>CV</th>
                                    <th>payment</th>
                                    <th>Order Status</th>
                                    <th>Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($get_current_orders as $order):?>
                                    <tr>
                                        <td><?php echo $order->tracking_id; ?></td>
                                        <td><?php echo $order->sub_total; ?></td>
                                        <td><?php echo $order->order_grand_total; ?></td>
                                        <td><?php echo $order->cv; ?></td>
                                        <td><?php echo $order->order_payment_method; ?></td>
                                        <td><?php echo $order->order_status; ?></td>
                                        <td><?php echo $order->created_at; ?></td>
                                        <td><a href="<?php echo base_url('member/order_detail/'.$order->id.''); ?>" name="delete_shop_category" class="btn btn-info btn-xs">Detail</a></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>

                        </table>
                            </div>
                            </div>
                        </div>
                    </div>
                    
                </div>


                <!-- ============================================================== -->
                <!-- Table -->
                <!-- ============================================================== -->
                <div class="row">
                    <!-- col -->
                    <div class="col-lg-12 col-md-6">
                        <div class="card ">
                            <div class="card-body">
                                <h4 class="card-title mb-4">News & Activities</h4>
                                <div id="myCarousel1" class="carousel slide" data-ride="carousel">
                                    <!-- Carousel items -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item flex-column">
                                            <div class="d-flex no-block align-items-center">
                                                <img style="width: 100%; height: 300px;" src="<?php echo base_url(); ?>new_adminfiles/assets/image/banner1.webp" alt="">
                                            </div>
                                            
                                        </div>
                                        <div class="carousel-item flex-column active">
                                            <div class="d-flex no-block align-items-center">
                                                <img style="width: 100%; height: 300px;" src="<?php echo base_url(); ?>new_adminfiles/assets/image/space.webp" alt="">
                                            </div>
                                            
                                        </div>
                                        <div class="carousel-item flex-column">
                                            <div class="d-flex no-block align-items-center">
                                                <img style="width: 100%; height: 300px;" src="<?php echo base_url(); ?>new_adminfiles/assets/image/space2.webp" alt="">
                                            </div>
                                            <div class="row text-center text-white mt-4">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <!-- ============================================================== -->
                <!-- Table -->
                <!-- ============================================================== -->
             
            </div>