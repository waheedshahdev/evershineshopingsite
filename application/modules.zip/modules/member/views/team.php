





































                    <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item active"><a href="#"><?php echo $title; ?></a></li>
                                    <!-- <li class="breadcrumb-item active" aria-current="page">Library</li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="text-right upgrade-btn">
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
               <?php 
             if($this->session->flashdata("error_msg") != ''){?>
             <div class="alert alert-danger">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("error_msg");?>
             </div>
          <?php
            }
          ?>
          <?php 
             if($this->session->flashdata("success") != ''){?>
             <div class="alert alert-success">
                 <button class="close" data-dismiss="alert"></button>
                 <?php echo $this->session->flashdata("success");?>
             </div>
          <?php
            }
          ?>

                <div class="row">

                    <div class="col-12">

                        <div class="card">
                            <div class="card-body">
                                <!-- title -->
                                
                                <div class="d-md-flex align-items-center">

                                    <div>
                                        <h4 class="card-title">Direct Referals</h4>
                                    

                                    </div>

                                   
                                </div>
                            </div>
                            <div class="table-responsive" style="padding:0 15px;">
                                <table class="table product-overview dataTable no-footer">
							<thead>

								<tr>
									<th>#</th>
									<th>Referal Name</th>
									
									<th>Referal Email</th>
									<th>Referal Phone</th>
									<th>Referal Code</th>
									<th>Ranking</th>
									<th>Total CV Earned</th>
									<th>Total TCV Earned</th>
									
								</tr>
							</thead>
							<tbody>
								<?php $count = 1; foreach ($team_direct as $direct):?>
								<tr>
									<td><?php echo $count++; ?></td>
									<td><?php echo $direct->member_name; ?></td>
									<td><?php echo $direct->member_email; ?></td>
									<td><?php echo $direct->phone_number; ?></td>
									<td><?php echo $direct->member_code; ?></td>
									<td><?php echo $direct->ranking; ?></td>
									<td><?php echo $direct->pcv; ?></td>
									<td><?php echo $direct->tcv; ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>

						</table>
                            </div>



                        </div>
                    </div>
                </div>

                <div class="row">

                    <div class="col-12">

                        <div class="card">
                            <div class="card-body">
                                <!-- title -->
                                
                                <div class="d-md-flex align-items-center">

                                    <div>
                                        <h4 class="card-title">First Indirect Referals</h4>
                                    

                                    </div>

                                   
                                </div>
                            </div>
                            <div class="table-responsive" style="padding:0 15px;">
                                <table class="table product-overview dataTable no-footer">
							<thead>

								<tr>
									<th>#</th>
									<th>Referal Name</th>
									<th>Referal Email</th>
									<th>Referal Phone</th>
									<th>Referal Code</th>
									<th>Ranking</th>
									<th>Total CV Earned</th>
									<th>Total TCV Earned</th>
									
								</tr>
							</thead>
							<tbody>
								<?php $count = 1; foreach ($team_first_indirect as $direct):?>
								<tr>
									<td><?php echo $count++; ?></td>
									<td><?php echo $direct->member_name; ?></td>
									<td><?php echo $direct->member_email; ?></td>
									<td><?php echo $direct->phone_number; ?></td>
									<td><?php echo $direct->member_code; ?></td>
									<td><?php echo $direct->ranking; ?></td>
									<td><?php echo $direct->pcv; ?></td>
									<td><?php echo $direct->tcv; ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>

						</table>
                            </div>



                        </div>
                    </div>
                </div>

                <div class="row">

                    <div class="col-12">

                        <div class="card">
                            <div class="card-body">
                                <!-- title -->
                                
                                <div class="d-md-flex align-items-center">

                                    <div>
                                        <h4 class="card-title">Second Indirect Referals</h4>
                                    

                                    </div>

                                   
                                </div>
                            </div>
                            <div class="table-responsive" style="padding:0 15px;">
                                <table class="table product-overview dataTable no-footer">
							<thead>

								<tr>
									<th>#</th>
									<th>Referal Name</th>
									
									<th>Referal Email</th>
									<th>Referal Phone</th>
									<th>Referal Code</th>
									<th>Ranking</th>
									<th>Total CV Earned</th>
									<th>Total TCV Earned</th>
									
								</tr>
							</thead>
							<tbody>
								<?php $count = 1; foreach ($team_second_indirect as $direct):?>
								<tr>
									<td><?php echo $count++; ?></td>
									<td><?php echo $direct->member_name; ?></td>
									<td><?php echo $direct->member_email; ?></td>
									<td><?php echo $direct->phone_number; ?></td>
									<td><?php echo $direct->member_code; ?></td>
									<td><?php echo $direct->ranking; ?></td>
									<td><?php echo $direct->pcv; ?></td>
									<td><?php echo $direct->tcv; ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>

						</table>
                            </div>



                        </div>
                    </div>
                </div>


                <div class="row">

                    <div class="col-12">

                        <div class="card">
                            <div class="card-body">
                                <!-- title -->
                                
                                <div class="d-md-flex align-items-center">

                                    <div>
                                        <h4 class="card-title">Third Indirect Referals</h4>
                                    

                                    </div>

                                   
                                </div>
                            </div>
                            <div class="table-responsive" style="padding:0 15px;">
                                <table class="table product-overview dataTable no-footer">
							<thead>

								<tr>
									<th>#</th>
									<th>Referal Name</th>
									
									<th>Referal Email</th>
									<th>Referal Phone</th>
									<th>Referal Code</th>
									<th>Ranking</th>
									<th>Total P Earned</th>
									<th>Total RP Earned</th>
									
								</tr>
							</thead>
							<tbody>
								<?php $count = 1; foreach ($team_second_indirect as $direct):?>
								<tr>
									<td><?php echo $count++; ?></td>
									<td><?php echo $direct->member_name; ?></td>
									<td><?php echo $direct->member_email; ?></td>
									<td><?php echo $direct->phone_number; ?></td>
									<td><?php echo $direct->member_code; ?></td>
									<td><?php echo $direct->ranking; ?></td>
									<td><?php echo $direct->pcv; ?></td>
									<td><?php echo $direct->tcv; ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>

						</table>
                            </div>



                        </div>
                    </div>
                </div>






        
            </div>