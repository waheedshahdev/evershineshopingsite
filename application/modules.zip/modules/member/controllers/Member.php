<?php
class Member extends MX_Controller 
{

function __construct() {
parent::__construct();
}
public function member_ranking()
{
   if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {
        $member_code = $this->session->userdata('member_code');
        $fetch_points = get_query_data('SELECT pcv,tcv,rank FROM tbl_member where member_code = '.$member_code.'');
        // print_r($fetch_points);
        $pcv = $fetch_points[0]->pcv;
        $tcv = $fetch_points[0]->tcv;
        $rank = $fetch_points[0]->rank;
        // echo $pcv;
        // exit();
        if($pcv >= 50 && $pcv <= 149 && $tcv >= 200 && $tcv <= 849)
        {

            $rank_id = 1;
        //     echo $rank_id;
        // exit();
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 150 && $pcv <= 299 && $tcv >= 850 && $tcv <= 2249)
        {
            $rank_id = 2;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 300 && $pcv <= 499 && $tcv >= 2250 && $tcv <= 8199)
        {
            $rank_id = 3;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 500 && $pcv <= 749 && $tcv >= 8200 && $tcv <= 12199)
        {
            $rank_id = 4;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 750 && $pcv <= 1049 && $tcv >= 12200 && $tcv <= 18149)
        {
            $rank_id = 5;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 1050 && $pcv <= 1399 && $tcv >= 18150 && $tcv <= 26549)
        {
            $rank_id = 6;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 1400 && $pcv <= 1799 && $tcv >= 26550 && $tcv <= 38149)
        {
            $rank_id = 7;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 1800 && $pcv <= 2249 && $tcv >= 38150 && $tcv <= 53949)
        {
            $rank_id = 8;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 2250 && $pcv <= 2749 && $tcv >= 53950 && $tcv <= 74199)
        {
            $rank_id = 9;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 2750 && $pcv <= 3299 && $tcv >= 74200 && $tcv <= 102399)
        {
            $rank_id = 10;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 3300 && $pcv <= 3899 && $tcv >= 102400 && $tcv <= 139299)
        {
            $rank_id = 11;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 3900 && $pcv <= 4599 && $tcv >= 139300 && $tcv <= 187099)
        {
            $rank_id = 12;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 4600 && $pcv <= 5399 && $tcv >= 187100 && $tcv <= 248549)
        {
            $rank_id = 13;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 5400 && $pcv <= 6299 && $tcv >= 248550 && $tcv <= 326949)
        {
            $rank_id = 14;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 6300 && $pcv <= 7299 && $tcv >= 326950 && $tcv <= 427649)
        {
            $rank_id = 15;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 7300 && $pcv <= 8499 && $tcv >= 427650 && $tcv <= 556449)
        {
            $rank_id = 16;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 8500 && $pcv <= 9799 && $tcv >= 556450 && $tcv <= 718899)
        {
            $rank_id = 17;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 9800 && $pcv <= 11199 && $tcv >= 718900 && $tcv <= 902599)
        {
            $rank_id = 18;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 11200 && $pcv <= 12699 && $tcv >= 902600 && $tcv <= 1149399)
        {
            $rank_id = 19;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 12700 && $pcv <= 14299 && $tcv >= 1149400 && $tcv <= 1447399)
        {
            $rank_id = 20;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 14300 && $pcv <= 15999 && $tcv >= 1447400 && $tcv <= 1802949)
        {
            $rank_id = 21;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 16000 && $pcv <= 17799 && $tcv >= 1802950 && $tcv <= 2222649)
        {
            $rank_id = 22;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 17800 && $pcv <= 19699 && $tcv >= 2222650 && $tcv <= 2713749)
        {
            $rank_id = 23;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        elseif($pcv >= 19700 && $pcv <= 21700 && $tcv >= 2713750 && $tcv <= 3283750)
        {
            $rank_id = 24;
            if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
            }
            
        
        }
        else{
            $rank_id = 0;
            // if($rank != $rank_id){
                $data = array('rank' => $rank_id);
                $where = 'member_code = '.$member_code.'';
                update_data_by_where('tbl_member',$data,$where);
        
        }

        

    }
    else{
        redirect('member/login');
    }
     
}
public function index()
{
    if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {


        $member_code = $this->session->userdata('member_code');

        // $data['team_direct'] = get_query_data('SELECT * FROM tbl_tcv_member JOIN tbl_member on tbl_member.member_code = tbl_tcv_member.member_id where direct_referal='.$member_code.'');      
        $data = array(
                'get_data'               => get_query_data('SELECT *,date(created_at) as create_date FROM tbl_member where member_code = '.$member_code.''),
                'team_direct'            => get_total('member_id','tbl_tcv_member', 'direct_referal='.$member_code.''),
                'team_first_indirect'    => get_total('member_id','tbl_tcv_member', 'first_indirect='.$member_code.''),
                'team_second_indirect'   => get_total('member_id','tbl_tcv_member', 'second_indirect='.$member_code.''),
                'team_third_indirect'   => get_total('member_id','tbl_tcv_member', 'third_indirect='.$member_code.''),
                'get_current_orders'     => get_query_data('SELECT * FROM tbl_order where customer_id = '.$member_code.' and order_status = "Pending" order By created_at DESC'),
        );
       
        $this->member_ranking();
    $data['title'] = "Dashboard";
    $data['view_module'] = "member";
    $data['view_files'] = "index";
    $this->load->module("templates");
    $this->templates->member($data);

     }
    else{
        redirect('member/login');
    }
}





public function login()
{
    $this->load->view('member/login');
}

public function dashboard()
{
    if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {
       
            redirect('member','refresh');
    }
    else
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        if($email=="" || $password=="" ){   
            $this->session->set_flashdata('error_msg', 'Username or Password is empty. Please try again!');
            redirect(base_url().'admin/login');    
        }
        
        $user_login = array(
            'email' => $this->input->post('email'),
            'password' => $this->input->post('password')
        );
        $this->load->model('mdl_member');
        $data = $this->mdl_member->validate_credentials($user_login['email'],$user_login['password']);
        if($data)
        {
            $this->session->set_userdata('id',$data['id']);
            $this->session->set_userdata('member_email',$data['member_email']);
            $this->session->set_userdata('member_name',$data['member_name']);
            $this->session->set_userdata('member_code',$data['member_code']);
           redirect('member','refresh');
        }
        else
        {
            $this->session->set_flashdata('error_msg', 'You are Not Authorized Person, Contact to Administrator.');
            redirect('member/login');
        }   
    }
}

public function logout()
{
    $this->session->sess_destroy();
      redirect('member/login', 'refresh');
}



// image library. 



public function image_config($path_name){

                $path ='./'.$path_name.'/';
                $config['upload_path']          = $path;
                $config['allowed_types']        = 'gif|jpg|jpeg|png|mov|mpeg|zip';
                $config['max_size']             = 555550000000;
                $config['max_width']            = 555550000000;
                $config['max_height']           = 555550000000;
                $config['encrypt_name']         = true;
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

}

// End image uploading library


public function team()
{
  if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {
    $member_code = $this->session->userdata('member_code');    
    $data['team_direct'] = get_query_data('SELECT * FROM tbl_tcv_member JOIN tbl_member on tbl_member.member_code = tbl_tcv_member.member_id where direct_referal='.$member_code.'');    
    $data['team_first_indirect'] = get_query_data('SELECT * FROM tbl_tcv_member JOIN tbl_member on tbl_member.member_code = tbl_tcv_member.member_id where first_indirect='.$member_code.'');    
    $data['team_second_indirect'] = get_query_data('SELECT * FROM tbl_tcv_member JOIN tbl_member on tbl_member.member_code = tbl_tcv_member.member_id where second_indirect='.$member_code.'');   
    $data['team_third_indirect'] = get_query_data('SELECT * FROM tbl_tcv_member JOIN tbl_member on tbl_member.member_code = tbl_tcv_member.member_id where third_indirect='.$member_code.'');    
    $data['title'] = 'Team';
    $data['view_module'] = "member";
    $data['view_files'] = "team";
    $this->load->module("templates");
    $this->templates->member($data);

     }
    else{
        redirect('member/login');
    }

}

public function ranking()
{
  if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {

    $data['ranking'] = get_query_data('SELECT * FROM tbl_ranking');      
    $data['title'] = 'Ranking';
    $data['view_module'] = "member";
    $data['view_files'] = "ranking";
    $this->load->module("templates");
    $this->templates->member($data);

     }
    else{
        redirect('member/login');
    }

}



// shop code

public function products($category_id,$sub_cat_id)
{  
    if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {

if($sub_cat_id == '' && $category_id != ''){
            $data['product_by'] = get_query_data('SELECT *,tbl_product_info.id as p_info_id FROM tbl_products JOIN tbl_product_info on tbl_product_info.product_id = tbl_products.product_id where tbl_product_info.product_status = "Active" and tbl_products.category_id = '.$category_id.' ORDER BY rand() DESC LIMIT 30');
            
        }
        elseif ($category_id == '' && $sub_cat_id == '') {
            $data['product_by'] = get_query_data('SELECT *,tbl_product_info.id as p_info_id FROM tbl_products JOIN tbl_product_info on tbl_product_info.product_id = tbl_products.product_id where tbl_product_info.product_status = "Active" ORDER BY rand() DESC LIMIT 30');
        }
        elseif ($sub_cat_id != '' && $category_id != '') {
            $data['product_by'] = get_query_data('SELECT *,tbl_product_info.id as p_info_id FROM tbl_products JOIN tbl_product_info on tbl_product_info.product_id = tbl_products.product_id where tbl_product_info.product_status = "Active" and category_id = '.$category_id.' and sub_cat_id = '.$sub_cat_id.' ORDER BY tbl_products.created_at DESC LIMIT 20');
        }


    $data['catego'] = get_query_data('SELECT * FROM tbl_product_category where status = "Active" ORDER BY created_at DESC');
    $data['title'] = "Products";
    $data['view_module'] = "member";
    $data['view_files'] = "new_products";
    $this->load->module("templates");
    $this->templates->member_products($data);

    }
    else{
        redirect('member/login');
    }

}

// customer list
public function add_cart()
{
    $this->load->library('cart');


        $get_delivery_price = get_query_data('SELECT delivery_price FROM tbl_delivery_price');

        $size = $this->input->post('size_id');
        $get_size = explode(',', $size);
        $size_id = $get_size[0];
        // $size_name = $get_size[1];
        $data = array(
            'id' => rand(00000000,99999999),
            'Product_id' => $this->input->post('product_id'),
            'cv' => $this->input->post('cv'),
            'qty' => $this->input->post('quantity'),
            'name' => $this->input->post('product_name'),
            'price' => $this->input->post('product_price'),
            'product_image' => $this->input->post('product_image'),
            'discount_coupon' => $this->input->post('discount_coupon'),
            'discount_amount' => $this->input->post('discount_amount'),
            'delivery_price' => $get_delivery_price[0]->delivery_price,
            'delivery_coupon' => $this->input->post('delivery_coupon'),
            'size_id' => $size_id,
            'p_info_id' => $this->input->post('p_info_id'),

        );
    //print_r($data);
    //save_data('tbl_cart_detail', $data);
        $this->cart->insert($data);

}

public function add_to_wishlist()
{
    
        $data = array(
            'product_id' => $this->input->post('product_id'),
            'customer_id' => $this->session->userdata('member_code'),
            'list_from' => 'Member',
        );

        save_data('tbl_wishlist',$data);

}

    
    public function wishlist()
    {
       if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
        {
            $member_code = $this->session->userdata('member_code');
        $data['wishlist'] = get_query_data('SELECT product_name,sub_image,tbl_wishlist.status, tbl_wishlist.product_id, tbl_wishlist.created_at FROM tbl_wishlist JOIN tbl_products on tbl_products.product_id = tbl_wishlist.product_id where customer_id = '.$member_code.'');
        $data['view_module'] = "member";
        $data['view_files'] = "wishlist";
        $this->load->module("templates");
        $this->templates->member($data);
           }
    else{
        redirect('member/login');
    }

    }


    public function cart()
    {
        $this->load->library('cart');
        // $get_delivery_price = get_query_data('SELECT delivery_price FROM tbl_delivery_price');


        $data['cart_data'] = $this->cart->contents();
        $data['view_module'] = "member";
        $data['view_files'] = "cart";
        $this->load->module("templates");
        $this->templates->member($data);

    }

        public function new_cart()
    {
        $this->load->library('cart');
        // $get_delivery_price = get_query_data('SELECT delivery_price FROM tbl_delivery_price');


        $data['cart_data'] = $this->cart->contents();
        $data['view_module'] = "member";
        $data['view_files'] = "new_cart";
        $this->load->module("templates");
        $this->templates->member_products($data);

    }

    public function product_details($product_id,$p_info_id)
    {
        if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
        {
        $data['product_detail'] = get_query_data('SELECT *,tbl_product_info.id as p_info_id FROM tbl_products
                                                    JOIN tbl_product_category on tbl_product_category.id = tbl_products.category_id 
                                                    JOIN tbl_product_info on tbl_product_info.product_id = tbl_products.product_id WHERE tbl_products.product_id='.$product_id.' and tbl_product_info.product_status = "Active"');

        $data['sizes'] = get_query_data('SELECT * FROM tbl_product_sizes where product_id = '.$product_id.' and p_info_id = '.$p_info_id.' and quantity != total_sold');

        // $data['product_detail'] = get_query_data('SELECT * FROM tbl_products JOIN tbl_product_category on tbl_product_category.id = tbl_products.category_id WHERE tbl_products.id='.$id.'');
        $data['title'] = 'Product Details';
        $data['view_module'] = "member";
        $data['view_files'] = "product_detail";
        $this->load->module("templates");
        $this->templates->member($data);
            }
    else{
        redirect('member/login');
    }

    }


    public function new_product_details($product_id,$p_info_id)
    {
        if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
        {
                    $review_submit = $this->input->post('submit_review');
        if($review_submit == 'Submit Review'){
            $name = $this->input->post('name');
            $review = $this->input->post('review');
            $rating = $this->input->post('rating');


            $review_data = array(
                    'product_id' => $product_id,
                    'customer_name' => $name,
                    'customer_type' => 'Member',
                    'review' => $review,
                    'rating' => $rating,
            );
            $review_result_id = save_data('tbl_review', $review_data);



$number_of_files = count($_FILES['userfile']['name']);

        $files = $_FILES;

        $images = array();
        // if(!is_dir('app-assets/news_images'))
        // {
        //     mkdir('./app-assets/news_images',true);
        // }
        for($i=0; $i < $number_of_files; $i++){
          
            $_FILES['userfile']['name'] = $files['userfile']['name'][$i];
            $_FILES['userfile']['type'] = $files['userfile']['type'][$i];
            $_FILES['userfile']['tmp_name'] = $files['userfile']['tmp_name'][$i];
            $_FILES['userfile']['error'] = $files['userfile']['error'][$i];
            $_FILES['userfile']['size'] = $files['userfile']['size'][$i];

            $config['upload_path'] = './rating_images/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $config['max_size'] = '0';
            $config['max_width'] = '0';
            $config['max_height'] = '0';
            $config['overwrite'] = TRUE;
            $config['remove_space'] = TRUE;
            $config['encrypt_name'] = true;

            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            $this->upload->do_upload('userfile');
    
            if(!$this->upload->do_upload('userfile'))
            {
                   
                $error = array('error' => $this->upload->display_errors());
                // print_r($error);
                // exit();
            }
            else
            {

                
                $data = array(
                    'upload_data' => $this->upload->data());

                $data = array(
                         'review_id' => $review_result_id,
                         'review_images' => $data['upload_data']['file_name'],
                    );
                    $result_set = save_data('tbl_review_images', $data);
                }
               
            
           
        }
           if($result_set)
                    {
                        $this->session->set_flashdata('success', 'Thanks for Your Review!');
                        redirect('member/new_product_details/'.$product_id.'/'.$p_info_id);

                    }
                    else
                    {
                        $this->session->set_flashdata('error_msg', 'Sorry! your review is not added Due to Error.');
                        redirect('member/new_product_details/'.$product_id.'/'.$p_info_id);
                    }
















        }












            $this->load->library('cart');
            $data['cart_data'] = $this->cart->contents();
        $data['product_detail'] = get_query_data('SELECT *,tbl_product_info.id as p_info_id FROM tbl_products
                                                    JOIN tbl_product_category on tbl_product_category.id = tbl_products.category_id 
                                                    JOIN tbl_product_info on tbl_product_info.product_id = tbl_products.product_id WHERE tbl_products.product_id='.$product_id.' and tbl_product_info.product_status = "Active"');

        $data['sizes'] = get_query_data('SELECT * FROM tbl_product_sizes where product_id = '.$product_id.' and p_info_id = '.$p_info_id.' and quantity != total_sold');
        $data = array('total_reviews' =>  get_total('id', 'tbl_review', 'product_id = '.$product_id.''),
                   
                    'rating' => get_query_data('SELECT * FROM `tbl_review` as R 
                                                where R.product_id = '.$product_id.' order by created_at DESC'),

                );
        // $data['product_detail'] = get_query_data('SELECT * FROM tbl_products JOIN tbl_product_category on tbl_product_category.id = tbl_products.category_id WHERE tbl_products.id='.$id.'');
        $data['title'] = 'Product Details';
        $data['view_module'] = "member";
        $data['view_files'] = "new_product_detail";
        $this->load->module("templates");
        $this->templates->member_products($data);
            }
    else{
        redirect('member/login');
    }

    }



public function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

public function checkout()
    {
        if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
        {
          //  echo "string";exit();
            $customer_id = $this->session->userdata('member_code');
             $update_member = $this->input->post('update_member_1');
            if($update_member == 'Update Shipping')
        {

            $data = array(
                    'phone_number' => $this->input->post('phone_number'),
                    'country' => $this->input->post('country'),
                    'city' => $this->input->post('city'),
                    'state' => $this->input->post('state'),
                    'street' => $this->input->post('street'),
                    'address' => $this->input->post('address'),
                    'postal_code' => $this->input->post('postal_code'),
                    'shipping_option' => $this->input->post('shipping_option'),
            );

            $result = update_data_by_where('tbl_member', $data, 'member_code='.$customer_id.'');
            if($result){
                
                $this->session->set_flashdata('error_msg', 'Shipping Address Not Updated Due to Error. Please Try Again.');
                redirect('member/checkout');     
            }
            else{
                

                $this->session->set_flashdata('success', 'Shipping Address Updated Successfully.');
                redirect('member/checkout');
            }

      
        }






            $customer_id = $this->session->userdata('member_code');

            $this->load->library('cart');
            $cart_data = $this->cart->contents();
            if(empty($cart_data)){
                $this->session->set_flashdata('error_msg', 'Your Cart is empty.');
                redirect('member/cart');

            }

            $submit = $this->input->post('proceed');
            if($submit == 'Proceed to Checkout')
            {
            $cart_data = $this->cart->contents();
            
            $cv = $this->input->post('cv');

            // if($customer_id != '')
            // {
                
            //     $select_first_indirect = get_query_data('SELECT member_id FROM tbl_tcv_member where first_indirect='.$customer_id.'');
            //     if(!empty($select_first_indirect[0]->member_id))
            //     {
            //         $tcv = $cv*25/100;


            //         $first_indirect = array('tcv' => $tcv);
            //         foreach ($select_first_indirect as $F_indirect) {
            //             update_data_by_where('tbl_member', $first_indirect, 'member_code = '.$F_indirect->member_id.'');
            //         }
            //     }
            // }


            $payment_method = $this->input->post('payment_method');
           





            $this->image_config('bank_receipts');
            if($payment_method == 'Cash on Delivery'){

                 $data['bank_receipt'] = '';
            }
            else{
                if(!$this->upload->do_upload('bank_receipt'))
                {
                    $error = $this->upload->display_errors();
                    $this->session->set_flashdata('error_msg', $error);
                    redirect('member/checkout');

                   
                }
                else
                {
                    $filename = $this->upload->data();
                    $new_name = $filename['file_name'];
                   
                    $data['bank_receipt'] = $filename['file_name']; //time().$filename['file_name'];
                }
            }
            

            $data = array(
                'customer_id' => $customer_id,
                'customer_type' => 'Member',
                'promo_id' => $this->input->post('promo_id'),
                'promo_discount' => $this->input->post('promo_discount'),
                'delivery_price' => $this->input->post('delivery_price'),
                'delivery_coupon' => $this->input->post('delivery_coupon'),
                'sub_total' => $this->input->post('subtotal'),
                'cv' => $cv,
                'order_grand_total' => $this->input->post('order_grand_total'),
                // 'comment_about_order' => $this->input->post('comment_about_order'),
                'order_payment_method' => $this->input->post('payment_method'),
                'tracking_id' =>  $this->generateRandomString()   
            );

            $result = save_data('tbl_order',$data);
            if($result){

                
               
              





                foreach ($cart_data as $values) {
                    $cart_items = array(
                        'product_id' => $values['Product_id'],
                        'p_info_id' => $values['p_info_id'],
                        'size_id' => $values['size_id'],
                        'product_quantity' => $values['qty'],
                        'order_id' => $result,
                    );

                    $order_added = save_data('tbl_order_detail', $cart_items);
                    $quantity = $values['qty'];
                    
                    $sql_query = 'UPDATE tbl_product_sizes SET total_sold = total_sold + '.$quantity.' where id = '.$values['size_id'].'';

            
                        execute_query($sql_query);

                  
                }
                $this->cart->destroy();
                $this->session->set_flashdata('success', 'Order Placed Successfully.');
                redirect('member');


            }else{
                $this->session->set_flashdata('error_msg', 'Sorry! Order Not Placed Due to Error.');
                redirect('member');

            } 
            }







        $data['get_data'] = get_query_data('SELECT * FROM tbl_member where member_code = '.$customer_id.'');

        // below code is only for header menu
        $data['cart_data'] = $this->cart->contents();
        $data['view_module'] = "member";
        $data['view_files'] = "checkout";
        $this->load->module("templates");
        $this->templates->member($data);
        }
    else{
        redirect('member/login');
    }

    }


        public function remove_cart_item($id)
    {

        $data = array(

            'rowid' => $id,
            'qty' => 0
        );
        $this->load->library('cart');
        $this->cart->update($data);
        redirect('member/cart');

    }
    public function update_quantity($cart_id)
    {
        $cv = $this->input->post('cv');
        $quantity = $this->input->post('quantity');
        $update_cv = $quantity * $cv;
        $data = array(

            'rowid' => $cart_id,
            'qty' => $quantity,
            'cv' => $update_cv,
        );
        $this->load->library('cart');
        $this->cart->update($data);
        redirect('member/cart');

    }

public function fetch_sub_cat()
{
    $cat = $this->input->post('category_id');

    $data = get_query_data('SELECT * FROM tbl_products WHERE category_id = '.$cat.'');

    $output = '<option value="">Please Select Sub Category</option>';

    foreach ($data as $values) {

        $output .= '<option value="'.$values->id.'">'.$values->sub_cat_name.'</option>';
    }
    // print_r($output);
    // exit();
    echo $output;
}

public function profile()
{
    if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {


        $member_code = $this->session->userdata('member_code');

        $update_member = $this->input->post('update_member');
        $profile_pic = $this->input->post('profile_pic');
        $upload_cnic = $this->input->post('upload_cnic');
        if($update_member == 'Update Profile')
        {
            $password = $this->input->post('password');
            $confirm_password = $this->input->post('confirm_password');

        if($password == $confirm_password){

            $data = array(
                    'member_password' => md5($password),
                    'member_name' => $this->input->post('member_name'),
                    'member_email' => $this->input->post('member_email'),
            );

            $result = update_data_by_where('tbl_member', $data, 'member_code='.$member_code.'');
            if($result){
                
                $this->session->set_flashdata('error_msg', 'Profile Not Updated Due to Error. Please Try Again.');
                redirect('member/profile');     
            }
            else{
                

                $this->session->set_flashdata('success', 'Profile Updated Successfully.');
                redirect('member/profile');
            }

        }
        else{
                $this->session->set_flashdata('error_msg', 'Password Not Matched Please Try Again.');
                redirect('member/profile');
        }
        }

        elseif($update_member == 'Update Shipping')
        {

            $data = array(
                    'phone_number' => $this->input->post('phone_number'),
                    'country' => $this->input->post('country'),
                    'city' => $this->input->post('city'),
                    'state' => $this->input->post('state'),
                    'street' => $this->input->post('street'),
                    'address' => $this->input->post('address'),
                    'postal_code' => $this->input->post('postal_code'),
                    'shipping_option' => $this->input->post('shipping_option'),
            );

            $result = update_data_by_where('tbl_member', $data, 'member_code='.$member_code.'');
            if($result){
                
                $this->session->set_flashdata('error_msg', 'Shipping Address Not Updated Due to Error. Please Try Again.');
                redirect('member/profile');     
            }
            else{
                

                $this->session->set_flashdata('success', 'Shipping Address Updated Successfully.');
                redirect('member/profile');
            }

      
        }
        if($profile_pic == 'Change Profile Pic'){
             $this->image_config('member_pic');
               
                if(!$this->upload->do_upload('profile_pic'))
                {
                    $error = $this->upload->display_errors();
                    $this->session->set_flashdata('error_msg', $error);
                    redirect('member/profile');

                   
                }
                else
                {
                    
                    $filename = $this->upload->data();
                    $new_name = $filename['file_name'];
                    $data['profile_pic'] = $filename['file_name']; //time().$filename['file_name'];
                    $returnCatValue = update_data_by_where('tbl_member', $data, 'member_code='.$member_code.'');
                    if($returnCatValue)
                    {
                        
                        $this->session->set_flashdata('error_msg', 'Sorry! Profile Picture not changed Due to Error.');
                        redirect('member/profile');

                    }
                    else
                    {
                        $this->session->set_flashdata('success', 'Profile Picture Changed Successfully.');
                        redirect('member/profile');
                    }
                }
        }
        if($upload_cnic == 'Upload CNIC'){
            $number_of_files = count($_FILES['userfile']['name']);

        $files = $_FILES;

        $images = array();
        // if(!is_dir('app-assets/news_images'))
        // {
        //     mkdir('./app-assets/news_images',true);
        // }
        for($i=0; $i < $number_of_files; $i++){
          
            $_FILES['userfile']['name'] = $files['userfile']['name'][$i];
            $_FILES['userfile']['type'] = $files['userfile']['type'][$i];
            $_FILES['userfile']['tmp_name'] = $files['userfile']['tmp_name'][$i];
            $_FILES['userfile']['error'] = $files['userfile']['error'][$i];
            $_FILES['userfile']['size'] = $files['userfile']['size'][$i];

            $config['upload_path'] = './member_pic/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $config['max_size'] = '0';
            $config['max_width'] = '0';
            $config['max_height'] = '0';
            $config['overwrite'] = TRUE;
            $config['remove_space'] = TRUE;
            $config['encrypt_name'] = true;

            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            $this->upload->do_upload('userfile');
    
            if(!$this->upload->do_upload('userfile'))
            {
                   
                $error = array('error' => $this->upload->display_errors());
                // print_r($error);
                // exit();
            }
            else
            {

                
                $data = array(
                    'upload_data' => $this->upload->data());

                $data = array(
                         'member_id' => $member_code,
                         'cnic_pic' => $data['upload_data']['file_name'],
                    );
                    $result_set = save_data('tbl_member_cnic', $data);
                }
               
            
           
        }
           if($result_set)
                    {
                        $this->session->set_flashdata('success', 'CNIC Uploaded Successfully.');
                        redirect('member/profile');

                    }
                    else
                    {
                        $this->session->set_flashdata('error_msg', 'Sorry! CNIC Not Uploaded Due to Error.');
                        redirect('member/profile');
                    }
        }
       





        $data['get_data'] = get_query_data('SELECT * FROM tbl_member where member_code = '.$member_code.'');
        $data['get_cnic'] = get_query_data('SELECT * FROM tbl_member_cnic where member_id = '.$member_code.'');
    $data['title'] = "Profile";
    $data['view_module'] = "member";
    $data['view_files'] = "profile";
    $this->load->module("templates");
    $this->templates->member($data);

     }
    else{
        redirect('member/login');
    }
}

public function delete_cnic_pic($id)
{
    if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {
         $member_code = $this->session->userdata('member_code');
         $result = delete_data('tbl_member_cnic',$id);
         if($result){
            $this->session->set_flashdata('success', 'CNIC Deleted Successfully.');
                        redirect('member/profile');
         }
         else{
            $this->session->set_flashdata('error_msg', 'Sorry! CNIC Deleted Not Added Due to Error.');
                        redirect('member/profile');
         }

    }
    else{
        redirect('member/login');
    }

}
// referal Member
public function referal_member($referal_member,$token)
{
  
  if($token != 'IFi2W51JCg76Dovr6yFU' || $token == ''){
    // redirect('404');
    echo ' you are in wrong place';
  }


 

        $submit = $this->input->post('submit');

        if($submit == 'Submit'){
             $password  = $this->input->post('password');
              $confirm_password  = $this->input->post('confirm_password');
              if ($password != $confirm_password) {
                $this->session->set_flashdata('error_msg', 'Sorry! Password Not Matched please Try again.');
                        redirect('member/referal_member/'.$referal_member.'/'.$token.'');
                  
              }
            $member_code = rand(000000,999999); 
            $ref_code = decode_id($referal_member);
            if($ref_code == '')
            {
                $referal_code = '12345';
            }
            elseif (!empty($ref_code)) {
                $referal_code = $ref_code;
            }


               if(!empty($referal_code)){
                 $fetch_num = get_query_data('SELECT * FROM tbl_tcv_member where member_id = '.$referal_code.'');
                    $first_indirect = $fetch_num[0]->first_indirect;
                    $second_indirect = $fetch_num[0]->second_indirect;


                    $direct_referal = $referal_code;
                    
                    $get_data = get_query_data('SELECT * FROM tbl_tcv_member where member_id = '.$direct_referal.'');


                    $direct = $get_data[0]->direct_referal;
                    $first_indirect = $get_data[0]->first_indirect;
                    $second_indirect = $get_data[0]->second_indirect;


                   
                    if($direct != '' && $direct != 0)
                    {
                         $F_indirect = $get_data[0]->direct_referal;
                    } else{
                        $F_indirect= '';
                        
                    }

                     if ($first_indirect != '' || $first_indirect != 0) {
                       $S_indirect = $get_data[0]->first_indirect;
                    }
                     else{
                       
                        $S_indirect= '';
                    }
                     if ($second_indirect != '' || $second_indirect != 0) {
                       $T_indirect = $get_data[0]->second_indirect;
                    }
                     else{
                       
                        $T_indirect= '';
                    }
                 

                    


                   
                    $add_referal = array(
                                        'member_id'         => $member_code,
                                        'direct_referal'    => $direct_referal,
                                        'first_indirect'    => $F_indirect,
                                        'second_indirect'    => $S_indirect,
                                        'third_indirect'    => $T_indirect,

                                    );

               }
               
        $data = array(
            'member_code'       => $member_code,
            'member_name'       => $this->input->post('member_name'),
            'member_email'       => $this->input->post('member_email'),
            'member_password'       => md5($password),
            'referal_person_code' => $referal_code,
            'referal_person_status' => $ref_status,
        );
                $returnCatValue = save_data('tbl_member', $data);
                    if($returnCatValue)
                    {
                        $assign_cv = array('pcv' => 1);
                        update_data_by_where('tbl_member', $assign_cv,'id = '.$returnCatValue.'');
                        save_data('tbl_tcv_member',$add_referal);
                        
                     
                        $this->session->set_flashdata('success', 'Welcome to ZSMPK! You are now a member of ZSMPK. Please Login.');
                        redirect('member/login');

                    }
                    else
                    {
                        $this->session->set_flashdata('error_msg', 'Sorry! Member Not Added Due to Error.');
                        redirect('member/referal_member/'.$referal_member.'/'.$token.'');
                    }
                
        }



    $this->load->view('member/referal_member');


}
// END referal member






////////////////////////////////////// ORDER Module /////////////////////////

    public function orders()
{  
    if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {


    $data['title'] = "Orders";
    $data['view_module'] = "member";
    $data['view_files'] = "orders";
    $this->load->module("templates");
    $this->templates->member($data);

    }
    else{
        redirect('member/login');
    }

}

//////// ORder List ////////


public function order_list($member_id)
{
    if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {
        // echo $member_id;
        // // exit();

        $this->load->model("mdl_member");  
           $fetch_data = $this->mdl_member->order_make_datatables($member_id);  
           $data = array();  
           foreach($fetch_data as $row)  
           {  
                $customer_name = $row->first_name.' '.$last_name;
                
                
                $shop_array = array();   
                $shop_array[] = $row->tracking_id;   
                $shop_array[] = $row->sub_total;          
                // $shop_array[] = $row->promo_discount;          
                $shop_array[] = $row->order_grand_total;          
                $shop_array[] = $row->cv;          
                $shop_array[] = $row->order_payment_method;          
                $shop_array[] = $row->order_status;         
                $shop_array[] = $row->created_at;  
                $shop_array[] = '<a href="'.base_url('member/order_detail/'.$row->order_id.'').'" name="delete_shop_category" class="btn btn-info btn-xs">Detail</a>';   
                  
                $data[] = $shop_array;  
           }  
           $output = array(  
                "draw"                    =>     intval($_POST["draw"]),  
                "recordsTotal"          =>      $this->mdl_member->order_get_all_data($member_id),  
                "recordsFiltered"     =>     $this->mdl_member->order_get_filtered_data($member_id),  
                "data"                    =>     $data  
           );  
           echo json_encode($output); 

           }
       else{
        redirect('member/login');
    }
}


    public function order_detail($id)
{  
    if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {

    // $data['order_products'] = get_query_data('SELECT *, tbl_products.member_retail_price as m_price FROM tbl_order 
    //                                     JOIN tbl_order_detail on tbl_order_detail.order_id = tbl_order.id
    //                                     JOIN tbl_products on tbl_products.product_id = tbl_order_detail.product_id WHERE tbl_order.id = '.$id.'');
    $data['order_products'] = get_query_data('SELECT * FROM tbl_order 
                                        JOIN tbl_order_detail on tbl_order_detail.order_id = tbl_order.id
                                        JOIN tbl_products on tbl_products.product_id = tbl_order_detail.product_id
                                        JOIN tbl_product_sizes on tbl_product_sizes.id = tbl_order_detail.size_id
                                        JOIN tbl_product_info on tbl_product_info.id = tbl_order_detail.p_info_id
                                         WHERE tbl_order.id = '.$id.'');
    // $data['order_info'] = get_query_data('SELECT * FROM tbl_order JOIN tbl_customers on tbl_customers.customer_id = tbl_order.customer_id where tbl_order.id = '.$id.'');
    // $data['second_shipping_info'] = get_query_data('SELECT * FROM tbl_order JOIN tbl_customer_shipping_info on tbl_customer_shipping_info.customer_id = tbl_order.customer_id where tbl_order.id = '.$id.'');
    
    $data['order_info'] = get_query_data('SELECT * FROM tbl_order JOIN tbl_member on tbl_member.member_code = tbl_order.customer_id where tbl_order.id = '.$id.'');
    $data['second_shipping_info'] = get_query_data('SELECT * FROM tbl_order JOIN tbl_customer_shipping_info on tbl_customer_shipping_info.customer_id = tbl_order.customer_id where tbl_order.id = '.$id.'');
    $data['title'] = "Order Detail";
    $data['view_module'] = "member";
    $data['view_files'] = "order_detail";
    $this->load->module("templates");
    $this->templates->member($data);

    }
    else{
        redirect('admin/login');
    }

}

//////// END order List ////////
//////// Discount Coupon ////////
public function discount_coupon($id)
{  
    if( $this->session->userdata('user_type') == 'Admin')
    {

        $submit = $this->input->post('submit');

        if($submit == 'Submit'){
        $data = array(
            'discount_coupon' => $this->input->post('discount_coupon'),
            'discount_amount' => $this->input->post('discount_amount'),
        );

                    $returnCatValue = save_data('tbl_discount_coupon', $data);
                    if($returnCatValue)
                    {
                       
                        $this->session->set_flashdata('success', 'Product Category Added Successfully.');
                        redirect('member/discount_coupon');

                    }
                    else
                    {
                        $this->session->set_flashdata('error_msg', 'Sorry! Product Category Not Added Due to Error.');
                        redirect('member/discount_coupon');
                    }
                
        }

        if($submit == 'Update'){
                $data = array(
                    'discount_coupon' => $this->input->post('discount_coupon'),
                    'discount_amount' => $this->input->post('discount_amount'),
                    'status' => $this->input->post('status'),
                );


                 $returnCatValue = update_data('tbl_discount_coupon', $data, $id);



                    if($returnCatValue)
                    {
                        $this->session->set_flashdata('success', 'Status Changed Successfully.');
                        redirect('member/discount_coupon/'.$id.'');

                    }
                    else
                    {
                        $this->session->set_flashdata('error_msg', 'Sorry! Status Not Updated Due to Error.');
                        redirect('member/discount_coupon/'.$id.'');
                    }


        }

    if($id !=''){
           $data['discount_data'] = get_query_data('SELECT * FROM tbl_discount_coupon WHERE id = '.$id.'');
    }

    $data['discount_coupons'] = get_query_data('SELECT * FROM tbl_discount_coupon order By created_at DESC');
    $data['title'] = "Discount Coupon";
    $data['view_module'] = "member";
    $data['view_files'] = "discount_coupon";
    $this->load->module("templates");
    $this->templates->member($data);

    }
    else{
        redirect('member/login');
    }

}
//////// END Discount Coupon ////////

/////// Delivery Module Code ////////

public function delivery($id)
{  
    if( $this->session->userdata('user_type') == 'Admin')
    {

        $submit = $this->input->post('submit');

        if($submit == 'Submit'){
        $data = array(
            'delivery_price' => $this->input->post('delivery_price'),
            'status' => $this->input->post('status'),
        );

                    $returnCatValue = save_data('tbl_delivery_price', $data);
                    if($returnCatValue)
                    {
                       
                        $this->session->set_flashdata('success', 'Delivery Price Added.');
                        redirect('member/delivery');

                    }
                    else
                    {
                        $this->session->set_flashdata('error_msg', 'Sorry! Delivery Price Not Added Due to Error.');
                        redirect('member/delivery');
                    }
                
        }

        if($submit == 'Update'){
            $delivery_id = $this->input->post('delivery_id');
                $data = array(
                    'delivery_price' => $this->input->post('delivery_price'),
                    'status' => $this->input->post('status'),
                );


                 $returnCatValue = update_data('tbl_delivery_price', $data, $delivery_id);



                    if($returnCatValue)
                    {
                        $this->session->set_flashdata('success', 'Delivery Price Changed Successfully.');
                        redirect('member/delivery');

                    }
                    else
                    {
                        $this->session->set_flashdata('error_msg', 'Sorry! Price Not Updated Due to Error.');
                        redirect('member/delivery');
                    }


        }


    $data['delivery'] = get_query_data('SELECT * FROM tbl_delivery_price order By created_at DESC');
    $data['delivery_coupon'] = get_query_data('SELECT * FROM tbl_delivery_coupon order By created_at DESC');
    $data['title'] = "Delivery";
    $data['view_module'] = "member";
    $data['view_files'] = "delivery";
    $this->load->module("templates");
    $this->templates->member($data);

    }
    else{
        redirect('member/login');
    }

}

public function delivery_coupon($id)
{  
    if( $this->session->userdata('user_type') == 'Admin')
    {

        $submit = $this->input->post('submit_delivery_coupon');

        if($submit == 'Submit'){
        $data = array(
            'delivery_coupon' => $this->input->post('delivery_coupon'),
            'delivery_status' => $this->input->post('delivery_status'),
        );

                    $returnCatValue = save_data('tbl_delivery_coupon', $data);
                    if($returnCatValue)
                    {
                       
                        $this->session->set_flashdata('success', 'Delivery Coupon Price Added.');
                        redirect('member/delivery');

                    }
                    else
                    {
                        $this->session->set_flashdata('error_msg', 'Sorry! Delivery Price Not Added Due to Error.');
                        redirect('member/delivery');
                    }
                
        }

        if($submit == 'Update'){
            $delivery_coupon_id = $this->input->post('delivery_coupon_id');
                $data = array(
                    'delivery_coupon' => $this->input->post('delivery_coupon'),
                    'delivery_status' => $this->input->post('delivery_status'),
                );


                 $returnCatValue = update_data('tbl_delivery_coupon', $data, $delivery_coupon_id);



                    if($returnCatValue)
                    {
                        $this->session->set_flashdata('success', 'Delivery Price Changed Successfully.');
                        redirect('member/delivery');

                    }
                    else
                    {
                        $this->session->set_flashdata('error_msg', 'Sorry! Price Not Updated Due to Error.');
                        redirect('member/delivery');
                    }


        }

    }
    else{
        redirect('member/login');
    }

}
public function fetch_delivery_data()
{
    if($this->session->userdata('user_type') == 'Admin'){
        $id = $this->input->post('id');
     

        $result = get_query_data('SELECT * FROM tbl_delivery_price WHERE id = '.$id.'');

         echo json_encode($result);
    
         //print_r($result);
        //echo $result;
       
    
    }
    else{

        redirect('member/login');

    }
}
public function fetch_delivery_coupon_data()
{
    if($this->session->userdata('user_type') == 'Admin'){
        $id = $this->input->post('id');
     

        $result = get_query_data('SELECT * FROM tbl_delivery_coupon WHERE id = '.$id.'');

         echo json_encode($result);
    
         //print_r($result);
        //echo $result;
       
    
    }
    else{

        redirect('member/login');

    }
}
/////// End Delivery Module Code ////////
public function fetch_size()
{
    $size = $this->input->post('size');
    $product_id = $this->input->post('product_id');

    $get_size = explode(',', $size);

    $size_id = $get_size[0];
    $size_name = $get_size[1];


    // echo $size_id;

    // $data = get_query_data("SELECT * FROM tbl_menu_category WHERE type = '".$cat."'");
    

        $data = get_query_data('SELECT * FROM tbl_product_sizes where product_id = '.$product_id.' and size = "'.$size_name.'" order by created_at DESC');
        foreach ($data as $client) 
        {
            $output .= '<option value="'.$client->id.'">'.$client->color.'</option>';
        
        
    }

    // print_r($output);
    // exit();
    echo $output;
}


    public function fetch_stock()
{
    $size = $this->input->post('size');
    $product_id = $this->input->post('product_id');

    $get_size = explode(',', $size);

    $size_id = $get_size[0];
    $size_name = $get_size[1];


        $data = get_query_data('SELECT * FROM tbl_product_sizes where product_id = '.$product_id.' and size = "'.$size_name.'" order by created_at DESC');
        foreach ($data as $client) 
        {
            $qty = $client->quantity;
            $sold = $client->total_sold;
            $total_q = $qty - $sold;
           
            
    }
    if($sold < $qty ){
                 $output .= '<p style="color:green;" data-qty_check="'.$total_q.'">Available '.$total_q.' in Stock</p>';
                 $output .= '<input type="hidden" id="qty_check" value="'.$total_q.'">';
            }
            elseif ($sold >= $qty) {
                 $output .= '<span style="color:red;">Not Available in Stock</span>';
            }

    // print_r($output);
    // exit();
    echo $output;
}


public function product_images($product_id)
{  
    if( $this->session->userdata('user_type') == 'Admin')
    {

    $data['product_images'] = get_query_data('SELECT * FROM tbl_product_images where product_id = '.$product_id.'');
    $data['title'] = "Product Images";
    $data['view_module'] = "member";
    $data['view_files'] = "product_images";
    $this->load->module("templates");
    $this->templates->member($data);

    }
    else{
        redirect('member/login');
    }

}

public function withdrawal()
{  
    if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {

        // $withdrawal_mode = $this->input->post('submit');

        // echo $withdrawal_mode;


        $member_id = $this->session->userdata('member_code');
        $get_member_colums = select_columns('member_code,pcv,tcv,rank,cancelation_amount','tbl_member', 'member_code = '.$member_id.'');
        $pcv = $get_member_colums[0]->pcv;
        $tcv = $get_member_colums[0]->tcv;
        $rank = $get_member_colums[0]->rank;
        // print_r($get_member_colums);
       // echo $tcv;
       // exit();
        
       
        $check = get_query_data('SELECT member_id,rank_id FROM tbl_referal_earnings where member_id = '.$member_id.' and rank_id = '.$rank.'');
        $rank_data = select_columns('id,referral_earnings,incentive,level_earnings,total_earnings','tbl_ranking', 'id = '.$rank.'');
        if(empty($check)){
            
            $withdraw_amount = $rank_data[0]->level_earnings - $get_member_colums[0]->cancelation_amount;
            $data = array(
                        'member_id'    => $get_member_colums[0]->member_code,
                        'rank_id'    => $rank,
                        'referal_amount'    => $rank_data[0]->referral_earnings,
                        'incentive_amount'    => $rank_data[0]->incentive,
                        'level_earnings'    => $rank_data[0]->level_earnings,
                        'cancelation_charges'    => $get_member_colums[0]->cancelation_amount,
                        'withdraw_amount'    => $withdraw_amount,
                        'status'    => 'Pending',
            );

            
            
        //     switch (true) 
        //     {
        //     case ($pcv >= 50 && $tcv >= 200 || $tcv < 650 ):
        //         echo 'i m big';
               
                
        //         break;
        //     case ($pcv >= 10 && $tcv >= 100 || $tcv < 200 ):
               
        //           echo 'i m small';
                  
        //         break;
        //     case '3':
        //         $sql_query = 'UPDATE employee_data SET annual_leave = annual_leave - '.$leaves.' WHERE '.$where.'';
        //     execute_query($sql_query);
                
        //         break;
            
        //     default:
        //         # code...
        //         break;
        // }
            if($pcv >= 50 && $pcv <= 99  && $tcv >= 200 && $tcv <= 649 && $rank == 1){
                    $insert_data = save_data('tbl_referal_earnings', $data);
            }
            elseif ($pcv >= 100 && $pcv <= 149 && $tcv >= 650 && $tcv <= 849 && $rank == 2) {
               $insert_data = save_data('tbl_referal_earnings', $data);
                  
            }
            elseif ($pcv >= 150 && $pcv <= 299 && $tcv >= 1400 && $tcv <= 2249 && $rank == 3) {
               $insert_data = save_data('tbl_referal_earnings', $data);
                  
            }
            elseif ($pcv >= 200 && $pcv <= 499 && $tcv >= 2500 && $tcv <= 4749 && $rank == 4) {
               $insert_data = save_data('tbl_referal_earnings', $data);
                  
            }
            elseif ($pcv >= 250 && $pcv <= 749 && $tcv >= 4000 && $tcv <= 8749 && $rank == 5) {
               $insert_data = save_data('tbl_referal_earnings', $data);
                  
            }
            elseif ($pcv >= 300 && $pcv <= 1049 && $tcv >= 5950 && $tcv <= 14699 && $rank == 6) {
               $insert_data = save_data('tbl_referal_earnings', $data);
                  
            }
            elseif ($pcv >= 350 && $pcv <= 1399 && $tcv >= 8400 && $tcv <= 23099 && $rank == 7) {
               $insert_data = save_data('tbl_referal_earnings', $data);
                  
            }
            elseif ($pcv >= 400 && $pcv <= 1799 && $tcv >= 11600 && $tcv <= 34699 && $rank == 8) {
               $insert_data = save_data('tbl_referal_earnings', $data);
                  
            }



        }
       

        $submit = $this->input->post('Submit_request');
        $withdrawal_mode = $this->input->post('withdrawal_mode');
        $earnings_data = get_query_data('SELECT * FROM tbl_referal_earnings where member_id = '.$member_id.' and status = "Pending"');

        $incentive = $earnings_data[0]->incentive_amount;
        $level_earnings = $earnings_data[0]->level_earnings;
        $referral_earnings = $earnings_data[0]->referal_amount;
        $withdraw_amount = $earnings_data[0]->withdraw_amount;
        $cancel_charges = $earnings_data[0]->cancelation_charges;
        
        // for only incentives
        $withdraw_incentives = $incentive - $cancel_charges;
        // for Referal Amount
        $withdraw_referral_earnings = $referral_earnings - $cancel_charges;

        // for both amount
        // $withdraw_referral_earnings = 

        if($submit == 'Submit Request'){
            $withdrawal = array(
                            'member_id'     => $member_id,
                            'earning_id'     => $this->input->post('earning_id'),
                            'withdrawal_mode'     => $withdrawal_mode,
                            'withdrawal_source'     => $this->input->post('withdrawal_source'),
                            'account_holder'     => $this->input->post('account_holder'),
                            'account_number'     => $this->input->post('account_number'),
                            'holder_cnic'     => $this->input->post('holder_cnic'),
                            'holder_mobile'     => $this->input->post('holder_mobile'),
                            'badge_name'     => $this->input->post('badge_name'),
                            'note'     => $this->input->post('note'),
            );
            $where_1 = 'member_id = '.$member_id.' and rank_id = '.$rank.'';
            if($withdrawal_mode == 'Incentive'){
                $withdrawal['withdraw_amount'] = $withdraw_incentives;
                $data_for_update = array('withdraw_status' => 'Withdraw Incentives',);
                update_data_by_where('tbl_referal_earnings', $data_for_update, $where_1);

            }
            elseif ($withdrawal_mode == 'Referral Point Bonus (RPB)') {

                    $withdrawal['withdraw_amount'] = $withdraw_referral_earnings;

                    $data_for_update = array('withdraw_status' => 'Withdraw Referral Point');
                update_data_by_where('tbl_referal_earnings', $data_for_update, $where_1); 
                           }
            elseif ($withdrawal_mode == 'RPB + Incentive Both') {

                $withdrawal['withdraw_amount'] = $withdraw_amount;
                $data_for_update = array('withdraw_status' => 'Withdraw Both');
                update_data_by_where('tbl_referal_earnings', $data_for_update, $where_1);
            }
           
              $send_request = save_data('tbl_withdrawl_request',$withdrawal);
            
            if($send_request)
                    {
                        $this->session->set_flashdata('success', 'Withdrawal Request has been sent Successfully!');
                        redirect('member/withdrawal');

                    }
                    else
                    {
                        $this->session->set_flashdata('error_msg', 'Sorry! Withdrawal Request has been sent Due to Error.');
                        redirect('member/withdrawal');
                    }

        }








    $data['earnings'] = $earnings_data;
    $data['withdraw_request'] = get_query_data('SELECT * FROM tbl_withdrawl_request where member_id = '.$member_id.'');
    $data['title'] = "Withdrawal";
    $data['view_module'] = "member";
    $data['view_files'] = "withdrawal";
    $this->load->module("templates");
    $this->templates->member($data);

    }
    else{
        redirect('member/login');
    }

}


// search Query here
public function fetch_member_search()
{
    if($this->session->userdata('member_code') != '' && $this->session->userdata('member_email') != '')
    {
        $output = '';
        $search = $this->input->post('search');
        if(isset($search))
        {
           $query = get_query_data('SELECT *,tbl_product_info.id as p_info_id FROM tbl_products JOIN tbl_product_info on tbl_product_info.product_id = tbl_products.product_id where tbl_product_info.product_status = "Active" and tbl_products.product_id LIKE "%'.$search.'%" OR tbl_products.product_name LIKE "%'.$search.'%" ORDER BY tbl_products.created_at DESC LIMIT 30

           ');
       }
       else
       {
           $query = get_query_data('
           SELECT *,tbl_product_info.id as p_info_id FROM tbl_products JOIN tbl_product_info on tbl_product_info.product_id = tbl_products.product_id where tbl_product_info.product_status = "Active" ORDER BY rand() DESC LIMIT 30
           ');
       }

       if($query != ''){



       foreach ($query as $items) {
                if(empty($items->member_retail_price_new) || $items->member_retail_price_new == 0)
                                    {
                                        $pr_price = $items->member_retail_price;
                                        $product_price = '<span class="current_price">PKR '.$items->member_retail_price.'.00</span>';
                                    }
                                    else{
                                        $pr_price = $items->member_retail_price_new;
                                        $product_price = '
                                                <span class="price-new">PKR '.$items->member_retail_price_new.'.00</span>   <del>PKR '.$items->member_retail_price.'.00</del>';
                                    }


                                      if(empty($items->sub_image))
                                    {
                                        $img = 'member_product_assets/img/products/9.jpg';
                                    }
                                    else{
                                        $img = 'product_images/'.$items->sub_image.'';
                                    }

        $output .='
                <div class="col-xs-12 col-sm-6 col-md-4">
                                            <div class="single-product">
                                                <div class="product-img">
                                                    <div class="pro-type">
                                                    </div>
                                                    <a href="'.base_url('member/new_product_details/'.$items->product_id.'/'.$items->p_info_id.'').'"><img src="'.base_url($img).'" alt="Product Title" style="width: 270px; height: 350px;"/></a>
                                                    <div class="actions-btn">
                                                        <a href="'.base_url('member/cart').'"><i class="mdi mdi-cart"></i></a>
                                                        <a href="'.base_url('member/new_product_details/'.$items->product_id.'/'.$items->p_info_id.'').'"><i class="mdi mdi-eye"></i></a>
                                                        <a type="button" data-product_id='.$detail->product_id.' class="wishlist"><i class="mdi mdi-heart"></i></a>
                                                    </div>
                                                </div>
                                                <div class="product-dsc">
                                                    <p><a href="#">'.$items->product_name.'</a></p>
                                                    <div class="ratting">
                                                        <i class="mdi mdi-star"></i>
                                                        <i class="mdi mdi-star"></i>
                                                        <i class="mdi mdi-star"></i>
                                                        <i class="mdi mdi-star-half"></i>
                                                        <i class="mdi mdi-star-outline"></i>
                                                    </div>
                                                    '.$product_price.' PKR - CV.'. $items->no_of_cv .'
                                                </div>
                                            </div>
                                        </div>
        ';



           
       }
       echo $output;
       }
       else{
        echo 'No Data Found';
       }


    }
    else{
        redirect('admin/login');
    }
}

// end search Query




}