    <div class="main">
      <div class="container-fluid">

        <div class="row margin-bottom-40">
          <!-- BEGIN SIDEBAR -->
    
          <!-- END SIDEBAR -->

          <!-- BEGIN CONTENT -->
          <div class="col-md-12 col-sm-12">
            <div class="content-page">
              <div id="map" class="gmaps margin-bottom-40" style="height:600px;">
              	<div class="mapouter"><div style="overflow:hidden;width: 100%;position: relative;"><iframe width="100%" height="600" src="https://maps.google.com/maps?hl=en&amp;q=City Plaza 10th Ave, F-10 Markaz F 10/3 F-10, Islamabad, Islamabad Capital Territory 44000+(undefined)&amp;ie=UTF8&amp;t=p&amp;z=15&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><div style="position: absolute;width: 80%;bottom: 10px;left: 0;right: 0;margin-left: auto;margin-right: auto;color: #000;text-align: center;"><div style="overflow: auto; position: absolute; height: 0pt; width: 0pt;">Powered by <a href="https://www.embedista.com/googlemapsembed">Google Map Embed</a> Code Generator</div><script type="text/javascript" src="https://www.embedista.com/j/map.js"></script></div><style>.nvs{position:relative;text-align:right;height:325px;width:643px;} #gmap_canvas img{max-width:none!important;background:none!important}</style></div></div>         
            </div>
          </div>
          <!-- END CONTENT -->
        </div>
        <!-- END SIDEBAR & CONTENT -->
      </div>







      <div class="container">
        <div class="row margin-bottom-40">
          <div class="col-md-8 col-sm-8 col-md-offset-2">
            <div class="content-page">
 

              <h2>Contact Form</h2>
              
              <!-- BEGIN FORM-->
              <form action="#" class="default-form" role="form">
                <div class="form-group">
                  <label for="name">Name</label>
                  <input type="text" class="form-control" id="name">
                </div>
                <div class="form-group">
                  <label for="email">Email <span class="require">*</span></label>
                  <input type="text" class="form-control" id="email">
                </div>
                <div class="form-group">
                  <label for="message">Message</label>
                  <textarea class="form-control" rows="8" id="message"></textarea>
                </div>
                <div class="padding-top-20">                  
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
              <!-- END FORM-->          
            </div>
          </div>
          <!-- END CONTENT -->
        </div>
        <!-- END SIDEBAR & CONTENT -->
      </div>
    </div>