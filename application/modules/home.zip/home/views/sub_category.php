 


    <div class="main">
      <div class="container">
        <ul class="breadcrumb">
            <li><a href="<?php echo base_url('/'); ?>">Home</a></li>
            <li><a href="<?php echo base_url('home/products'); ?>">Store</a></li>
            <li class="active">Sub Categories</li>
        </ul>
        <!-- BEGIN SIDEBAR & CONTENT -->
        <div class="row margin-bottom-40">
          <!-- BEGIN SIDEBAR -->
          <div class="col-md-9 col-sm-7">

            <div class="row list-view-sorting clearfix">
              <div class="col-md-2 col-sm-2 list-view">
                <a href="javascript:;"><i class="fa fa-th-large"></i></a>
                <a href="javascript:;"><i class="fa fa-th-list"></i></a>
              </div>
              <div class="col-md-10 col-sm-10">
          
              </div>
            </div>
            <!-- BEGIN PRODUCT LIST -->
              <div class="row product-list">
              <!-- PRODUCT ITEM START -->
              <?php foreach ($sub_categories as $sub_Category):

                                    if(empty($sub_Category->sub_category_image))
                                    {
                                        $img = 'new_adminfiles/assets/image/product/6product50x59.jpg';
                                    }
                                    else{
                                        $img = 'product_images/'.$sub_Category->sub_category_image.'';
                                    }

                                ?>

              <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="product-item">
                  <a href="<?php echo base_url(); ?>home/products/<?php echo $sub_Category->category_id; ?>/<?php echo $sub_Category->id; ?>">
                  <div class="pi-img-wrapper">
                    <img src="<?php echo base_url($img);?>" class="img-responsive" alt="<?php echo $sub_Category->sub_category_name; ?>" style="border-radius: 20px !important;">
                    <div>

                    </div>
                  </div>
                  <h3><a href="<?php echo base_url(); ?>home/products/<?php echo $sub_Category->category_id; ?>/<?php echo $sub_Category->id; ?>"><?php echo $sub_Category->sub_category_name; ?></a></h3>
    
                </a>
                </div>
              </div>
              <?php endforeach; ?>

              <!-- PRODUCT ITEM END -->

            </div>


         
          </div>
          <!-- END SIDEBAR -->
          <!-- BEGIN CONTENT -->

          <!-- END CONTENT -->
        </div>
        <!-- END SIDEBAR & CONTENT -->
      </div>
    </div>