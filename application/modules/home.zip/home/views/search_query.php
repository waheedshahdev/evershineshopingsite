
    <!--shop banner area start-->
    <div class="shop_banner_area mt-50 mb-45">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="shop_banner_thumb">
                        <img src="<?php echo base_url(); ?>frontfiles/assets/img/bg/banner16.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--shop banner area end-->

    
    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">   
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.html">home</a></li>
                            <li>shop fullwidth</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>         
    </div>
    <!--breadcrumbs area end-->
    
    <!--shop  area start-->
    <div class="shop_area shop_fullwidth mt-45 mb-50">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!--shop wrapper start-->
                    <!--shop toolbar start-->
                    <div class="shop_toolbar_wrapper">
                        <div class="shop_toolbar_btn">

                            <button data-role="grid_3" type="button" class=" btn-grid-3" data-toggle="tooltip" title="3"></button>

                            <button data-role="grid_4" type="button"  class="active btn-grid-4" data-toggle="tooltip" title="4"></button>

                            <button data-role="grid_list" type="button"  class="btn-list" data-toggle="tooltip" title="List"></button>
                        </div>
                        <!-- <div class=" niceselect_option">
                            <form class="select_option" action="#">
                                <select name="orderby" id="short">

                                    <option selected value="1">Sort by average rating</option>
                                    <option  value="2">Sort by popularity</option>
                                    <option value="3">Sort by newness</option>
                                    <option value="4">Sort by price: low to high</option>
                                    <option value="5">Sort by price: high to low</option>
                                    <option value="6">Product Name: Z</option>
                                </select>
                            </form>
                        </div> -->
                        <div class="page_amount">
                            <!-- <p>Showing 1–9 of 21 results</p> -->
                        </div>
                    </div>
                    <?php if($search_products === ''){?>                    		
                    		<h4>Nothing Found</h4>
                    	<?php } ?>
                    <!--shop toolbar end-->
                    <div class="row shop_wrapper grid_4">
                    	


                    	<?php foreach ($search_products as $products_data):
                    			if(empty($products_data->new_price) || $products_data->new_price == 0)
                                    {
                                        $pr_price = $products_data->price;
                                        $product_price = '<span class="current_price">$'.$products_data->price.'.00</span>';
                                    }
                                    else{
                                        $pr_price = $products_data->new_price;
                                        $product_price = '<span class="old_price">$'.$products_data->price.'.00</span> 
                                                <span class="current_price">$'.$products_data->new_price.'.00</span>';
                                    }
                    			if(empty($products_data->sub_image))
                                    {
                                        $img = 'frontfiles/assets/img/product/product1.jpg';
                                    }
                                    else{
                                        $img = 'product_images/'.$products_data->sub_image.'';
                                    }
                    		?>
                        <div class="col-lg-3 col-md-4 col-12 ">
                            <article class="single_product">
                                <figure>
                                    <div class="product_name">
                                       <h4><a href="product-details.html"><?php echo $products_data->product_name; ?></a></h4>
                                    </div>
                                   <div class="product_rating">
                                       <ul>
                                           <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                           <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                           <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                           <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                           <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                       </ul>
                                   </div>
                                    <div class="product_thumb">
                                        <a class="primary_img" href="product-details.html"><img src="<?php echo base_url($img); ?>" alt=""></a>
                                        <div class="label_product">
                                            <span class="label_sale">Sale!</span>
                                        </div>
                                        <div class="quick_button">
                                            <a href="#" data-toggle="modal" id="<?php echo $products_data->id; ?>" data-target="#modal_box" class="home_modal"  title="quick view"> Quick View</a>
                                        </div>
                                    </div>
                                    <div class="product_footer product_content grid_content">
                                        <div class="price_box"> 
                                            <span class="old_price">$<?php echo $products_data->price; ?>.00</span> 
                                            <span class="current_price">$<?php echo $products_data->new_price; ?>.00</span>
                                        </div>
                                        <div class="action_links">
                                             <ul>
                                                <input type="hidden" name="product_quantity" id="product_quantity" value="1">
                                                    <li class="add_to_cart"><a class="button add_to_cart" type="button" data-product_name="<?php echo $products_data->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-product_id="<?php echo $products_data->product_id; ?>" data-product_image="<?php echo $img; ?>" title="Add to cart"> cart</a></li>

                                                <li class="wishlist"><a href="wishlist.html"  title="Add to Wishlist"><i class="ion-android-favorite-outline"></i></a></li>

                                                <li class="compare"><a href="#" title="Add to Compare"><i class="ion-shuffle"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product_content list_content">
                                        <div class="product_name">
                                               <h4><a href="product-details.html"><?php echo $products_data->product_name; ?></a></h4>
                                        </div>
                                        <div class="product_rating">
                                           <ul>
                                               <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                               <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                               <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                               <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                               <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                           </ul>
                                        </div>
                                        <div class="price_box"> 
                                            <span class="old_price">$<?php echo $products_data->price; ?>.00</span> 
                                            <span class="current_price">$<?php echo $products_data->new_price; ?>.00</span>
                                        </div>
                                        <div class="product_desc">
                                            <p><?php echo $products_data->description; ?></p>
                                        </div>
                                        <div class="action_links">
                                             <ul>
                                                <input type="hidden" name="product_quantity" id="product_quantity" value="1">
                                                    <li class="add_to_cart"><a class="button add_to_cart" type="button" data-product_name="<?php echo $products_data->product_name; ?>" data-product_price="<?php echo $pr_price; ?>" data-product_id="<?php echo $products_data->product_id; ?>" data-product_image="<?php echo $img; ?>" title="Add to cart">Add to cart</a></li>

                                                <li class="wishlist"><a href="wishlist.html"  title="Add to Wishlist"><i class="ion-android-favorite-outline"></i></a></li>

                                                <li class="compare"><a href="#" title="Add to Compare"><i class="ion-shuffle"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </figure>
                            </article>
                        </div>
                    <?php endforeach; ?>
                       
                        

                        
                       


                    </div>

                    <!-- <div class="shop_toolbar t_bottom">
                        <div class="pagination">
                            <ul>
                                <li class="current">1</li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li class="next"><a href="#">next</a></li>
                                <li><a href="#">>></a></li>
                            </ul>
                        </div>
                    </div> -->
                    <!--shop toolbar end-->
                    <!--shop wrapper end-->
                </div>
            </div>
        </div>
    </div>
    <!--shop  area end-->
    