    <!-- BEGIN SLIDER -->
<!--     <div class="page-slider">
        <div id="carousel-example-generic" class="carousel slide carousel-slider">
      
            <ol class="carousel-indicators" >
                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                <li data-target="#carousel-example-generic" data-slide-to="3"></li>
            </ol>


            <div class="carousel-inner" role="listbox">
      
                <div class="item carousel-item-four active">
                    <div class="container">
                        <div class="carousel-position-four text-center">
                         
                        </div>
                    </div>
                </div>
    
                <div class="item carousel-item-five">
                    <div class="container">
                        <div class="carousel-position-four text-center">
                           
                        </div>
                        <img class="carousel-position-five animate-delay hidden-sm hidden-xs" src="<?php echo base_url(); ?>/frontfiles/assets/pages/img/shop-slider/slide2/price.png" alt="Price" data-animation="animated zoomIn">
                    </div>
                </div>

    
                <div class="item carousel-item-six">
                    <div class="container">
                        <div class="carousel-position-four text-center">
                         
                        </div>
                    </div>
                </div>

                <div class="item carousel-item-seven">
                   <div class="center-block">
                        <div class="center-block-wrap">
                            <div class="center-block-body">
                                <h2 class="carousel-title-v1 margin-bottom-20" data-animation="animated fadeInDown">
                                    The most <br/>
                                    wanted 
                                </h2>
                                <a class="carousel-btn" href="#" data-animation="animated fadeInUp">But It Now!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>




            <a class="left carousel-control carousel-control-shop" href="#carousel-example-generic" role="button" data-slide="prev">
                <i class="fa fa-angle-left" aria-hidden="true"></i>
            </a>
            <a class="right carousel-control carousel-control-shop" href="#carousel-example-generic" role="button" data-slide="next">
                <i class="fa fa-angle-right" aria-hidden="true"></i>
            </a>
        </div>
    </div> -->



 
      
          <div class="page-slider">
        <div id="carousel-example-generic" class="carousel slide carousel-slider">
     
            <div class="hero featured-carousel owl-carousel">
              <div class="item">
                <div class="work">
                  <div class="img d-flex align-items-center justify-content-center" style="background-image: url(<?php echo base_url('frontfiles/carousel');?>/images/<?php echo $slider1; ?>);">
                    
                  </div> 
                </div>
              </div>
              <div class="item">
                <div class="work">
                  <div class="img d-flex align-items-center justify-content-center" style="background-image: url(<?php echo base_url('frontfiles/carousel');?>/images/<?php echo $slider2; ?>);">

                  </div>
                </div>
              </div>
              <div class="item">
                <div class="work">
                  <div class="img d-flex align-items-center justify-content-center" style="background-image: url(<?php echo base_url('frontfiles/carousel');?>/images/<?php echo $slider3; ?>);">

                  </div>
                </div>
            
            </div>
           
          </div>
          </div>
          </div>
   
    
    <!-- END SLIDER -->

<div class="container-fluid">
    <div class="row">
  <!-- <div class="col-md-4 col-sm-4">
    ___________________________
</div> -->
<div class="col-md-12"><h2 style="margin-bottom: 20px; font-size: 35px;"><t style="font-family: fangsong;">CATEGORIES</t> </h2></div>
<!-- <div class="col-md-4">___________________________ </div> -->
  </div>
  
</div>
    <div class="container">
    
        <div class="row margin-bottom-40">
          <!-- BEGIN SALE PRODUCT -->
          <div class="col-md-12 sale-product">
            

              <?php foreach ($categories as $category):?>
                <a href="<?php echo base_url('home/products/'.$category->id.''); ?>">
              <div class="col-md-3">
                <div class="product-item">
                  <div class="pi-img-wrapper">
                    <img src="<?php echo base_url(); ?>product_images/<?php echo $category->category_image;  ?>" class="img-responsive" style="border-radius: 20px !important;">
                    
                  </div>
                 
                </div>
              </div>
            </a>


      
            
            <?php endforeach; ?>
              
            
          </div>
    
      
        </div>
        <h2><a href="<?php echo base_url('home/categories'); ?>" class="btn btn-primary" style="border-radius: 30px !important; font-size: 20px;     padding-left: 30px;
    padding-right: 30px;
    padding-bottom: 10px;
    padding-top: 10px;">Explore</a> </h2>
        <!-- END SALE PRODUCT & NEW ARRIVALS -->
    </div>
        <!-- BEGIN STEPS -->





    <!-- END STEPS -->
    <div class="main">


      <div class="steps-block steps-block-red">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 steps-block-col">
            
            <div>
              <h2 style="font-family: fangsong; text-align: center;">Festival Collection</h2>
              
            </div>
          </div>
        
        </div>
      </div>
    </div>


      <div class="container">
        <!-- BEGIN SALE PRODUCT & NEW ARRIVALS -->
        <div class="row margin-bottom-40">
          <!-- BEGIN SALE PRODUCT -->
          <div class="col-md-12 sale-product">
            <h2 style="font-size:40px">New Arrivals</h2>
            <h2><a href="<?php echo base_url('home/products'); ?>" class="btn btn-primary" style="border-radius: 20px !important;">Shop Now</a></h2>
           
            <div class="owl-carousel <?php echo $carousal; ?>">
              <?php foreach ($latest as $key => $value_1):
                                                    if(empty($value_1->customer_retail_price_new) || $value_1->customer_retail_price_new == 0)
                                                        {
                                                            $pr_price = $value_1->customer_retail_price;
                                                            $product_price_1 = '<span class="current_price">$'.$value_1->customer_retail_price.'.00</span>';
                                                        }
                                                        else{
                                                            $pr_price = $value_1->customer_retail_price_new;
                                                            $product_price_1 = '<span class="old_price">$'.$value_1->customer_retail_price.'.00</span> 
                                                                    <span class="current_price">$'.$value_1->customer_retail_price_new.'.00</span>';
                                                                    $sale_tag = '<div class="sticker sticker-new"></div>';
                                                        }

                                                        if(empty($value_1->sub_image))
                                                        {
                                                            $img_1 = 'frontfiles/assets/img/product/product6.jpg';
                                                        }
                                                        else{
                                                            $img_1 = 'product_images/'.$value_1->sub_image.'';
                                                        }
                                                        if($value_1->product_area == 'Latest'){
                                                            $latest_tag = '<div class="sticker sticker-new"></div>';
                                                        }
                                                    
                                                ?>
              <div>
                <div class="product-item">
                   <a href="<?php echo base_url(); ?>home/product_details/<?php echo $value_1->product_id; ?>/<?php echo $value_1->p_info_id; ?>">
                  <div class="pi-img-wrapper">
                   <img src="<?php echo base_url($img_1); ?>" class="img-responsive" alt="<?php echo $value_1->product_name; ?>" style="border-radius: 20px !important;">
                    <div>
                      <!-- <a href="#product-pop-up" class="btn btn-default fancybox-fast-view home_modal" id="<?php //echo $value_1->product_id; ?>">View</a> -->

                    </div>
                  </div>
                  </a>
                  <h3><a href="<?php echo base_url(); ?>home/product_details/<?php echo $value_1->product_id; ?>/<?php echo $value_1->p_info_id; ?>"><?php echo $value_1->product_name; ?></a></h3>
                  <div class="pi-price">PKR <?php echo $pr_price; ?></div>
                  <input type="hidden" name="product_quantity" id="product_quantity" value="1">
                  <!-- <a type="button" class="btn btn-default add2cart add_to_cart" data-product_name="<?php// echo $value_1->product_name; ?>" data-product_price="<?php //echo $pr_price; ?>" data-product_id="<?php// echo $value_1->product_id; ?>" data-product_image="<?php //echo $img_1; ?>" >Add to cart</a> -->
                  <!-- <div class="sticker sticker-sale"></div> -->
                  <a href="<?php echo base_url(); ?>home/product_details/<?php echo $value_1->product_id; ?>/<?php echo $value_1->p_info_id; ?>" class="btn btn-default add2cart">Add to cart</a>
                  <?php echo $latest_tag;
                        echo $sale_tag; ?>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
          <!-- END SALE PRODUCT -->
        </div>
        <!-- END SALE PRODUCT & NEW ARRIVALS -->





        <!-- BEGIN SALE PRODUCT & BESTSELLER -->
        <div class="row margin-bottom-40">
          <!-- BEGIN SALE PRODUCT -->
          <div class="col-md-12 sale-product">
            <h2 style="font-size:40px">BEST SELLER</h2>
            <h2><button type="button" class="btn btn-primary" style="border-radius: 20px !important;">Shop Now</button></h2>
            <div class="owl-carousel <?php echo $bestsellcarousal; ?>">
              
              <?php foreach ($latest as $key => $value_1):
                                                    if(empty($value_1->customer_retail_price_new) || $value_1->customer_retail_price_new == 0)
                                                        {
                                                            $pr_price = $value_1->customer_retail_price;
                                                            $product_price_1 = '<span class="current_price">$'.$value_1->customer_retail_price.'.00</span>';
                                                        }
                                                        else{
                                                            $pr_price = $value_1->customer_retail_price_new;
                                                            $product_price_1 = '<span class="old_price">$'.$value_1->customer_retail_price.'.00</span> 
                                                                    <span class="current_price">$'.$value_1->customer_retail_price_new.'.00</span>';
                                                                    $sale_tag = '<div class="sticker sticker-new"></div>';
                                                        }

                                                        if(empty($value_1->sub_image))
                                                        {
                                                            $img_1 = 'frontfiles/assets/img/product/product6.jpg';
                                                        }
                                                        else{
                                                            $img_1 = 'product_images/'.$value_1->sub_image.'';
                                                        }
                                                        if($value_1->product_area == 'Latest'){
                                                            $latest_tag = '<div class="sticker sticker-new"></div>';
                                                        }
                                                    
                                                ?>
              
             
              <div>
                <div class="product-item">
                  <a href="<?php echo base_url(); ?>home/product_details/<?php echo $value_1->product_id; ?>/<?php echo $value_1->p_info_id; ?>">
                  <div class="pi-img-wrapper">
                    <img src="<?php echo base_url($img_1); ?>" class="img-responsive" alt="<?php echo $value_1->product_name; ?>" style="border-radius: 20px !important;">
                    <div>
                      <!-- <a href="#product-pop-up" class="btn btn-default fancybox-fast-view">View</a> -->

                    </div>
                  </div>
                  </a>
                  <h3><a href="<?php echo base_url(); ?>home/product_details/<?php echo $value_1->product_id; ?>/<?php echo $value_1->p_info_id; ?>"><?php echo $value_1->product_name; ?></a></h3>
                  <div class="pi-price">PKR <?php echo $pr_price; ?></div>
                  <!-- <a type="button" class="btn btn-default add2cart add_to_cart" data-product_name="<?php// echo $value_1->product_name; ?>" data-product_price="<?php// echo $pr_price; ?>" data-product_id="<?php //echo $value_1->product_id; ?>" data-product_image="<?php //echo $img_1; ?>" >Add to cart</a> -->
                  <a href="<?php echo base_url(); ?>home/product_details/<?php echo $value_1->product_id; ?>/<?php echo $value_1->p_info_id; ?>" class="btn btn-default add2cart">Add to cart</a>
                  <!-- <div class="sticker sticker-sale"></div> -->
                  <?php echo $latest_tag;
                        echo $sale_tag; ?>
                </div>
              </div>
              <?php endforeach; ?>

              
            
            </div>
          </div>
          <!-- END SALE PRODUCT -->
        </div>
        <!-- END SALE PRODUCT & BESTSELLER -->





        <!-- BEGIN SALE PRODUCT & NEW ARRIVALS -->
        <div class="row margin-bottom-40">
          <!-- BEGIN SALE PRODUCT -->
          <div class="col-md-12 sale-product">
            <h2 style="font-size:40px">Products</h2>
            <h2><a href="<?php echo base_url('home/products'); ?>" class="btn btn-primary" style="border-radius: 20px !important;">Shop Now</a></h2>
      
             
              <?php foreach ($rand_product_2 as $key => $value_1):
                                                    if(empty($value_1->customer_retail_price_new) || $value_1->customer_retail_price_new == 0)
                                                        {
                                                            $pr_price = $value_1->customer_retail_price;
                                                            $product_price_1 = '<span class="current_price">$'.$value_1->customer_retail_price.'.00</span>';
                                                        }
                                                        else{
                                                            $pr_price = $value_1->customer_retail_price_new;
                                                            $product_price_1 = '<span class="old_price">$'.$value_1->customer_retail_price.'.00</span> 
                                                                    <span class="current_price">$'.$value_1->customer_retail_price_new.'.00</span>';
                                                                    $sale_tag = '<div class="sticker sticker-new"></div>';
                                                        }

                                                        if(empty($value_1->sub_image))
                                                        {
                                                            $img_1 = 'frontfiles/assets/img/product/product6.jpg';
                                                        }
                                                        else{
                                                            $img_1 = 'product_images/'.$value_1->sub_image.'';
                                                        }
                                                        if($value_1->product_area == 'Latest'){
                                                            $latest_tag = '<div class="sticker sticker-new"></div>';
                                                        }
                                                    
                                                ?>

              
              
              <div class="col-md-3">
                <div class="product-item">
                  <a href="<?php echo base_url(); ?>home/product_details/<?php echo $value_1->product_id; ?>/<?php echo $value_1->p_info_id; ?>">
                  <div class="pi-img-wrapper">
                    <img src="<?php echo base_url($img_1); ?>" class="img-responsive" alt="<?php echo $value_1->product_name; ?>" style="border-radius: 20px !important;">
                    <div>
                      <!-- <a href="#product-pop-up" class="btn btn-default fancybox-fast-view">View</a> -->
                    </div>
                  </div>
                  </a>
                  <h3><a href="<?php echo base_url(); ?>home/product_details/<?php echo $value_1->product_id; ?>/<?php echo $value_1->p_info_id; ?>"><?php echo $value_1->product_name; ?></a></h3>
                  <div class="pi-price">PKR <?php echo $pr_price; ?></div>
                  <!-- <a href="javascript:;" class="btn btn-default add2cart add_to_cart" data-product_name="<?php //echo $value_1->product_name; ?>" data-product_price="<?php //echo $pr_price; ?>" data-product_id="<?php //echo $value_1->product_id; ?>" data-product_image="<?php //echo $img_1; ?>">Add to cart</a> -->
                  <a href="<?php echo base_url(); ?>home/product_details/<?php echo $value_1->product_id; ?>/<?php echo $value_1->p_info_id; ?>" class="btn btn-default add2cart">Add to cart</a>
                  <?php echo $latest_tag;
                        echo $sale_tag; ?>
                </div>
              </div>
            <?php endforeach; ?>

              
       
          </div>
          <!-- END SALE PRODUCT -->
        </div>
        <!-- END SALE PRODUCT & NEW ARRIVALS -->













        <!-- BEGIN TWO PRODUCTS & PROMO -->
<!--         <div class="row margin-bottom-35 ">
       
          <div class="col-md-6 col-sm-12 col-xs-12 shop-index-carousel">
            <div class="content-slider">
              <div id="myCarousel" class="carousel slide" data-ride="carousel">
            
                <ol class="carousel-indicators">
                  <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                  <li data-target="#myCarousel" data-slide-to="1"></li>
                  <li data-target="#myCarousel" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                  <div class="item active">
                    <img src="<?php //echo base_url(); ?>/frontfiles/assets/pages/img/index-sliders/slider11.png" class="img-responsive" alt="Berry Lace Dress">
                  </div>
                  <div class="item">
                    <img src="<?php //echo base_url(); ?>/frontfiles/assets/pages/img/index-sliders/slider12.png" class="img-responsive" alt="Berry Lace Dress">
                  </div>
                  <div class="item">
                    <img src="<?php //echo base_url(); ?>/frontfiles/assets/pages/img/index-sliders/slider13.png" class="img-responsive" alt="Berry Lace Dress">
                  </div>
                </div>
              </div>
            </div>
          </div>
        
          <div class="col-md-4 col-md-offset-2 col-sm-12 col-xs-12">
            <center><h1 style="margin-top: 110px; font-size: 40px; "><b>Evershine Exclusive</b></h1></center>
            <center><p>HANDCRAFTED JEWELRY & ACCESSORIES</p></center>
            <div style="    margin-top: 43px; text-align: center;">
                  <a href="javascript:;" class="btn btn-default" style="padding-left: 85px; padding-right: 85px; padding-top: 15px; padding-bottom: 15px; font-size: 15; color: #f38155;"><b>SHOP NOW</b></a>
            </div>
          </div>
      
          
        </div>   -->      

















      </div>
    </div>